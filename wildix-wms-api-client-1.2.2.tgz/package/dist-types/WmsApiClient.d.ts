import { CallControlAnswerCommandInput, CallControlAnswerCommandOutput } from "./commands/CallControlAnswerCommand";
import { CallControlAttendantTransferCommandInput, CallControlAttendantTransferCommandOutput } from "./commands/CallControlAttendantTransferCommand";
import { CallControlBlindTransferCommandInput, CallControlBlindTransferCommandOutput } from "./commands/CallControlBlindTransferCommand";
import { CallControlDtmfCommandInput, CallControlDtmfCommandOutput } from "./commands/CallControlDtmfCommand";
import { CallControlHangupCommandInput, CallControlHangupCommandOutput } from "./commands/CallControlHangupCommand";
import { CallControlHoldCommandInput, CallControlHoldCommandOutput } from "./commands/CallControlHoldCommand";
import { CallControlMakeCallCommandInput, CallControlMakeCallCommandOutput } from "./commands/CallControlMakeCallCommand";
import { CallControlUnholdCommandInput, CallControlUnholdCommandOutput } from "./commands/CallControlUnholdCommand";
import { CallControlUpdateContactInfoCommandInput, CallControlUpdateContactInfoCommandOutput } from "./commands/CallControlUpdateContactInfoCommand";
import { CreatePbxAclGroupCommandInput, CreatePbxAclGroupCommandOutput } from "./commands/CreatePbxAclGroupCommand";
import { CreatePbxColleagueCommandInput, CreatePbxColleagueCommandOutput } from "./commands/CreatePbxColleagueCommand";
import { CreatePbxOAuth2ClientCommandInput, CreatePbxOAuth2ClientCommandOutput } from "./commands/CreatePbxOAuth2ClientCommand";
import { DeletePbxAclGroupCommandInput, DeletePbxAclGroupCommandOutput } from "./commands/DeletePbxAclGroupCommand";
import { DeletePbxColleagueCommandInput, DeletePbxColleagueCommandOutput } from "./commands/DeletePbxColleagueCommand";
import { DeletePbxOAuth2ClientCommandInput, DeletePbxOAuth2ClientCommandOutput } from "./commands/DeletePbxOAuth2ClientCommand";
import { GetCallQueuesSettingsCommandInput, GetCallQueuesSettingsCommandOutput } from "./commands/GetCallQueuesSettingsCommand";
import { GetColleagueByIdCommandInput, GetColleagueByIdCommandOutput } from "./commands/GetColleagueByIdCommand";
import { GetPbxAclGroupsPermissionsCommandInput, GetPbxAclGroupsPermissionsCommandOutput } from "./commands/GetPbxAclGroupsPermissionsCommand";
import { GetPbxCallGroupsCommandInput, GetPbxCallGroupsCommandOutput } from "./commands/GetPbxCallGroupsCommand";
import { GetPbxColleaguesCommandInput, GetPbxColleaguesCommandOutput } from "./commands/GetPbxColleaguesCommand";
import { GetPbxOAuth2ClientsCommandInput, GetPbxOAuth2ClientsCommandOutput } from "./commands/GetPbxOAuth2ClientsCommand";
import { GetPbxesCommandInput, GetPbxesCommandOutput } from "./commands/GetPbxesCommand";
import { GetPersonalInfoCommandInput, GetPersonalInfoCommandOutput } from "./commands/GetPersonalInfoCommand";
import { ListPbxDepartmentsCommandInput, ListPbxDepartmentsCommandOutput } from "./commands/ListPbxDepartmentsCommand";
import { ListPbxGroupsCommandInput, ListPbxGroupsCommandOutput } from "./commands/ListPbxGroupsCommand";
import { ListUserActiveCallsCommandInput, ListUserActiveCallsCommandOutput } from "./commands/ListUserActiveCallsCommand";
import { ListUserDevicesCommandInput, ListUserDevicesCommandOutput } from "./commands/ListUserDevicesCommand";
import { NotificationsCommandInput, NotificationsCommandOutput } from "./commands/NotificationsCommand";
import { OriginateCallCommandInput, OriginateCallCommandOutput } from "./commands/OriginateCallCommand";
import { OriginateCommandInput, OriginateCommandOutput } from "./commands/OriginateCommand";
import { ReloadBroadcastsCommandInput, ReloadBroadcastsCommandOutput } from "./commands/ReloadBroadcastsCommand";
import { UpdatePbxOAuth2ClientCommandInput, UpdatePbxOAuth2ClientCommandOutput } from "./commands/UpdatePbxOAuth2ClientCommand";
import { RuntimeExtension, RuntimeExtensionsConfig } from "./runtimeExtensions";
import { UserAgentInputConfig, UserAgentResolvedConfig } from "@aws-sdk/middleware-user-agent";
import { RetryInputConfig, RetryResolvedConfig } from "@smithy/middleware-retry";
import { HttpHandlerUserInput as __HttpHandlerUserInput } from "@smithy/protocol-http";
import { Client as __Client, DefaultsMode as __DefaultsMode, SmithyConfiguration as __SmithyConfiguration, SmithyResolvedConfiguration as __SmithyResolvedConfiguration } from "@smithy/smithy-client";
import { Provider, BodyLengthCalculator as __BodyLengthCalculator, CheckOptionalClientConfig as __CheckOptionalClientConfig, ChecksumConstructor as __ChecksumConstructor, Decoder as __Decoder, Encoder as __Encoder, HashConstructor as __HashConstructor, HttpHandlerOptions as __HttpHandlerOptions, Logger as __Logger, Provider as __Provider, StreamCollector as __StreamCollector, UrlParser as __UrlParser, UserAgent as __UserAgent } from "@smithy/types";
import { TokenProvider } from '@wildix/smithy-utils';
export { __Client };
/**
 * @public
 */
export type ServiceInputTypes = CallControlAnswerCommandInput | CallControlAttendantTransferCommandInput | CallControlBlindTransferCommandInput | CallControlDtmfCommandInput | CallControlHangupCommandInput | CallControlHoldCommandInput | CallControlMakeCallCommandInput | CallControlUnholdCommandInput | CallControlUpdateContactInfoCommandInput | CreatePbxAclGroupCommandInput | CreatePbxColleagueCommandInput | CreatePbxOAuth2ClientCommandInput | DeletePbxAclGroupCommandInput | DeletePbxColleagueCommandInput | DeletePbxOAuth2ClientCommandInput | GetCallQueuesSettingsCommandInput | GetColleagueByIdCommandInput | GetPbxAclGroupsPermissionsCommandInput | GetPbxCallGroupsCommandInput | GetPbxColleaguesCommandInput | GetPbxOAuth2ClientsCommandInput | GetPbxesCommandInput | GetPersonalInfoCommandInput | ListPbxDepartmentsCommandInput | ListPbxGroupsCommandInput | ListUserActiveCallsCommandInput | ListUserDevicesCommandInput | NotificationsCommandInput | OriginateCallCommandInput | OriginateCommandInput | ReloadBroadcastsCommandInput | UpdatePbxOAuth2ClientCommandInput;
/**
 * @public
 */
export type ServiceOutputTypes = CallControlAnswerCommandOutput | CallControlAttendantTransferCommandOutput | CallControlBlindTransferCommandOutput | CallControlDtmfCommandOutput | CallControlHangupCommandOutput | CallControlHoldCommandOutput | CallControlMakeCallCommandOutput | CallControlUnholdCommandOutput | CallControlUpdateContactInfoCommandOutput | CreatePbxAclGroupCommandOutput | CreatePbxColleagueCommandOutput | CreatePbxOAuth2ClientCommandOutput | DeletePbxAclGroupCommandOutput | DeletePbxColleagueCommandOutput | DeletePbxOAuth2ClientCommandOutput | GetCallQueuesSettingsCommandOutput | GetColleagueByIdCommandOutput | GetPbxAclGroupsPermissionsCommandOutput | GetPbxCallGroupsCommandOutput | GetPbxColleaguesCommandOutput | GetPbxOAuth2ClientsCommandOutput | GetPbxesCommandOutput | GetPersonalInfoCommandOutput | ListPbxDepartmentsCommandOutput | ListPbxGroupsCommandOutput | ListUserActiveCallsCommandOutput | ListUserDevicesCommandOutput | NotificationsCommandOutput | OriginateCallCommandOutput | OriginateCommandOutput | ReloadBroadcastsCommandOutput | UpdatePbxOAuth2ClientCommandOutput;
/**
 * @public
 */
export interface ClientDefaults extends Partial<__SmithyConfiguration<__HttpHandlerOptions>> {
    /**
     * The HTTP handler to use or its constructor options. Fetch in browser and Https in Nodejs.
     */
    requestHandler?: __HttpHandlerUserInput;
    /**
     * A constructor for a class implementing the {@link @smithy/types#ChecksumConstructor} interface
     * that computes the SHA-256 HMAC or checksum of a string or binary buffer.
     * @internal
     */
    sha256?: __ChecksumConstructor | __HashConstructor;
    /**
     * The function that will be used to convert strings into HTTP endpoints.
     * @internal
     */
    urlParser?: __UrlParser;
    /**
     * A function that can calculate the length of a request body.
     * @internal
     */
    bodyLengthChecker?: __BodyLengthCalculator;
    /**
     * A function that converts a stream into an array of bytes.
     * @internal
     */
    streamCollector?: __StreamCollector;
    /**
     * The function that will be used to convert a base64-encoded string to a byte array.
     * @internal
     */
    base64Decoder?: __Decoder;
    /**
     * The function that will be used to convert binary data to a base64-encoded string.
     * @internal
     */
    base64Encoder?: __Encoder;
    /**
     * The function that will be used to convert a UTF8-encoded string to a byte array.
     * @internal
     */
    utf8Decoder?: __Decoder;
    /**
     * The function that will be used to convert binary data to a UTF-8 encoded string.
     * @internal
     */
    utf8Encoder?: __Encoder;
    /**
     * The runtime environment.
     * @internal
     */
    runtime?: string;
    /**
     * Disable dynamically changing the endpoint of the client based on the hostPrefix
     * trait of an operation.
     */
    disableHostPrefix?: boolean;
    /**
     * The provider populating default tracking information to be sent with `user-agent`, `x-amz-user-agent` header
     * @internal
     */
    defaultUserAgentProvider?: Provider<__UserAgent>;
    /**
     * Value for how many times a request will be made at most in case of retry.
     */
    maxAttempts?: number | __Provider<number>;
    /**
     * Specifies which retry algorithm to use.
     * @see https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/Package/-smithy-util-retry/Enum/RETRY_MODES/
     *
     */
    retryMode?: string | __Provider<string>;
    /**
     * Optional logger for logging debug/info/warn/error.
     */
    logger?: __Logger;
    /**
     * Optional extensions
     */
    extensions?: RuntimeExtension[];
    /**
     * The {@link @smithy/smithy-client#DefaultsMode} that will be used to determine how certain default configuration options are resolved in the SDK.
     */
    defaultsMode?: __DefaultsMode | __Provider<__DefaultsMode>;
}
/**
 * @public
 */
export type WmsApiClientConfigType = Partial<__SmithyConfiguration<__HttpHandlerOptions>> & ClientDefaults & UserAgentInputConfig & RetryInputConfig;
/**
 * @public
 *
 *  The configuration interface of WmsApiClient class constructor that set the region, credentials and other options.
 */
export interface WmsApiClientConfig extends WmsApiClientConfigType {
    domain: string;
    port?: number;
    token: TokenProvider;
}
/**
 * @public
 */
export type WmsApiClientResolvedConfigType = __SmithyResolvedConfiguration<__HttpHandlerOptions> & Required<ClientDefaults> & RuntimeExtensionsConfig & UserAgentResolvedConfig & RetryResolvedConfig;
/**
 * @public
 *
 *  The resolved configuration interface of WmsApiClient class. This is resolved and normalized from the {@link WmsApiClientConfig | constructor configuration interface}.
 */
export interface WmsApiClientResolvedConfig extends WmsApiClientResolvedConfigType {
}
/**
 * @public
 */
export declare class WmsApiClient extends __Client<__HttpHandlerOptions, ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig> {
    /**
     * The resolved configuration of WmsApiClient class. This is resolved and normalized from the {@link WmsApiClientConfig | constructor configuration interface}.
     */
    readonly config: WmsApiClientResolvedConfig;
    constructor(...[configuration]: __CheckOptionalClientConfig<WmsApiClientConfig>);
    /**
     * Destroy underlying resources, like sockets. It's usually not necessary to do this.
     * However in Node.js, it's best to explicitly shut down the client's agent when it is no longer needed.
     * Otherwise, sockets might stay open for quite a long time before the server terminates them.
     */
    destroy(): void;
}
