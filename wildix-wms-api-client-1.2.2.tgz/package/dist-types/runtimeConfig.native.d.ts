import { WmsApiClientConfig } from "./WmsApiClient";
/**
 * @internal
 */
export declare const getRuntimeConfig: (config: WmsApiClientConfig) => {
    runtime: string;
    sha256: import("@smithy/types").HashConstructor;
    domain: string;
    port?: number | undefined;
    token: import("@wildix/smithy-utils").TokenProvider;
    requestHandler: import("@smithy/types").NodeHttpHandlerOptions | import("@smithy/types").FetchHttpHandlerOptions | Record<string, unknown> | import("@smithy/protocol-http").HttpHandler<any> | import("@smithy/fetch-http-handler").FetchHttpHandler;
    cacheMiddleware?: boolean | undefined;
    protocol?: import("@smithy/types").ClientProtocol<any, any> | import("@smithy/types").$ClientProtocol<any, any> | import("@smithy/types").ClientProtocolCtor<any, any> | import("@smithy/types").$ClientProtocolCtor<any, any> | undefined;
    protocolSettings?: {
        [setting: string]: unknown;
        defaultNamespace?: string | undefined;
    } | undefined;
    apiVersion: string;
    urlParser: import("@smithy/types").UrlParser;
    bodyLengthChecker: import("@smithy/types").BodyLengthCalculator;
    streamCollector: import("@smithy/types").StreamCollector;
    base64Decoder: import("@smithy/types").Decoder;
    base64Encoder: (_input: string | Uint8Array) => string;
    utf8Decoder: import("@smithy/types").Decoder;
    utf8Encoder: (input: string | Uint8Array) => string;
    disableHostPrefix: boolean;
    defaultUserAgentProvider: (config?: import("@aws-sdk/util-user-agent-browser").PreviouslyResolved | undefined) => Promise<import("@smithy/types").UserAgent>;
    maxAttempts: number | import("@smithy/types").Provider<number>;
    retryMode: string | import("@smithy/types").Provider<string>;
    logger: import("@smithy/types").Logger;
    extensions: import("./runtimeExtensions").RuntimeExtension[];
    defaultsMode: import("@smithy/smithy-client").DefaultsMode | import("@smithy/types").Provider<import("@smithy/smithy-client").DefaultsMode>;
    customUserAgent?: string | import("@smithy/types").UserAgent | undefined;
    userAgentAppId?: string | import("@smithy/types").Provider<string | undefined> | undefined;
    retryStrategy?: import("@smithy/types").RetryStrategy | import("@smithy/types").RetryStrategyV2 | undefined;
};
