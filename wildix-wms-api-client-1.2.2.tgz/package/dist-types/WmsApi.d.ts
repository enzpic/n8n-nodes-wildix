import { WmsApiClient } from "./WmsApiClient";
import { CallControlAnswerCommandInput, CallControlAnswerCommandOutput } from "./commands/CallControlAnswerCommand";
import { CallControlAttendantTransferCommandInput, CallControlAttendantTransferCommandOutput } from "./commands/CallControlAttendantTransferCommand";
import { CallControlBlindTransferCommandInput, CallControlBlindTransferCommandOutput } from "./commands/CallControlBlindTransferCommand";
import { CallControlDtmfCommandInput, CallControlDtmfCommandOutput } from "./commands/CallControlDtmfCommand";
import { CallControlHangupCommandInput, CallControlHangupCommandOutput } from "./commands/CallControlHangupCommand";
import { CallControlHoldCommandInput, CallControlHoldCommandOutput } from "./commands/CallControlHoldCommand";
import { CallControlMakeCallCommandInput, CallControlMakeCallCommandOutput } from "./commands/CallControlMakeCallCommand";
import { CallControlUnholdCommandInput, CallControlUnholdCommandOutput } from "./commands/CallControlUnholdCommand";
import { CallControlUpdateContactInfoCommandInput, CallControlUpdateContactInfoCommandOutput } from "./commands/CallControlUpdateContactInfoCommand";
import { CreatePbxAclGroupCommandInput, CreatePbxAclGroupCommandOutput } from "./commands/CreatePbxAclGroupCommand";
import { CreatePbxColleagueCommandInput, CreatePbxColleagueCommandOutput } from "./commands/CreatePbxColleagueCommand";
import { CreatePbxOAuth2ClientCommandInput, CreatePbxOAuth2ClientCommandOutput } from "./commands/CreatePbxOAuth2ClientCommand";
import { DeletePbxAclGroupCommandInput, DeletePbxAclGroupCommandOutput } from "./commands/DeletePbxAclGroupCommand";
import { DeletePbxColleagueCommandInput, DeletePbxColleagueCommandOutput } from "./commands/DeletePbxColleagueCommand";
import { DeletePbxOAuth2ClientCommandInput, DeletePbxOAuth2ClientCommandOutput } from "./commands/DeletePbxOAuth2ClientCommand";
import { GetCallQueuesSettingsCommandInput, GetCallQueuesSettingsCommandOutput } from "./commands/GetCallQueuesSettingsCommand";
import { GetColleagueByIdCommandInput, GetColleagueByIdCommandOutput } from "./commands/GetColleagueByIdCommand";
import { GetPbxAclGroupsPermissionsCommandInput, GetPbxAclGroupsPermissionsCommandOutput } from "./commands/GetPbxAclGroupsPermissionsCommand";
import { GetPbxCallGroupsCommandInput, GetPbxCallGroupsCommandOutput } from "./commands/GetPbxCallGroupsCommand";
import { GetPbxColleaguesCommandInput, GetPbxColleaguesCommandOutput } from "./commands/GetPbxColleaguesCommand";
import { GetPbxOAuth2ClientsCommandInput, GetPbxOAuth2ClientsCommandOutput } from "./commands/GetPbxOAuth2ClientsCommand";
import { GetPbxesCommandInput, GetPbxesCommandOutput } from "./commands/GetPbxesCommand";
import { GetPersonalInfoCommandInput, GetPersonalInfoCommandOutput } from "./commands/GetPersonalInfoCommand";
import { ListPbxDepartmentsCommandInput, ListPbxDepartmentsCommandOutput } from "./commands/ListPbxDepartmentsCommand";
import { ListPbxGroupsCommandInput, ListPbxGroupsCommandOutput } from "./commands/ListPbxGroupsCommand";
import { ListUserActiveCallsCommandInput, ListUserActiveCallsCommandOutput } from "./commands/ListUserActiveCallsCommand";
import { ListUserDevicesCommandInput, ListUserDevicesCommandOutput } from "./commands/ListUserDevicesCommand";
import { NotificationsCommandInput, NotificationsCommandOutput } from "./commands/NotificationsCommand";
import { OriginateCallCommandInput, OriginateCallCommandOutput } from "./commands/OriginateCallCommand";
import { OriginateCommandInput, OriginateCommandOutput } from "./commands/OriginateCommand";
import { ReloadBroadcastsCommandInput, ReloadBroadcastsCommandOutput } from "./commands/ReloadBroadcastsCommand";
import { UpdatePbxOAuth2ClientCommandInput, UpdatePbxOAuth2ClientCommandOutput } from "./commands/UpdatePbxOAuth2ClientCommand";
import { HttpHandlerOptions as __HttpHandlerOptions } from "@smithy/types";
export interface WmsApi {
    /**
     * @see {@link CallControlAnswerCommand}
     */
    callControlAnswer(args: CallControlAnswerCommandInput, options?: __HttpHandlerOptions): Promise<CallControlAnswerCommandOutput>;
    callControlAnswer(args: CallControlAnswerCommandInput, cb: (err: any, data?: CallControlAnswerCommandOutput) => void): void;
    callControlAnswer(args: CallControlAnswerCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CallControlAnswerCommandOutput) => void): void;
    /**
     * @see {@link CallControlAttendantTransferCommand}
     */
    callControlAttendantTransfer(args: CallControlAttendantTransferCommandInput, options?: __HttpHandlerOptions): Promise<CallControlAttendantTransferCommandOutput>;
    callControlAttendantTransfer(args: CallControlAttendantTransferCommandInput, cb: (err: any, data?: CallControlAttendantTransferCommandOutput) => void): void;
    callControlAttendantTransfer(args: CallControlAttendantTransferCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CallControlAttendantTransferCommandOutput) => void): void;
    /**
     * @see {@link CallControlBlindTransferCommand}
     */
    callControlBlindTransfer(args: CallControlBlindTransferCommandInput, options?: __HttpHandlerOptions): Promise<CallControlBlindTransferCommandOutput>;
    callControlBlindTransfer(args: CallControlBlindTransferCommandInput, cb: (err: any, data?: CallControlBlindTransferCommandOutput) => void): void;
    callControlBlindTransfer(args: CallControlBlindTransferCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CallControlBlindTransferCommandOutput) => void): void;
    /**
     * @see {@link CallControlDtmfCommand}
     */
    callControlDtmf(args: CallControlDtmfCommandInput, options?: __HttpHandlerOptions): Promise<CallControlDtmfCommandOutput>;
    callControlDtmf(args: CallControlDtmfCommandInput, cb: (err: any, data?: CallControlDtmfCommandOutput) => void): void;
    callControlDtmf(args: CallControlDtmfCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CallControlDtmfCommandOutput) => void): void;
    /**
     * @see {@link CallControlHangupCommand}
     */
    callControlHangup(args: CallControlHangupCommandInput, options?: __HttpHandlerOptions): Promise<CallControlHangupCommandOutput>;
    callControlHangup(args: CallControlHangupCommandInput, cb: (err: any, data?: CallControlHangupCommandOutput) => void): void;
    callControlHangup(args: CallControlHangupCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CallControlHangupCommandOutput) => void): void;
    /**
     * @see {@link CallControlHoldCommand}
     */
    callControlHold(args: CallControlHoldCommandInput, options?: __HttpHandlerOptions): Promise<CallControlHoldCommandOutput>;
    callControlHold(args: CallControlHoldCommandInput, cb: (err: any, data?: CallControlHoldCommandOutput) => void): void;
    callControlHold(args: CallControlHoldCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CallControlHoldCommandOutput) => void): void;
    /**
     * @see {@link CallControlMakeCallCommand}
     */
    callControlMakeCall(args: CallControlMakeCallCommandInput, options?: __HttpHandlerOptions): Promise<CallControlMakeCallCommandOutput>;
    callControlMakeCall(args: CallControlMakeCallCommandInput, cb: (err: any, data?: CallControlMakeCallCommandOutput) => void): void;
    callControlMakeCall(args: CallControlMakeCallCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CallControlMakeCallCommandOutput) => void): void;
    /**
     * @see {@link CallControlUnholdCommand}
     */
    callControlUnhold(args: CallControlUnholdCommandInput, options?: __HttpHandlerOptions): Promise<CallControlUnholdCommandOutput>;
    callControlUnhold(args: CallControlUnholdCommandInput, cb: (err: any, data?: CallControlUnholdCommandOutput) => void): void;
    callControlUnhold(args: CallControlUnholdCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CallControlUnholdCommandOutput) => void): void;
    /**
     * @see {@link CallControlUpdateContactInfoCommand}
     */
    callControlUpdateContactInfo(args: CallControlUpdateContactInfoCommandInput, options?: __HttpHandlerOptions): Promise<CallControlUpdateContactInfoCommandOutput>;
    callControlUpdateContactInfo(args: CallControlUpdateContactInfoCommandInput, cb: (err: any, data?: CallControlUpdateContactInfoCommandOutput) => void): void;
    callControlUpdateContactInfo(args: CallControlUpdateContactInfoCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CallControlUpdateContactInfoCommandOutput) => void): void;
    /**
     * @see {@link CreatePbxAclGroupCommand}
     */
    createPbxAclGroup(args: CreatePbxAclGroupCommandInput, options?: __HttpHandlerOptions): Promise<CreatePbxAclGroupCommandOutput>;
    createPbxAclGroup(args: CreatePbxAclGroupCommandInput, cb: (err: any, data?: CreatePbxAclGroupCommandOutput) => void): void;
    createPbxAclGroup(args: CreatePbxAclGroupCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CreatePbxAclGroupCommandOutput) => void): void;
    /**
     * @see {@link CreatePbxColleagueCommand}
     */
    createPbxColleague(args: CreatePbxColleagueCommandInput, options?: __HttpHandlerOptions): Promise<CreatePbxColleagueCommandOutput>;
    createPbxColleague(args: CreatePbxColleagueCommandInput, cb: (err: any, data?: CreatePbxColleagueCommandOutput) => void): void;
    createPbxColleague(args: CreatePbxColleagueCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CreatePbxColleagueCommandOutput) => void): void;
    /**
     * @see {@link CreatePbxOAuth2ClientCommand}
     */
    createPbxOAuth2Client(args: CreatePbxOAuth2ClientCommandInput, options?: __HttpHandlerOptions): Promise<CreatePbxOAuth2ClientCommandOutput>;
    createPbxOAuth2Client(args: CreatePbxOAuth2ClientCommandInput, cb: (err: any, data?: CreatePbxOAuth2ClientCommandOutput) => void): void;
    createPbxOAuth2Client(args: CreatePbxOAuth2ClientCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CreatePbxOAuth2ClientCommandOutput) => void): void;
    /**
     * @see {@link DeletePbxAclGroupCommand}
     */
    deletePbxAclGroup(args: DeletePbxAclGroupCommandInput, options?: __HttpHandlerOptions): Promise<DeletePbxAclGroupCommandOutput>;
    deletePbxAclGroup(args: DeletePbxAclGroupCommandInput, cb: (err: any, data?: DeletePbxAclGroupCommandOutput) => void): void;
    deletePbxAclGroup(args: DeletePbxAclGroupCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: DeletePbxAclGroupCommandOutput) => void): void;
    /**
     * @see {@link DeletePbxColleagueCommand}
     */
    deletePbxColleague(args: DeletePbxColleagueCommandInput, options?: __HttpHandlerOptions): Promise<DeletePbxColleagueCommandOutput>;
    deletePbxColleague(args: DeletePbxColleagueCommandInput, cb: (err: any, data?: DeletePbxColleagueCommandOutput) => void): void;
    deletePbxColleague(args: DeletePbxColleagueCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: DeletePbxColleagueCommandOutput) => void): void;
    /**
     * @see {@link DeletePbxOAuth2ClientCommand}
     */
    deletePbxOAuth2Client(args: DeletePbxOAuth2ClientCommandInput, options?: __HttpHandlerOptions): Promise<DeletePbxOAuth2ClientCommandOutput>;
    deletePbxOAuth2Client(args: DeletePbxOAuth2ClientCommandInput, cb: (err: any, data?: DeletePbxOAuth2ClientCommandOutput) => void): void;
    deletePbxOAuth2Client(args: DeletePbxOAuth2ClientCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: DeletePbxOAuth2ClientCommandOutput) => void): void;
    /**
     * @see {@link GetCallQueuesSettingsCommand}
     */
    getCallQueuesSettings(args: GetCallQueuesSettingsCommandInput, options?: __HttpHandlerOptions): Promise<GetCallQueuesSettingsCommandOutput>;
    getCallQueuesSettings(args: GetCallQueuesSettingsCommandInput, cb: (err: any, data?: GetCallQueuesSettingsCommandOutput) => void): void;
    getCallQueuesSettings(args: GetCallQueuesSettingsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetCallQueuesSettingsCommandOutput) => void): void;
    /**
     * @see {@link GetColleagueByIdCommand}
     */
    getColleagueById(args: GetColleagueByIdCommandInput, options?: __HttpHandlerOptions): Promise<GetColleagueByIdCommandOutput>;
    getColleagueById(args: GetColleagueByIdCommandInput, cb: (err: any, data?: GetColleagueByIdCommandOutput) => void): void;
    getColleagueById(args: GetColleagueByIdCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetColleagueByIdCommandOutput) => void): void;
    /**
     * @see {@link GetPbxAclGroupsPermissionsCommand}
     */
    getPbxAclGroupsPermissions(): Promise<GetPbxAclGroupsPermissionsCommandOutput>;
    getPbxAclGroupsPermissions(args: GetPbxAclGroupsPermissionsCommandInput, options?: __HttpHandlerOptions): Promise<GetPbxAclGroupsPermissionsCommandOutput>;
    getPbxAclGroupsPermissions(args: GetPbxAclGroupsPermissionsCommandInput, cb: (err: any, data?: GetPbxAclGroupsPermissionsCommandOutput) => void): void;
    getPbxAclGroupsPermissions(args: GetPbxAclGroupsPermissionsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetPbxAclGroupsPermissionsCommandOutput) => void): void;
    /**
     * @see {@link GetPbxCallGroupsCommand}
     */
    getPbxCallGroups(): Promise<GetPbxCallGroupsCommandOutput>;
    getPbxCallGroups(args: GetPbxCallGroupsCommandInput, options?: __HttpHandlerOptions): Promise<GetPbxCallGroupsCommandOutput>;
    getPbxCallGroups(args: GetPbxCallGroupsCommandInput, cb: (err: any, data?: GetPbxCallGroupsCommandOutput) => void): void;
    getPbxCallGroups(args: GetPbxCallGroupsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetPbxCallGroupsCommandOutput) => void): void;
    /**
     * @see {@link GetPbxColleaguesCommand}
     */
    getPbxColleagues(): Promise<GetPbxColleaguesCommandOutput>;
    getPbxColleagues(args: GetPbxColleaguesCommandInput, options?: __HttpHandlerOptions): Promise<GetPbxColleaguesCommandOutput>;
    getPbxColleagues(args: GetPbxColleaguesCommandInput, cb: (err: any, data?: GetPbxColleaguesCommandOutput) => void): void;
    getPbxColleagues(args: GetPbxColleaguesCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetPbxColleaguesCommandOutput) => void): void;
    /**
     * @see {@link GetPbxesCommand}
     */
    getPbxes(): Promise<GetPbxesCommandOutput>;
    getPbxes(args: GetPbxesCommandInput, options?: __HttpHandlerOptions): Promise<GetPbxesCommandOutput>;
    getPbxes(args: GetPbxesCommandInput, cb: (err: any, data?: GetPbxesCommandOutput) => void): void;
    getPbxes(args: GetPbxesCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetPbxesCommandOutput) => void): void;
    /**
     * @see {@link GetPbxOAuth2ClientsCommand}
     */
    getPbxOAuth2Clients(): Promise<GetPbxOAuth2ClientsCommandOutput>;
    getPbxOAuth2Clients(args: GetPbxOAuth2ClientsCommandInput, options?: __HttpHandlerOptions): Promise<GetPbxOAuth2ClientsCommandOutput>;
    getPbxOAuth2Clients(args: GetPbxOAuth2ClientsCommandInput, cb: (err: any, data?: GetPbxOAuth2ClientsCommandOutput) => void): void;
    getPbxOAuth2Clients(args: GetPbxOAuth2ClientsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetPbxOAuth2ClientsCommandOutput) => void): void;
    /**
     * @see {@link GetPersonalInfoCommand}
     */
    getPersonalInfo(): Promise<GetPersonalInfoCommandOutput>;
    getPersonalInfo(args: GetPersonalInfoCommandInput, options?: __HttpHandlerOptions): Promise<GetPersonalInfoCommandOutput>;
    getPersonalInfo(args: GetPersonalInfoCommandInput, cb: (err: any, data?: GetPersonalInfoCommandOutput) => void): void;
    getPersonalInfo(args: GetPersonalInfoCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetPersonalInfoCommandOutput) => void): void;
    /**
     * @see {@link ListPbxDepartmentsCommand}
     */
    listPbxDepartments(): Promise<ListPbxDepartmentsCommandOutput>;
    listPbxDepartments(args: ListPbxDepartmentsCommandInput, options?: __HttpHandlerOptions): Promise<ListPbxDepartmentsCommandOutput>;
    listPbxDepartments(args: ListPbxDepartmentsCommandInput, cb: (err: any, data?: ListPbxDepartmentsCommandOutput) => void): void;
    listPbxDepartments(args: ListPbxDepartmentsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ListPbxDepartmentsCommandOutput) => void): void;
    /**
     * @see {@link ListPbxGroupsCommand}
     */
    listPbxGroups(): Promise<ListPbxGroupsCommandOutput>;
    listPbxGroups(args: ListPbxGroupsCommandInput, options?: __HttpHandlerOptions): Promise<ListPbxGroupsCommandOutput>;
    listPbxGroups(args: ListPbxGroupsCommandInput, cb: (err: any, data?: ListPbxGroupsCommandOutput) => void): void;
    listPbxGroups(args: ListPbxGroupsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ListPbxGroupsCommandOutput) => void): void;
    /**
     * @see {@link ListUserActiveCallsCommand}
     */
    listUserActiveCalls(): Promise<ListUserActiveCallsCommandOutput>;
    listUserActiveCalls(args: ListUserActiveCallsCommandInput, options?: __HttpHandlerOptions): Promise<ListUserActiveCallsCommandOutput>;
    listUserActiveCalls(args: ListUserActiveCallsCommandInput, cb: (err: any, data?: ListUserActiveCallsCommandOutput) => void): void;
    listUserActiveCalls(args: ListUserActiveCallsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ListUserActiveCallsCommandOutput) => void): void;
    /**
     * @see {@link ListUserDevicesCommand}
     */
    listUserDevices(): Promise<ListUserDevicesCommandOutput>;
    listUserDevices(args: ListUserDevicesCommandInput, options?: __HttpHandlerOptions): Promise<ListUserDevicesCommandOutput>;
    listUserDevices(args: ListUserDevicesCommandInput, cb: (err: any, data?: ListUserDevicesCommandOutput) => void): void;
    listUserDevices(args: ListUserDevicesCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ListUserDevicesCommandOutput) => void): void;
    /**
     * @see {@link NotificationsCommand}
     */
    notifications(args: NotificationsCommandInput, options?: __HttpHandlerOptions): Promise<NotificationsCommandOutput>;
    notifications(args: NotificationsCommandInput, cb: (err: any, data?: NotificationsCommandOutput) => void): void;
    notifications(args: NotificationsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: NotificationsCommandOutput) => void): void;
    /**
     * @see {@link OriginateCommand}
     */
    originate(args: OriginateCommandInput, options?: __HttpHandlerOptions): Promise<OriginateCommandOutput>;
    originate(args: OriginateCommandInput, cb: (err: any, data?: OriginateCommandOutput) => void): void;
    originate(args: OriginateCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: OriginateCommandOutput) => void): void;
    /**
     * @see {@link OriginateCallCommand}
     */
    originateCall(args: OriginateCallCommandInput, options?: __HttpHandlerOptions): Promise<OriginateCallCommandOutput>;
    originateCall(args: OriginateCallCommandInput, cb: (err: any, data?: OriginateCallCommandOutput) => void): void;
    originateCall(args: OriginateCallCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: OriginateCallCommandOutput) => void): void;
    /**
     * @see {@link ReloadBroadcastsCommand}
     */
    reloadBroadcasts(): Promise<ReloadBroadcastsCommandOutput>;
    reloadBroadcasts(args: ReloadBroadcastsCommandInput, options?: __HttpHandlerOptions): Promise<ReloadBroadcastsCommandOutput>;
    reloadBroadcasts(args: ReloadBroadcastsCommandInput, cb: (err: any, data?: ReloadBroadcastsCommandOutput) => void): void;
    reloadBroadcasts(args: ReloadBroadcastsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ReloadBroadcastsCommandOutput) => void): void;
    /**
     * @see {@link UpdatePbxOAuth2ClientCommand}
     */
    updatePbxOAuth2Client(args: UpdatePbxOAuth2ClientCommandInput, options?: __HttpHandlerOptions): Promise<UpdatePbxOAuth2ClientCommandOutput>;
    updatePbxOAuth2Client(args: UpdatePbxOAuth2ClientCommandInput, cb: (err: any, data?: UpdatePbxOAuth2ClientCommandOutput) => void): void;
    updatePbxOAuth2Client(args: UpdatePbxOAuth2ClientCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: UpdatePbxOAuth2ClientCommandOutput) => void): void;
}
/**
 * @public
 */
export declare class WmsApi extends WmsApiClient implements WmsApi {
}
