import { HttpHandlerExtensionConfiguration } from "@smithy/protocol-http";
import { DefaultExtensionConfiguration } from "@smithy/types";
/**
 * @internal
 */
export interface WmsApiExtensionConfiguration extends HttpHandlerExtensionConfiguration, DefaultExtensionConfiguration {
}
