import { WmsApiServiceException as __BaseException } from "./WmsApiServiceException";
import { ExceptionOptionType as __ExceptionOptionType } from "@smithy/smithy-client";
/**
 * @public
 * @enum
 */
export declare const PbxLicenseType: {
    readonly BASIC: "basic";
    readonly BUSINESS: "business";
    readonly ESSENTIAL: "essential";
    readonly PREMIUM: "premium";
    readonly WIZYCONF: "wizyconf";
};
/**
 * @public
 */
export type PbxLicenseType = typeof PbxLicenseType[keyof typeof PbxLicenseType];
/**
 * @public
 * @enum
 */
export declare const AclGroupPermissionAbility: {
    readonly CAN: "can";
    readonly CANNOT: "cannot";
    readonly NO: "no";
    readonly NOUSE: "nouse";
    readonly USE: "use";
    readonly YES: "yes";
};
/**
 * @public
 */
export type AclGroupPermissionAbility = typeof AclGroupPermissionAbility[keyof typeof AclGroupPermissionAbility];
/**
 * @public
 */
export interface AclGroupRule {
    ability?: AclGroupPermissionAbility | undefined;
    group?: string | undefined;
    rule?: string | undefined;
}
/**
 * @public
 */
export interface AclGroup {
    id: number;
    name: string;
    dn: string;
    wcgrp: string;
    inherits: string;
    rules: (AclGroupRule)[];
    adminRules: string;
}
/**
 * @public
 */
export interface AclGroupPermissionFlatItem {
    groupDn: string;
    groupName: string;
    access: boolean;
}
/**
 * @public
 */
export interface AclGroupPermissionItem {
    groupDn: string;
    groupName: string;
    access: boolean;
    subGroups: (AclGroupPermissionFlatItem)[];
}
/**
 * @public
 */
export interface AclGroupPermission {
    ability: AclGroupPermissionAbility;
    key: string;
    name: string;
    containSubGroups: boolean;
    groups: (AclGroupPermissionItem)[];
}
/**
 * @public
 */
export interface Call {
    sipCallId: string;
    callerNumber: string;
    callerName?: string | undefined;
    calleeNumber: string;
    calleeName?: string | undefined;
    state: string;
    duration: number;
}
/**
 * @public
 */
export interface CallControlAnswerInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
    /**
     * Call identifier. For makecall action it is not required, for other actions it is required.
     * @public
     */
    sipCallId: string;
    /**
     * Can specify the device to answer the call on. If not specified, the default device for the user will be used.
     * @public
     */
    device?: string | undefined;
}
/**
 * @public
 */
export interface CallControlAnswerOutput {
    /**
     * A message describing the result of the call control operation, providing additional details or error information if applicable.
     * @public
     */
    message?: string | undefined;
}
/**
 * @public
 * @enum
 */
export declare const ResponseType: {
    readonly ERROR: "error";
    readonly RESULT: "result";
};
/**
 * @public
 */
export type ResponseType = typeof ResponseType[keyof typeof ResponseType];
/**
 * @public
 */
export declare class ChannelNotFoundException extends __BaseException {
    readonly name: "ChannelNotFoundException";
    readonly $fault: "client";
    type: ResponseType;
    reason: string;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<ChannelNotFoundException, __BaseException>);
}
/**
 * @public
 */
export declare class WmsForbiddenException extends __BaseException {
    readonly name: "WmsForbiddenException";
    readonly $fault: "client";
    type: ResponseType;
    reason: string;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<WmsForbiddenException, __BaseException>);
}
/**
 * @public
 */
export declare class WmsUnauthorizedException extends __BaseException {
    readonly name: "WmsUnauthorizedException";
    readonly $fault: "client";
    type: ResponseType;
    reason: string;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<WmsUnauthorizedException, __BaseException>);
}
/**
 * @public
 */
export interface CallControlAttendantTransferInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
    /**
     * Call identifier. For makecall action it is not required, for other actions it is required.
     * @public
     */
    sipCallId: string;
    /**
     * The destination for a call control operation. This can be a phone number, extension, or another valid identifier.
     * @public
     */
    destination: string;
}
/**
 * @public
 */
export interface CallControlAttendantTransferOutput {
    /**
     * A message describing the result of the call control operation, providing additional details or error information if applicable.
     * @public
     */
    message?: string | undefined;
}
/**
 * @public
 */
export interface CallControlBlindTransferInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
    /**
     * Call identifier. For makecall action it is not required, for other actions it is required.
     * @public
     */
    sipCallId: string;
    /**
     * The destination for a call control operation. This can be a phone number, extension, or another valid identifier.
     * @public
     */
    destination: string;
}
/**
 * @public
 */
export interface CallControlBlindTransferOutput {
    /**
     * A message describing the result of the call control operation, providing additional details or error information if applicable.
     * @public
     */
    message?: string | undefined;
}
/**
 * @public
 */
export interface CallControlDtmfInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
    /**
     * Call identifier. For makecall action it is not required, for other actions it is required.
     * @public
     */
    sipCallId: string;
    /**
     * DTMF digits. Allowed characters: 0-9, *, #
     * @public
     */
    digits: string;
}
/**
 * @public
 */
export interface CallControlDtmfOutput {
    /**
     * A message describing the result of the call control operation, providing additional details or error information if applicable.
     * @public
     */
    message?: string | undefined;
}
/**
 * @public
 */
export interface CallControlHangupInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
    /**
     * Call identifier. For makecall action it is not required, for other actions it is required.
     * @public
     */
    sipCallId: string;
    /**
     * Optional reason for the hangup. This can provide additional context for the action taken.
     * @public
     */
    reason?: string | undefined;
}
/**
 * @public
 */
export interface CallControlHangupOutput {
    /**
     * A message describing the result of the call control operation, providing additional details or error information if applicable.
     * @public
     */
    message?: string | undefined;
}
/**
 * @public
 */
export interface CallControlHoldInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
    /**
     * Call identifier. For makecall action it is not required, for other actions it is required.
     * @public
     */
    sipCallId: string;
}
/**
 * @public
 */
export interface CallControlHoldOutput {
    /**
     * A message describing the result of the call control operation, providing additional details or error information if applicable.
     * @public
     */
    message?: string | undefined;
}
/**
 * @public
 */
export interface CallControlMakeCallInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
    /**
     * The destination for a call control operation. This can be a phone number, extension, or another valid identifier.
     * @public
     */
    destination: string;
    /**
     * Can specify the device to answer the call on. If not specified, the default device for the user will be used.
     * @public
     */
    device?: string | undefined;
}
/**
 * @public
 */
export interface CallControlMakeCallOutput {
    /**
     * A message describing the result of the call control operation, providing additional details or error information if applicable.
     * @public
     */
    message?: string | undefined;
}
/**
 * @public
 */
export interface CallControlUnholdInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
    /**
     * Call identifier. For makecall action it is not required, for other actions it is required.
     * @public
     */
    sipCallId: string;
}
/**
 * @public
 */
export interface CallControlUnholdOutput {
    /**
     * A message describing the result of the call control operation, providing additional details or error information if applicable.
     * @public
     */
    message?: string | undefined;
}
/**
 * @public
 */
export interface CallControlUpdateContactInfoInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
    /**
     * Call identifier. For makecall action it is not required, for other actions it is required.
     * @public
     */
    sipCallId: string;
    /**
     * Contact name
     * @public
     */
    name?: string | undefined;
    /**
     * Phone number
     * @public
     */
    phone?: string | undefined;
}
/**
 * @public
 */
export interface CallControlUpdateContactInfoOutput {
    /**
     * A message describing the result of the call control operation, providing additional details or error information if applicable.
     * @public
     */
    message?: string | undefined;
}
/**
 * @public
 */
export interface CallQueuesSettingsMember {
    name: string;
    stateInterface: string;
    membership: string;
    penalty: string;
    callsTaken: string;
    lastCall: string;
    isInCall: string;
    status: string;
    paused: string;
    actionID: string;
}
/**
 * @public
 */
export interface CreatePbxAclGroupInput {
    name: string;
    inherits?: string | undefined;
    wcgrp?: string | undefined;
    rules: (AclGroupRule)[];
}
/**
 * @public
 */
export interface CreatePbxAclGroupOutput {
    type: ResponseType;
    result: AclGroup;
}
/**
 * @public
 * @enum
 */
export declare const PbxColleagueRole: {
    readonly ADMIN: "admin";
    readonly FAX: "fax";
    readonly PARK_ORBIT: "park_orbit";
    readonly ROOM: "room";
    readonly USER: "user";
};
/**
 * @public
 */
export type PbxColleagueRole = typeof PbxColleagueRole[keyof typeof PbxColleagueRole];
/**
 * @public
 */
export interface CreatePbxColleagueInput {
    extension: string;
    name: string;
    officePhone?: string | undefined;
    mobilePhone?: string | undefined;
    faxNumber?: string | undefined;
    email?: string | undefined;
    role?: PbxColleagueRole | undefined;
    groupDn?: string | undefined;
    language?: string | undefined;
    dialplan?: string | undefined;
    faxDialplan?: string | undefined;
    department?: string | undefined;
    login?: string | undefined;
    password?: string | undefined;
    sipPassword?: string | undefined;
    licenseType?: PbxLicenseType | undefined;
}
/**
 * @public
 */
export interface PbxColleague {
    id: string;
    name?: string | undefined;
    login?: string | undefined;
    extension: string;
    officePhone?: string | undefined;
    mobilePhone?: string | undefined;
    faxNumber?: string | undefined;
    email?: string | undefined;
    pbxDn: string;
    pbx: string;
    role: PbxColleagueRole;
    groupName: string;
    groupDn: string;
    language: string;
    dialplan: string;
    faxDialplan: string;
    department?: string | undefined;
    picture: string;
    sourceId?: string | undefined;
    licenseType: PbxLicenseType;
    jid: string;
}
/**
 * @public
 */
export interface CreatePbxColleagueOutput {
    type: ResponseType;
    result: PbxColleague;
}
/**
 * @public
 */
export interface CreatePbxOAuth2ClientInput {
    /**
     * A name of OAuth2 client.
     * @public
     */
    name: string;
    /**
     * Array of redirect URLs, allowed for this client.
     * @public
     */
    redirectUri: (string)[];
    /**
     * Timestamp for expiration of the OAuth2 application. Should not exceed 1 year.
     * @public
     */
    expireTime: number;
}
/**
 * @public
 */
export interface PbxOAuth2Client {
    id: string;
    name: string;
    redirectUri: (string)[];
    secret: string;
    created: number;
    origins: (string)[];
    accessTokenTtl: number;
}
/**
 * @public
 */
export interface CreatePbxOAuth2ClientOutput {
    type: ResponseType;
    result: PbxOAuth2Client;
}
/**
 * @public
 */
export interface WmsErrorItem {
    field: string;
    reason: string;
}
/**
 * @public
 */
export declare class WmsValidationException extends __BaseException {
    readonly name: "WmsValidationException";
    readonly $fault: "client";
    type: ResponseType;
    reason: string;
    errors: (WmsErrorItem)[];
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<WmsValidationException, __BaseException>);
}
/**
 * @public
 */
export interface DeletePbxAclGroupInput {
    id: number;
}
/**
 * @public
 */
export interface DeletePbxAclGroupOutput {
    type: ResponseType;
    result: string;
}
/**
 * @public
 */
export interface DeletePbxColleagueInput {
    id: number;
}
/**
 * @public
 */
export interface DeletePbxColleagueOutput {
    type: ResponseType;
    result: string;
}
/**
 * @public
 */
export interface DeletePbxOAuth2ClientInput {
    /**
     * Client ID.
     * @public
     */
    id: string;
}
/**
 * @public
 */
export interface DeletePbxOAuth2ClientOutput {
    type: ResponseType;
    result: string;
}
/**
 * @public
 */
export declare class WmsNotFoundException extends __BaseException {
    readonly name: "WmsNotFoundException";
    readonly $fault: "client";
    type: ResponseType;
    reason: string;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<WmsNotFoundException, __BaseException>);
}
/**
 * @public
 */
export interface UserDevice {
    userAgent: string;
    contact: string;
    active: boolean;
}
/**
 * @public
 */
export interface GetCallQueuesSettingsInput {
    groupId: number;
}
/**
 * @public
 */
export interface GetCallQueuesSettingsResult {
    id: number;
    name: string;
    members: (CallQueuesSettingsMember)[];
}
/**
 * @public
 */
export interface GetCallQueuesSettingsOutput {
    type: ResponseType;
    result: GetCallQueuesSettingsResult;
}
/**
 * @public
 */
export interface GetColleagueByIdInput {
    id: number;
}
/**
 * @public
 */
export interface GetColleagueByIdOutput {
    type: ResponseType;
    result: PbxColleague;
}
/**
 * @public
 */
export interface GetPbxAclGroupsPermissionsInput {
    /**
     * User group(s) ID for filter result. Example: ['12345'] or ['12345','67890','134711']
     * @public
     */
    groups?: (string)[] | undefined;
    /**
     * ACL permission(s) key for filter result. Example: ['SEE_CALL_RECORDINGS'] or ['CTI_ANALYTICS','SUPERVISION','SEE_ANALYTICS']
     * @public
     */
    permissions?: (string)[] | undefined;
}
/**
 * @public
 */
export interface GetPbxAclGroupsPermissionsOutput {
    type: ResponseType;
    result: (AclGroupPermission)[];
}
/**
 * @public
 */
export interface PbxCallGroupAnnounce {
    frequency?: number | undefined;
    holdTime?: string | undefined;
    roundSeconds?: number | undefined;
}
/**
 * @public
 */
export interface PbxCallGroupExitAllMembers {
    busy?: boolean | undefined;
    paused?: boolean | undefined;
    ringing?: boolean | undefined;
}
/**
 * @public
 */
export interface PbxCallGroupSettings {
    queueManager?: string | undefined;
    cid?: string | undefined;
    autoPause?: string | undefined;
    autoPauseTime?: number | undefined;
    autoPauseDelay?: number | undefined;
    autoPauseBusy?: boolean | undefined;
    autoPauseUnAvail?: boolean | undefined;
    maxLen?: number | undefined;
    retry?: number | undefined;
    ringInUse?: boolean | undefined;
    strategy?: string | undefined;
    defaultPriority?: number | undefined;
    timeout?: number | undefined;
    weight?: number | undefined;
    wrapUpTime?: number | undefined;
    rule?: string | undefined;
    announce?: PbxCallGroupAnnounce | undefined;
    exitAllMembers?: PbxCallGroupExitAllMembers | undefined;
    smsNumber?: string | undefined;
}
/**
 * @public
 */
export interface PbxCallGroup {
    id: number;
    title: string;
    members: (string)[];
    settings: PbxCallGroupSettings;
}
/**
 * @public
 */
export interface GetPbxCallGroupsResult {
    records: (PbxCallGroup)[];
    total: number;
}
/**
 * @public
 */
export interface GetPbxCallGroupsOutput {
    type: ResponseType;
    result: GetPbxCallGroupsResult;
}
/**
 * @public
 * @enum
 */
export declare const GetPbxColleaguesDir: {
    readonly ASC: "asc";
    readonly DESC: "desc";
};
/**
 * @public
 */
export type GetPbxColleaguesDir = typeof GetPbxColleaguesDir[keyof typeof GetPbxColleaguesDir];
/**
 * @public
 * @enum
 */
export declare const PbxColleaguesQueryField: {
    readonly DEPARTMENT: "department";
    readonly DIALPLAN: "dialplan";
    readonly EMAIL: "email";
    readonly EXTENSION: "extension";
    readonly FAX_DIALPLAN: "faxDialplan";
    readonly GROUP_DN: "groupDn";
    readonly ID: "id";
    readonly LANGUAGE: "language";
    readonly LICENSE_TYPE: "licenseType";
    readonly LOGIN: "login";
    readonly MOBILE_PHONE: "mobilePhone";
    readonly NAME: "name";
    readonly OFFICE_PHONE: "officePhone";
    readonly PBX_DN: "pbxDn";
    readonly PICTURE: "picture";
    readonly ROLE: "role";
    readonly SOURCE_ID: "sourceId";
};
/**
 * @public
 */
export type PbxColleaguesQueryField = typeof PbxColleaguesQueryField[keyof typeof PbxColleaguesQueryField];
/**
 * @public
 * @enum
 */
export declare const PbxColleaguesSearchStrategy: {
    readonly CONTAIN: "contain";
    readonly STARTS_WITH: "startsWith";
};
/**
 * @public
 */
export type PbxColleaguesSearchStrategy = typeof PbxColleaguesSearchStrategy[keyof typeof PbxColleaguesSearchStrategy];
/**
 * @public
 */
export interface GetPbxColleaguesInput {
    extension?: (string)[] | undefined;
    id?: (string)[] | undefined;
    officePhone?: (string)[] | undefined;
    mobilePhone?: (string)[] | undefined;
    name?: (string)[] | undefined;
    email?: (string)[] | undefined;
    role?: (string)[] | undefined;
    dialplan?: (string)[] | undefined;
    faxDialplan?: (string)[] | undefined;
    department?: (string)[] | undefined;
    login?: (string)[] | undefined;
    groupDn?: (string)[] | undefined;
    pbxDn?: (string)[] | undefined;
    licenseType?: (PbxLicenseType)[] | undefined;
    fields?: (PbxColleaguesQueryField)[] | undefined;
    searchFields?: (PbxColleaguesQueryField)[] | undefined;
    search?: string | undefined;
    sort?: (PbxColleaguesQueryField)[] | undefined;
    start?: number | undefined;
    count?: number | undefined;
    dir?: GetPbxColleaguesDir | undefined;
    searchStrategy?: PbxColleaguesSearchStrategy | undefined;
}
/**
 * @public
 */
export interface GetPbxColleaguesResult {
    records: (PbxColleague)[];
    total: number;
}
/**
 * @public
 */
export interface GetPbxColleaguesOutput {
    type: ResponseType;
    result: GetPbxColleaguesResult;
}
/**
 * @public
 */
export interface Pbx {
    ip: string;
    serial: string;
    host: string;
    isServer: boolean;
    port: number;
    failOver: string;
    version: string;
    isUpdateNeeded: boolean;
    dn: string;
}
/**
 * @public
 */
export interface GetPbxesResult {
    records: (Pbx)[];
}
/**
 * @public
 */
export interface GetPbxesOutput {
    type: ResponseType;
    result: GetPbxesResult;
}
/**
 * @public
 */
export interface PbxOAuth2ClientListProjection {
    id: string;
    name: string;
    redirectUri: (string)[];
    secret: string;
    created: number;
    expireTime: number;
}
/**
 * @public
 */
export interface GetPbxOAuth2ClientsResult {
    records: (PbxOAuth2ClientListProjection)[];
}
/**
 * @public
 */
export interface GetPbxOAuth2ClientsOutput {
    type: ResponseType;
    result: GetPbxOAuth2ClientsResult;
}
/**
 * @public
 */
export interface GetPersonalInfoInput {
    extension?: (string)[] | undefined;
    id?: (string)[] | undefined;
    officePhone?: (string)[] | undefined;
    mobilePhone?: (string)[] | undefined;
    name?: (string)[] | undefined;
    email?: (string)[] | undefined;
    role?: (string)[] | undefined;
    dialplan?: (string)[] | undefined;
    faxDialplan?: (string)[] | undefined;
    department?: (string)[] | undefined;
    login?: (string)[] | undefined;
    groupDn?: (string)[] | undefined;
    pbxDn?: (string)[] | undefined;
    licenseType?: (PbxLicenseType)[] | undefined;
    fields?: (PbxColleaguesQueryField)[] | undefined;
    searchFields?: (PbxColleaguesQueryField)[] | undefined;
    search?: string | undefined;
    sort?: (PbxColleaguesQueryField)[] | undefined;
    start?: number | undefined;
    count?: number | undefined;
    dir?: GetPbxColleaguesDir | undefined;
    searchStrategy?: PbxColleaguesSearchStrategy | undefined;
}
/**
 * @public
 */
export interface GetPersonalInfoOutput {
    type: ResponseType;
    result: PbxColleague;
}
/**
 * @public
 */
export interface ListPbxDepartmentsInput {
}
/**
 * @public
 */
export interface ListPbxGroupsInput {
}
/**
 * @public
 */
export interface PbxGroup {
    /**
     * Example: gid=14082460,o=com0,dc=wildix
     * @public
     */
    dn: string;
    /**
     * Example: 14082460
     * @public
     */
    id: string;
    /**
     * Example: Admin
     * @public
     */
    name: string;
    wcgrp?: string | undefined;
}
/**
 * @public
 */
export interface ListPbxGroupsResult {
    total: number;
    records: (PbxGroup)[];
}
/**
 * @public
 */
export interface ListPbxGroupsOutput {
    type: ResponseType;
    result: ListPbxGroupsResult;
}
/**
 * @public
 */
export interface ListUserActiveCallsInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
}
/**
 * @public
 */
export interface ListUserActiveCallsOutput {
    calls: (Call)[];
}
/**
 * @public
 */
export interface ListUserDevicesInput {
    /**
     * Extension, login or email. Only users with root admin authorization can specify a different user. By default, the authorized user will be used. Optional parameter.
     * @public
     */
    user?: string | undefined;
}
/**
 * @public
 */
export interface ListUserDevicesOutput {
    devices: (UserDevice)[];
    activeDevice: UserDevice;
}
/**
 * @public
 */
export interface NotificationsInput {
    /**
     * Information about the source of the notification. For example, the name of the camera.
     * @public
     */
    from: string;
    /**
     * Type of the alert that is generated.
     * @public
     */
    notificationType: string;
    /**
     * Information about the event. What happened.
     * @public
     */
    event: string;
    /**
     * The message for announcing into a conference.
     * @public
     */
    broadcastMessage: string;
    /**
     * The broadcast ID to which the message will be sent.
     * @public
     */
    broadcastId: string;
    /**
     * How often (each N seconds) a request has to be repeated.
     * @public
     */
    playFrequency?: number | undefined;
    /**
     * How many seconds the request should wait for the confirmation after the start.
     * @public
     */
    confirmationTimeout?: number | undefined;
    /**
     * How many seconds the queued request should wait for starting processing.
     * @public
     */
    queueTimeout?: number | undefined;
    /**
     * Indicates the source of the request.
     * @public
     */
    origin?: string | undefined;
    /**
     * The priority of the notification.
     * @public
     */
    priority?: number | undefined;
    /**
     * The custom request ID.
     * @public
     */
    customRid?: string | undefined;
    /**
     * Skip notification transcribing.
     * @public
     */
    skipTranscribe?: boolean | undefined;
}
/**
 * @public
 */
export interface NotificationsOutputResult {
    requestId: string;
}
/**
 * @public
 */
export interface NotificationsOutput {
    type: ResponseType;
    result: NotificationsOutputResult;
}
/**
 * @public
 */
export interface OriginateInput {
    channel: string;
    exten?: string | undefined;
    context?: string | undefined;
    priority?: string | undefined;
    application?: string | undefined;
    data?: string | undefined;
    timeout?: string | undefined;
    callerid?: string | undefined;
    variable?: string | undefined;
    account?: string | undefined;
    async?: string | undefined;
    actionid?: string | undefined;
}
/**
 * @public
 * @enum
 */
export declare const ResponseResult: {
    readonly SUCCESS: "Success";
};
/**
 * @public
 */
export type ResponseResult = typeof ResponseResult[keyof typeof ResponseResult];
/**
 * @public
 */
export interface OriginateOutput {
    type: ResponseType;
    result: ResponseResult;
}
/**
 * @public
 */
export interface OriginateCallInput {
    /**
     * The phone number.
     * @public
     */
    number: string;
    /**
     * The name
     * @public
     */
    name?: string | undefined;
    /**
     * Date of sending the delayed message. (14/07/2015 15:35)
     * @public
     */
    postpone?: string | undefined;
}
/**
 * @public
 */
export interface OriginateCallOutput {
    type: ResponseType;
    result: ResponseResult;
}
/**
 * @public
 */
export interface ReloadBroadcastsInput {
}
/**
 * @public
 */
export interface ReloadBroadcastsOutput {
    type: ResponseType;
    result: string;
}
/**
 * @public
 */
export interface UpdatePbxOAuth2ClientInput {
    /**
     * Client ID.
     * @public
     */
    id: string;
    /**
     * A name of OAuth2 client.
     * @public
     */
    name: string;
    /**
     * Array of redirect URLs, allowed for this client.
     * @public
     */
    redirectUri: (string)[];
}
/**
 * @public
 */
export interface UpdatePbxOAuth2ClientOutput {
    type: ResponseType;
    result: PbxOAuth2Client;
}
/**
 * @public
 */
export interface PbxDepartment {
    id: string;
    name: string;
    users?: (string)[] | undefined;
    items?: (PbxDepartment)[] | undefined;
}
/**
 * @public
 */
export interface ListPbxDepartmentsResult {
    records: (PbxDepartment)[];
}
/**
 * @public
 */
export interface ListPbxDepartmentsOutput {
    type: ResponseType;
    result: ListPbxDepartmentsResult;
}
