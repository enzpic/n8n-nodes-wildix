import { CallControlAnswerCommandInput, CallControlAnswerCommandOutput } from "../commands/CallControlAnswerCommand";
import { CallControlAttendantTransferCommandInput, CallControlAttendantTransferCommandOutput } from "../commands/CallControlAttendantTransferCommand";
import { CallControlBlindTransferCommandInput, CallControlBlindTransferCommandOutput } from "../commands/CallControlBlindTransferCommand";
import { CallControlDtmfCommandInput, CallControlDtmfCommandOutput } from "../commands/CallControlDtmfCommand";
import { CallControlHangupCommandInput, CallControlHangupCommandOutput } from "../commands/CallControlHangupCommand";
import { CallControlHoldCommandInput, CallControlHoldCommandOutput } from "../commands/CallControlHoldCommand";
import { CallControlMakeCallCommandInput, CallControlMakeCallCommandOutput } from "../commands/CallControlMakeCallCommand";
import { CallControlUnholdCommandInput, CallControlUnholdCommandOutput } from "../commands/CallControlUnholdCommand";
import { CallControlUpdateContactInfoCommandInput, CallControlUpdateContactInfoCommandOutput } from "../commands/CallControlUpdateContactInfoCommand";
import { CreatePbxAclGroupCommandInput, CreatePbxAclGroupCommandOutput } from "../commands/CreatePbxAclGroupCommand";
import { CreatePbxColleagueCommandInput, CreatePbxColleagueCommandOutput } from "../commands/CreatePbxColleagueCommand";
import { CreatePbxOAuth2ClientCommandInput, CreatePbxOAuth2ClientCommandOutput } from "../commands/CreatePbxOAuth2ClientCommand";
import { DeletePbxAclGroupCommandInput, DeletePbxAclGroupCommandOutput } from "../commands/DeletePbxAclGroupCommand";
import { DeletePbxColleagueCommandInput, DeletePbxColleagueCommandOutput } from "../commands/DeletePbxColleagueCommand";
import { DeletePbxOAuth2ClientCommandInput, DeletePbxOAuth2ClientCommandOutput } from "../commands/DeletePbxOAuth2ClientCommand";
import { GetCallQueuesSettingsCommandInput, GetCallQueuesSettingsCommandOutput } from "../commands/GetCallQueuesSettingsCommand";
import { GetColleagueByIdCommandInput, GetColleagueByIdCommandOutput } from "../commands/GetColleagueByIdCommand";
import { GetPbxAclGroupsPermissionsCommandInput, GetPbxAclGroupsPermissionsCommandOutput } from "../commands/GetPbxAclGroupsPermissionsCommand";
import { GetPbxCallGroupsCommandInput, GetPbxCallGroupsCommandOutput } from "../commands/GetPbxCallGroupsCommand";
import { GetPbxColleaguesCommandInput, GetPbxColleaguesCommandOutput } from "../commands/GetPbxColleaguesCommand";
import { GetPbxOAuth2ClientsCommandInput, GetPbxOAuth2ClientsCommandOutput } from "../commands/GetPbxOAuth2ClientsCommand";
import { GetPbxesCommandInput, GetPbxesCommandOutput } from "../commands/GetPbxesCommand";
import { GetPersonalInfoCommandInput, GetPersonalInfoCommandOutput } from "../commands/GetPersonalInfoCommand";
import { ListPbxDepartmentsCommandInput, ListPbxDepartmentsCommandOutput } from "../commands/ListPbxDepartmentsCommand";
import { ListPbxGroupsCommandInput, ListPbxGroupsCommandOutput } from "../commands/ListPbxGroupsCommand";
import { ListUserActiveCallsCommandInput, ListUserActiveCallsCommandOutput } from "../commands/ListUserActiveCallsCommand";
import { ListUserDevicesCommandInput, ListUserDevicesCommandOutput } from "../commands/ListUserDevicesCommand";
import { NotificationsCommandInput, NotificationsCommandOutput } from "../commands/NotificationsCommand";
import { OriginateCallCommandInput, OriginateCallCommandOutput } from "../commands/OriginateCallCommand";
import { OriginateCommandInput, OriginateCommandOutput } from "../commands/OriginateCommand";
import { ReloadBroadcastsCommandInput, ReloadBroadcastsCommandOutput } from "../commands/ReloadBroadcastsCommand";
import { UpdatePbxOAuth2ClientCommandInput, UpdatePbxOAuth2ClientCommandOutput } from "../commands/UpdatePbxOAuth2ClientCommand";
import { HttpRequest as __HttpRequest, HttpResponse as __HttpResponse } from "@smithy/protocol-http";
import { SerdeContext as __SerdeContext } from "@smithy/types";
/**
 * serializeAws_restJson1CallControlAnswerCommand
 */
export declare const se_CallControlAnswerCommand: (input: CallControlAnswerCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CallControlAttendantTransferCommand
 */
export declare const se_CallControlAttendantTransferCommand: (input: CallControlAttendantTransferCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CallControlBlindTransferCommand
 */
export declare const se_CallControlBlindTransferCommand: (input: CallControlBlindTransferCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CallControlDtmfCommand
 */
export declare const se_CallControlDtmfCommand: (input: CallControlDtmfCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CallControlHangupCommand
 */
export declare const se_CallControlHangupCommand: (input: CallControlHangupCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CallControlHoldCommand
 */
export declare const se_CallControlHoldCommand: (input: CallControlHoldCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CallControlMakeCallCommand
 */
export declare const se_CallControlMakeCallCommand: (input: CallControlMakeCallCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CallControlUnholdCommand
 */
export declare const se_CallControlUnholdCommand: (input: CallControlUnholdCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CallControlUpdateContactInfoCommand
 */
export declare const se_CallControlUpdateContactInfoCommand: (input: CallControlUpdateContactInfoCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CreatePbxAclGroupCommand
 */
export declare const se_CreatePbxAclGroupCommand: (input: CreatePbxAclGroupCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CreatePbxColleagueCommand
 */
export declare const se_CreatePbxColleagueCommand: (input: CreatePbxColleagueCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CreatePbxOAuth2ClientCommand
 */
export declare const se_CreatePbxOAuth2ClientCommand: (input: CreatePbxOAuth2ClientCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1DeletePbxAclGroupCommand
 */
export declare const se_DeletePbxAclGroupCommand: (input: DeletePbxAclGroupCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1DeletePbxColleagueCommand
 */
export declare const se_DeletePbxColleagueCommand: (input: DeletePbxColleagueCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1DeletePbxOAuth2ClientCommand
 */
export declare const se_DeletePbxOAuth2ClientCommand: (input: DeletePbxOAuth2ClientCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetCallQueuesSettingsCommand
 */
export declare const se_GetCallQueuesSettingsCommand: (input: GetCallQueuesSettingsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetColleagueByIdCommand
 */
export declare const se_GetColleagueByIdCommand: (input: GetColleagueByIdCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetPbxAclGroupsPermissionsCommand
 */
export declare const se_GetPbxAclGroupsPermissionsCommand: (input: GetPbxAclGroupsPermissionsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetPbxCallGroupsCommand
 */
export declare const se_GetPbxCallGroupsCommand: (input: GetPbxCallGroupsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetPbxColleaguesCommand
 */
export declare const se_GetPbxColleaguesCommand: (input: GetPbxColleaguesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetPbxesCommand
 */
export declare const se_GetPbxesCommand: (input: GetPbxesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetPbxOAuth2ClientsCommand
 */
export declare const se_GetPbxOAuth2ClientsCommand: (input: GetPbxOAuth2ClientsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetPersonalInfoCommand
 */
export declare const se_GetPersonalInfoCommand: (input: GetPersonalInfoCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListPbxDepartmentsCommand
 */
export declare const se_ListPbxDepartmentsCommand: (input: ListPbxDepartmentsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListPbxGroupsCommand
 */
export declare const se_ListPbxGroupsCommand: (input: ListPbxGroupsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListUserActiveCallsCommand
 */
export declare const se_ListUserActiveCallsCommand: (input: ListUserActiveCallsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListUserDevicesCommand
 */
export declare const se_ListUserDevicesCommand: (input: ListUserDevicesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1NotificationsCommand
 */
export declare const se_NotificationsCommand: (input: NotificationsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1OriginateCommand
 */
export declare const se_OriginateCommand: (input: OriginateCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1OriginateCallCommand
 */
export declare const se_OriginateCallCommand: (input: OriginateCallCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ReloadBroadcastsCommand
 */
export declare const se_ReloadBroadcastsCommand: (input: ReloadBroadcastsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1UpdatePbxOAuth2ClientCommand
 */
export declare const se_UpdatePbxOAuth2ClientCommand: (input: UpdatePbxOAuth2ClientCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * deserializeAws_restJson1CallControlAnswerCommand
 */
export declare const de_CallControlAnswerCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CallControlAnswerCommandOutput>;
/**
 * deserializeAws_restJson1CallControlAttendantTransferCommand
 */
export declare const de_CallControlAttendantTransferCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CallControlAttendantTransferCommandOutput>;
/**
 * deserializeAws_restJson1CallControlBlindTransferCommand
 */
export declare const de_CallControlBlindTransferCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CallControlBlindTransferCommandOutput>;
/**
 * deserializeAws_restJson1CallControlDtmfCommand
 */
export declare const de_CallControlDtmfCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CallControlDtmfCommandOutput>;
/**
 * deserializeAws_restJson1CallControlHangupCommand
 */
export declare const de_CallControlHangupCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CallControlHangupCommandOutput>;
/**
 * deserializeAws_restJson1CallControlHoldCommand
 */
export declare const de_CallControlHoldCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CallControlHoldCommandOutput>;
/**
 * deserializeAws_restJson1CallControlMakeCallCommand
 */
export declare const de_CallControlMakeCallCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CallControlMakeCallCommandOutput>;
/**
 * deserializeAws_restJson1CallControlUnholdCommand
 */
export declare const de_CallControlUnholdCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CallControlUnholdCommandOutput>;
/**
 * deserializeAws_restJson1CallControlUpdateContactInfoCommand
 */
export declare const de_CallControlUpdateContactInfoCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CallControlUpdateContactInfoCommandOutput>;
/**
 * deserializeAws_restJson1CreatePbxAclGroupCommand
 */
export declare const de_CreatePbxAclGroupCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreatePbxAclGroupCommandOutput>;
/**
 * deserializeAws_restJson1CreatePbxColleagueCommand
 */
export declare const de_CreatePbxColleagueCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreatePbxColleagueCommandOutput>;
/**
 * deserializeAws_restJson1CreatePbxOAuth2ClientCommand
 */
export declare const de_CreatePbxOAuth2ClientCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreatePbxOAuth2ClientCommandOutput>;
/**
 * deserializeAws_restJson1DeletePbxAclGroupCommand
 */
export declare const de_DeletePbxAclGroupCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeletePbxAclGroupCommandOutput>;
/**
 * deserializeAws_restJson1DeletePbxColleagueCommand
 */
export declare const de_DeletePbxColleagueCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeletePbxColleagueCommandOutput>;
/**
 * deserializeAws_restJson1DeletePbxOAuth2ClientCommand
 */
export declare const de_DeletePbxOAuth2ClientCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeletePbxOAuth2ClientCommandOutput>;
/**
 * deserializeAws_restJson1GetCallQueuesSettingsCommand
 */
export declare const de_GetCallQueuesSettingsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetCallQueuesSettingsCommandOutput>;
/**
 * deserializeAws_restJson1GetColleagueByIdCommand
 */
export declare const de_GetColleagueByIdCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetColleagueByIdCommandOutput>;
/**
 * deserializeAws_restJson1GetPbxAclGroupsPermissionsCommand
 */
export declare const de_GetPbxAclGroupsPermissionsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetPbxAclGroupsPermissionsCommandOutput>;
/**
 * deserializeAws_restJson1GetPbxCallGroupsCommand
 */
export declare const de_GetPbxCallGroupsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetPbxCallGroupsCommandOutput>;
/**
 * deserializeAws_restJson1GetPbxColleaguesCommand
 */
export declare const de_GetPbxColleaguesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetPbxColleaguesCommandOutput>;
/**
 * deserializeAws_restJson1GetPbxesCommand
 */
export declare const de_GetPbxesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetPbxesCommandOutput>;
/**
 * deserializeAws_restJson1GetPbxOAuth2ClientsCommand
 */
export declare const de_GetPbxOAuth2ClientsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetPbxOAuth2ClientsCommandOutput>;
/**
 * deserializeAws_restJson1GetPersonalInfoCommand
 */
export declare const de_GetPersonalInfoCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetPersonalInfoCommandOutput>;
/**
 * deserializeAws_restJson1ListPbxDepartmentsCommand
 */
export declare const de_ListPbxDepartmentsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListPbxDepartmentsCommandOutput>;
/**
 * deserializeAws_restJson1ListPbxGroupsCommand
 */
export declare const de_ListPbxGroupsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListPbxGroupsCommandOutput>;
/**
 * deserializeAws_restJson1ListUserActiveCallsCommand
 */
export declare const de_ListUserActiveCallsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListUserActiveCallsCommandOutput>;
/**
 * deserializeAws_restJson1ListUserDevicesCommand
 */
export declare const de_ListUserDevicesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListUserDevicesCommandOutput>;
/**
 * deserializeAws_restJson1NotificationsCommand
 */
export declare const de_NotificationsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<NotificationsCommandOutput>;
/**
 * deserializeAws_restJson1OriginateCommand
 */
export declare const de_OriginateCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<OriginateCommandOutput>;
/**
 * deserializeAws_restJson1OriginateCallCommand
 */
export declare const de_OriginateCallCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<OriginateCallCommandOutput>;
/**
 * deserializeAws_restJson1ReloadBroadcastsCommand
 */
export declare const de_ReloadBroadcastsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ReloadBroadcastsCommandOutput>;
/**
 * deserializeAws_restJson1UpdatePbxOAuth2ClientCommand
 */
export declare const de_UpdatePbxOAuth2ClientCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UpdatePbxOAuth2ClientCommandOutput>;
