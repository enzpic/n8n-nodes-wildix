import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { NotificationsInput, NotificationsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link NotificationsCommand}.
 */
export interface NotificationsCommandInput extends NotificationsInput {
}
/**
 * @public
 *
 * The output of {@link NotificationsCommand}.
 */
export interface NotificationsCommandOutput extends NotificationsOutput, __MetadataBearer {
}
declare const NotificationsCommand_base: {
    new (input: NotificationsCommandInput): import("@smithy/smithy-client").CommandImpl<NotificationsCommandInput, NotificationsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: NotificationsCommandInput): import("@smithy/smithy-client").CommandImpl<NotificationsCommandInput, NotificationsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Notifications
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, NotificationsCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, NotificationsCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // NotificationsInput
 *   from: "STRING_VALUE", // required
 *   notificationType: "STRING_VALUE", // required
 *   event: "STRING_VALUE", // required
 *   broadcastMessage: "STRING_VALUE", // required
 *   broadcastId: "STRING_VALUE", // required
 *   playFrequency: Number("int"),
 *   confirmationTimeout: Number("int"),
 *   queueTimeout: Number("int"),
 *   origin: "STRING_VALUE",
 *   priority: Number("int"),
 *   customRid: "STRING_VALUE",
 *   skipTranscribe: true || false,
 * };
 * const command = new NotificationsCommand(input);
 * const response = await client.send(command);
 * // { // NotificationsOutput
 * //   type: "result" || "error", // required
 * //   result: { // NotificationsOutputResult
 * //     requestId: "STRING_VALUE", // required
 * //   },
 * // };
 *
 * ```
 *
 * @param NotificationsCommandInput - {@link NotificationsCommandInput}
 * @returns {@link NotificationsCommandOutput}
 * @see {@link NotificationsCommandInput} for command's `input` shape.
 * @see {@link NotificationsCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class NotificationsCommand extends NotificationsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: NotificationsInput;
            output: NotificationsOutput;
        };
        sdk: {
            input: NotificationsCommandInput;
            output: NotificationsCommandOutput;
        };
    };
}
