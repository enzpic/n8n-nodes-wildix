import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CallControlUnholdInput, CallControlUnholdOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CallControlUnholdCommand}.
 */
export interface CallControlUnholdCommandInput extends CallControlUnholdInput {
}
/**
 * @public
 *
 * The output of {@link CallControlUnholdCommand}.
 */
export interface CallControlUnholdCommandOutput extends CallControlUnholdOutput, __MetadataBearer {
}
declare const CallControlUnholdCommand_base: {
    new (input: CallControlUnholdCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlUnholdCommandInput, CallControlUnholdCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CallControlUnholdCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlUnholdCommandInput, CallControlUnholdCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CallControlUnholdCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CallControlUnholdCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CallControlUnholdInput
 *   user: "STRING_VALUE",
 *   sipCallId: "STRING_VALUE", // required
 * };
 * const command = new CallControlUnholdCommand(input);
 * const response = await client.send(command);
 * // { // CallControlUnholdOutput
 * //   message: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param CallControlUnholdCommandInput - {@link CallControlUnholdCommandInput}
 * @returns {@link CallControlUnholdCommandOutput}
 * @see {@link CallControlUnholdCommandInput} for command's `input` shape.
 * @see {@link CallControlUnholdCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link ChannelNotFoundException} (client fault)
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CallControlUnholdCommand extends CallControlUnholdCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CallControlUnholdInput;
            output: CallControlUnholdOutput;
        };
        sdk: {
            input: CallControlUnholdCommandInput;
            output: CallControlUnholdCommandOutput;
        };
    };
}
