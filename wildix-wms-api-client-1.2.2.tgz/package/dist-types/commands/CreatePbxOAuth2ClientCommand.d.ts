import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CreatePbxOAuth2ClientInput, CreatePbxOAuth2ClientOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CreatePbxOAuth2ClientCommand}.
 */
export interface CreatePbxOAuth2ClientCommandInput extends CreatePbxOAuth2ClientInput {
}
/**
 * @public
 *
 * The output of {@link CreatePbxOAuth2ClientCommand}.
 */
export interface CreatePbxOAuth2ClientCommandOutput extends CreatePbxOAuth2ClientOutput, __MetadataBearer {
}
declare const CreatePbxOAuth2ClientCommand_base: {
    new (input: CreatePbxOAuth2ClientCommandInput): import("@smithy/smithy-client").CommandImpl<CreatePbxOAuth2ClientCommandInput, CreatePbxOAuth2ClientCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CreatePbxOAuth2ClientCommandInput): import("@smithy/smithy-client").CommandImpl<CreatePbxOAuth2ClientCommandInput, CreatePbxOAuth2ClientCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Create new OAuth2 client in the PBX.
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CreatePbxOAuth2ClientCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CreatePbxOAuth2ClientCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CreatePbxOAuth2ClientInput
 *   name: "STRING_VALUE", // required
 *   redirectUri: [ // PbxOAuth2RedirectUrls // required
 *     "STRING_VALUE",
 *   ],
 *   expireTime: Number("int"), // required
 * };
 * const command = new CreatePbxOAuth2ClientCommand(input);
 * const response = await client.send(command);
 * // { // CreatePbxOAuth2ClientOutput
 * //   type: "result" || "error", // required
 * //   result: { // PbxOAuth2Client
 * //     id: "STRING_VALUE", // required
 * //     name: "STRING_VALUE", // required
 * //     redirectUri: [ // PbxOAuth2RedirectUrls // required
 * //       "STRING_VALUE",
 * //     ],
 * //     secret: "STRING_VALUE", // required
 * //     created: Number("int"), // required
 * //     origins: [ // PbxOAuth2Origins // required
 * //       "STRING_VALUE",
 * //     ],
 * //     accessTokenTtl: Number("int"), // required
 * //   },
 * // };
 *
 * ```
 *
 * @param CreatePbxOAuth2ClientCommandInput - {@link CreatePbxOAuth2ClientCommandInput}
 * @returns {@link CreatePbxOAuth2ClientCommandOutput}
 * @see {@link CreatePbxOAuth2ClientCommandInput} for command's `input` shape.
 * @see {@link CreatePbxOAuth2ClientCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsValidationException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class CreatePbxOAuth2ClientCommand extends CreatePbxOAuth2ClientCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CreatePbxOAuth2ClientInput;
            output: CreatePbxOAuth2ClientOutput;
        };
        sdk: {
            input: CreatePbxOAuth2ClientCommandInput;
            output: CreatePbxOAuth2ClientCommandOutput;
        };
    };
}
