import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CallControlHoldInput, CallControlHoldOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CallControlHoldCommand}.
 */
export interface CallControlHoldCommandInput extends CallControlHoldInput {
}
/**
 * @public
 *
 * The output of {@link CallControlHoldCommand}.
 */
export interface CallControlHoldCommandOutput extends CallControlHoldOutput, __MetadataBearer {
}
declare const CallControlHoldCommand_base: {
    new (input: CallControlHoldCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlHoldCommandInput, CallControlHoldCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CallControlHoldCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlHoldCommandInput, CallControlHoldCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CallControlHoldCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CallControlHoldCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CallControlHoldInput
 *   user: "STRING_VALUE",
 *   sipCallId: "STRING_VALUE", // required
 * };
 * const command = new CallControlHoldCommand(input);
 * const response = await client.send(command);
 * // { // CallControlHoldOutput
 * //   message: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param CallControlHoldCommandInput - {@link CallControlHoldCommandInput}
 * @returns {@link CallControlHoldCommandOutput}
 * @see {@link CallControlHoldCommandInput} for command's `input` shape.
 * @see {@link CallControlHoldCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link ChannelNotFoundException} (client fault)
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CallControlHoldCommand extends CallControlHoldCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CallControlHoldInput;
            output: CallControlHoldOutput;
        };
        sdk: {
            input: CallControlHoldCommandInput;
            output: CallControlHoldCommandOutput;
        };
    };
}
