import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CreatePbxColleagueInput, CreatePbxColleagueOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CreatePbxColleagueCommand}.
 */
export interface CreatePbxColleagueCommandInput extends CreatePbxColleagueInput {
}
/**
 * @public
 *
 * The output of {@link CreatePbxColleagueCommand}.
 */
export interface CreatePbxColleagueCommandOutput extends CreatePbxColleagueOutput, __MetadataBearer {
}
declare const CreatePbxColleagueCommand_base: {
    new (input: CreatePbxColleagueCommandInput): import("@smithy/smithy-client").CommandImpl<CreatePbxColleagueCommandInput, CreatePbxColleagueCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CreatePbxColleagueCommandInput): import("@smithy/smithy-client").CommandImpl<CreatePbxColleagueCommandInput, CreatePbxColleagueCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CreatePbxColleagueCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CreatePbxColleagueCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CreatePbxColleagueInput
 *   extension: "STRING_VALUE", // required
 *   name: "STRING_VALUE", // required
 *   officePhone: "STRING_VALUE",
 *   mobilePhone: "STRING_VALUE",
 *   faxNumber: "STRING_VALUE",
 *   email: "STRING_VALUE",
 *   role: "admin" || "user" || "fax" || "park_orbit" || "room",
 *   groupDn: "STRING_VALUE",
 *   language: "STRING_VALUE",
 *   dialplan: "STRING_VALUE",
 *   faxDialplan: "STRING_VALUE",
 *   department: "STRING_VALUE",
 *   login: "STRING_VALUE",
 *   password: "STRING_VALUE",
 *   sipPassword: "STRING_VALUE",
 *   licenseType: "basic" || "essential" || "business" || "premium" || "wizyconf",
 * };
 * const command = new CreatePbxColleagueCommand(input);
 * const response = await client.send(command);
 * // { // CreatePbxColleagueOutput
 * //   type: "result" || "error", // required
 * //   result: { // PbxColleague
 * //     id: "STRING_VALUE", // required
 * //     name: "STRING_VALUE",
 * //     login: "STRING_VALUE",
 * //     extension: "STRING_VALUE", // required
 * //     officePhone: "STRING_VALUE",
 * //     mobilePhone: "STRING_VALUE",
 * //     faxNumber: "STRING_VALUE",
 * //     email: "STRING_VALUE",
 * //     pbxDn: "STRING_VALUE", // required
 * //     pbx: "STRING_VALUE", // required
 * //     role: "admin" || "user" || "fax" || "park_orbit" || "room", // required
 * //     groupName: "STRING_VALUE", // required
 * //     groupDn: "STRING_VALUE", // required
 * //     language: "STRING_VALUE", // required
 * //     dialplan: "STRING_VALUE", // required
 * //     faxDialplan: "STRING_VALUE", // required
 * //     department: "STRING_VALUE",
 * //     picture: "STRING_VALUE", // required
 * //     sourceId: "STRING_VALUE",
 * //     licenseType: "basic" || "essential" || "business" || "premium" || "wizyconf", // required
 * //     jid: "STRING_VALUE", // required
 * //   },
 * // };
 *
 * ```
 *
 * @param CreatePbxColleagueCommandInput - {@link CreatePbxColleagueCommandInput}
 * @returns {@link CreatePbxColleagueCommandOutput}
 * @see {@link CreatePbxColleagueCommandInput} for command's `input` shape.
 * @see {@link CreatePbxColleagueCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CreatePbxColleagueCommand extends CreatePbxColleagueCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CreatePbxColleagueInput;
            output: CreatePbxColleagueOutput;
        };
        sdk: {
            input: CreatePbxColleagueCommandInput;
            output: CreatePbxColleagueCommandOutput;
        };
    };
}
