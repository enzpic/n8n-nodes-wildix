import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { OriginateCallInput, OriginateCallOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link OriginateCallCommand}.
 */
export interface OriginateCallCommandInput extends OriginateCallInput {
}
/**
 * @public
 *
 * The output of {@link OriginateCallCommand}.
 */
export interface OriginateCallCommandOutput extends OriginateCallOutput, __MetadataBearer {
}
declare const OriginateCallCommand_base: {
    new (input: OriginateCallCommandInput): import("@smithy/smithy-client").CommandImpl<OriginateCallCommandInput, OriginateCallCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: OriginateCallCommandInput): import("@smithy/smithy-client").CommandImpl<OriginateCallCommandInput, OriginateCallCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Originate call
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, OriginateCallCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, OriginateCallCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // OriginateCallInput
 *   number: "STRING_VALUE", // required
 *   name: "STRING_VALUE",
 *   postpone: "STRING_VALUE",
 * };
 * const command = new OriginateCallCommand(input);
 * const response = await client.send(command);
 * // { // OriginateCallOutput
 * //   type: "result" || "error", // required
 * //   result: "Success", // required
 * // };
 *
 * ```
 *
 * @param OriginateCallCommandInput - {@link OriginateCallCommandInput}
 * @returns {@link OriginateCallCommandOutput}
 * @see {@link OriginateCallCommandInput} for command's `input` shape.
 * @see {@link OriginateCallCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class OriginateCallCommand extends OriginateCallCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: OriginateCallInput;
            output: OriginateCallOutput;
        };
        sdk: {
            input: OriginateCallCommandInput;
            output: OriginateCallCommandOutput;
        };
    };
}
