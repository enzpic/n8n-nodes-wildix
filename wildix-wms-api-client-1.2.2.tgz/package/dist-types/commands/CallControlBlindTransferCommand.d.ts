import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CallControlBlindTransferInput, CallControlBlindTransferOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CallControlBlindTransferCommand}.
 */
export interface CallControlBlindTransferCommandInput extends CallControlBlindTransferInput {
}
/**
 * @public
 *
 * The output of {@link CallControlBlindTransferCommand}.
 */
export interface CallControlBlindTransferCommandOutput extends CallControlBlindTransferOutput, __MetadataBearer {
}
declare const CallControlBlindTransferCommand_base: {
    new (input: CallControlBlindTransferCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlBlindTransferCommandInput, CallControlBlindTransferCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CallControlBlindTransferCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlBlindTransferCommandInput, CallControlBlindTransferCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CallControlBlindTransferCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CallControlBlindTransferCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CallControlBlindTransferInput
 *   user: "STRING_VALUE",
 *   sipCallId: "STRING_VALUE", // required
 *   destination: "STRING_VALUE", // required
 * };
 * const command = new CallControlBlindTransferCommand(input);
 * const response = await client.send(command);
 * // { // CallControlBlindTransferOutput
 * //   message: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param CallControlBlindTransferCommandInput - {@link CallControlBlindTransferCommandInput}
 * @returns {@link CallControlBlindTransferCommandOutput}
 * @see {@link CallControlBlindTransferCommandInput} for command's `input` shape.
 * @see {@link CallControlBlindTransferCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link ChannelNotFoundException} (client fault)
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CallControlBlindTransferCommand extends CallControlBlindTransferCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CallControlBlindTransferInput;
            output: CallControlBlindTransferOutput;
        };
        sdk: {
            input: CallControlBlindTransferCommandInput;
            output: CallControlBlindTransferCommandOutput;
        };
    };
}
