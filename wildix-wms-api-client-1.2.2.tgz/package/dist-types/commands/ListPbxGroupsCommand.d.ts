import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { ListPbxGroupsInput, ListPbxGroupsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ListPbxGroupsCommand}.
 */
export interface ListPbxGroupsCommandInput extends ListPbxGroupsInput {
}
/**
 * @public
 *
 * The output of {@link ListPbxGroupsCommand}.
 */
export interface ListPbxGroupsCommandOutput extends ListPbxGroupsOutput, __MetadataBearer {
}
declare const ListPbxGroupsCommand_base: {
    new (input: ListPbxGroupsCommandInput): import("@smithy/smithy-client").CommandImpl<ListPbxGroupsCommandInput, ListPbxGroupsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [ListPbxGroupsCommandInput]): import("@smithy/smithy-client").CommandImpl<ListPbxGroupsCommandInput, ListPbxGroupsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, ListPbxGroupsCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, ListPbxGroupsCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = {};
 * const command = new ListPbxGroupsCommand(input);
 * const response = await client.send(command);
 * // { // ListPbxGroupsOutput
 * //   type: "result" || "error", // required
 * //   result: { // ListPbxGroupsResult
 * //     total: Number("int"), // required
 * //     records: [ // PbxGroupsList // required
 * //       { // PbxGroup
 * //         dn: "STRING_VALUE", // required
 * //         id: "STRING_VALUE", // required
 * //         name: "STRING_VALUE", // required
 * //         wcgrp: "STRING_VALUE",
 * //       },
 * //     ],
 * //   },
 * // };
 *
 * ```
 *
 * @param ListPbxGroupsCommandInput - {@link ListPbxGroupsCommandInput}
 * @returns {@link ListPbxGroupsCommandOutput}
 * @see {@link ListPbxGroupsCommandInput} for command's `input` shape.
 * @see {@link ListPbxGroupsCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class ListPbxGroupsCommand extends ListPbxGroupsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: {};
            output: ListPbxGroupsOutput;
        };
        sdk: {
            input: ListPbxGroupsCommandInput;
            output: ListPbxGroupsCommandOutput;
        };
    };
}
