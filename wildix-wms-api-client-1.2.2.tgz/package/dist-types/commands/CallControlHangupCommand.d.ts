import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CallControlHangupInput, CallControlHangupOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CallControlHangupCommand}.
 */
export interface CallControlHangupCommandInput extends CallControlHangupInput {
}
/**
 * @public
 *
 * The output of {@link CallControlHangupCommand}.
 */
export interface CallControlHangupCommandOutput extends CallControlHangupOutput, __MetadataBearer {
}
declare const CallControlHangupCommand_base: {
    new (input: CallControlHangupCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlHangupCommandInput, CallControlHangupCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CallControlHangupCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlHangupCommandInput, CallControlHangupCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CallControlHangupCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CallControlHangupCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CallControlHangupInput
 *   user: "STRING_VALUE",
 *   sipCallId: "STRING_VALUE", // required
 *   reason: "STRING_VALUE",
 * };
 * const command = new CallControlHangupCommand(input);
 * const response = await client.send(command);
 * // { // CallControlHangupOutput
 * //   message: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param CallControlHangupCommandInput - {@link CallControlHangupCommandInput}
 * @returns {@link CallControlHangupCommandOutput}
 * @see {@link CallControlHangupCommandInput} for command's `input` shape.
 * @see {@link CallControlHangupCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link ChannelNotFoundException} (client fault)
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CallControlHangupCommand extends CallControlHangupCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CallControlHangupInput;
            output: CallControlHangupOutput;
        };
        sdk: {
            input: CallControlHangupCommandInput;
            output: CallControlHangupCommandOutput;
        };
    };
}
