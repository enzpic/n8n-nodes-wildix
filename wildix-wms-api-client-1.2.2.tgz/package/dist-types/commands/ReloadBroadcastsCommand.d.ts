import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { ReloadBroadcastsInput, ReloadBroadcastsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ReloadBroadcastsCommand}.
 */
export interface ReloadBroadcastsCommandInput extends ReloadBroadcastsInput {
}
/**
 * @public
 *
 * The output of {@link ReloadBroadcastsCommand}.
 */
export interface ReloadBroadcastsCommandOutput extends ReloadBroadcastsOutput, __MetadataBearer {
}
declare const ReloadBroadcastsCommand_base: {
    new (input: ReloadBroadcastsCommandInput): import("@smithy/smithy-client").CommandImpl<ReloadBroadcastsCommandInput, ReloadBroadcastsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [ReloadBroadcastsCommandInput]): import("@smithy/smithy-client").CommandImpl<ReloadBroadcastsCommandInput, ReloadBroadcastsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Clear cache for broadcasts
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, ReloadBroadcastsCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, ReloadBroadcastsCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = {};
 * const command = new ReloadBroadcastsCommand(input);
 * const response = await client.send(command);
 * // { // ReloadBroadcastsOutput
 * //   type: "result" || "error", // required
 * //   result: "STRING_VALUE", // required
 * // };
 *
 * ```
 *
 * @param ReloadBroadcastsCommandInput - {@link ReloadBroadcastsCommandInput}
 * @returns {@link ReloadBroadcastsCommandOutput}
 * @see {@link ReloadBroadcastsCommandInput} for command's `input` shape.
 * @see {@link ReloadBroadcastsCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class ReloadBroadcastsCommand extends ReloadBroadcastsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: {};
            output: ReloadBroadcastsOutput;
        };
        sdk: {
            input: ReloadBroadcastsCommandInput;
            output: ReloadBroadcastsCommandOutput;
        };
    };
}
