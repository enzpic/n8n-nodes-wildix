import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { GetPbxAclGroupsPermissionsInput, GetPbxAclGroupsPermissionsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetPbxAclGroupsPermissionsCommand}.
 */
export interface GetPbxAclGroupsPermissionsCommandInput extends GetPbxAclGroupsPermissionsInput {
}
/**
 * @public
 *
 * The output of {@link GetPbxAclGroupsPermissionsCommand}.
 */
export interface GetPbxAclGroupsPermissionsCommandOutput extends GetPbxAclGroupsPermissionsOutput, __MetadataBearer {
}
declare const GetPbxAclGroupsPermissionsCommand_base: {
    new (input: GetPbxAclGroupsPermissionsCommandInput): import("@smithy/smithy-client").CommandImpl<GetPbxAclGroupsPermissionsCommandInput, GetPbxAclGroupsPermissionsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [GetPbxAclGroupsPermissionsCommandInput]): import("@smithy/smithy-client").CommandImpl<GetPbxAclGroupsPermissionsCommandInput, GetPbxAclGroupsPermissionsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, GetPbxAclGroupsPermissionsCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, GetPbxAclGroupsPermissionsCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // GetPbxAclGroupsPermissionsInput
 *   groups: [ // FilterList
 *     "STRING_VALUE",
 *   ],
 *   permissions: [
 *     "STRING_VALUE",
 *   ],
 * };
 * const command = new GetPbxAclGroupsPermissionsCommand(input);
 * const response = await client.send(command);
 * // { // GetPbxAclGroupsPermissionsOutput
 * //   type: "result" || "error", // required
 * //   result: [ // GetPbxAclGroupsPermissionsResult // required
 * //     { // AclGroupPermission
 * //       ability: "use" || "nouse" || "can" || "cannot" || "yes" || "no", // required
 * //       key: "STRING_VALUE", // required
 * //       name: "STRING_VALUE", // required
 * //       containSubGroups: true || false, // required
 * //       groups: [ // AclGroupPermissionItemsList // required
 * //         { // AclGroupPermissionItem
 * //           groupDn: "STRING_VALUE", // required
 * //           groupName: "STRING_VALUE", // required
 * //           access: true || false, // required
 * //           subGroups: [ // AclGroupPermissionFlatItemList // required
 * //             { // AclGroupPermissionFlatItem
 * //               groupDn: "STRING_VALUE", // required
 * //               groupName: "STRING_VALUE", // required
 * //               access: true || false, // required
 * //             },
 * //           ],
 * //         },
 * //       ],
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param GetPbxAclGroupsPermissionsCommandInput - {@link GetPbxAclGroupsPermissionsCommandInput}
 * @returns {@link GetPbxAclGroupsPermissionsCommandOutput}
 * @see {@link GetPbxAclGroupsPermissionsCommandInput} for command's `input` shape.
 * @see {@link GetPbxAclGroupsPermissionsCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class GetPbxAclGroupsPermissionsCommand extends GetPbxAclGroupsPermissionsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: GetPbxAclGroupsPermissionsInput;
            output: GetPbxAclGroupsPermissionsOutput;
        };
        sdk: {
            input: GetPbxAclGroupsPermissionsCommandInput;
            output: GetPbxAclGroupsPermissionsCommandOutput;
        };
    };
}
