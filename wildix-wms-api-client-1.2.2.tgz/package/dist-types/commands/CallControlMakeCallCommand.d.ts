import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CallControlMakeCallInput, CallControlMakeCallOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CallControlMakeCallCommand}.
 */
export interface CallControlMakeCallCommandInput extends CallControlMakeCallInput {
}
/**
 * @public
 *
 * The output of {@link CallControlMakeCallCommand}.
 */
export interface CallControlMakeCallCommandOutput extends CallControlMakeCallOutput, __MetadataBearer {
}
declare const CallControlMakeCallCommand_base: {
    new (input: CallControlMakeCallCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlMakeCallCommandInput, CallControlMakeCallCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CallControlMakeCallCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlMakeCallCommandInput, CallControlMakeCallCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CallControlMakeCallCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CallControlMakeCallCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CallControlMakeCallInput
 *   user: "STRING_VALUE",
 *   destination: "STRING_VALUE", // required
 *   device: "STRING_VALUE",
 * };
 * const command = new CallControlMakeCallCommand(input);
 * const response = await client.send(command);
 * // { // CallControlMakeCallOutput
 * //   message: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param CallControlMakeCallCommandInput - {@link CallControlMakeCallCommandInput}
 * @returns {@link CallControlMakeCallCommandOutput}
 * @see {@link CallControlMakeCallCommandInput} for command's `input` shape.
 * @see {@link CallControlMakeCallCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CallControlMakeCallCommand extends CallControlMakeCallCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CallControlMakeCallInput;
            output: CallControlMakeCallOutput;
        };
        sdk: {
            input: CallControlMakeCallCommandInput;
            output: CallControlMakeCallCommandOutput;
        };
    };
}
