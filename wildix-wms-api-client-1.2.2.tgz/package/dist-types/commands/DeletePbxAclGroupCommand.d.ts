import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { DeletePbxAclGroupInput, DeletePbxAclGroupOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link DeletePbxAclGroupCommand}.
 */
export interface DeletePbxAclGroupCommandInput extends DeletePbxAclGroupInput {
}
/**
 * @public
 *
 * The output of {@link DeletePbxAclGroupCommand}.
 */
export interface DeletePbxAclGroupCommandOutput extends DeletePbxAclGroupOutput, __MetadataBearer {
}
declare const DeletePbxAclGroupCommand_base: {
    new (input: DeletePbxAclGroupCommandInput): import("@smithy/smithy-client").CommandImpl<DeletePbxAclGroupCommandInput, DeletePbxAclGroupCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: DeletePbxAclGroupCommandInput): import("@smithy/smithy-client").CommandImpl<DeletePbxAclGroupCommandInput, DeletePbxAclGroupCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, DeletePbxAclGroupCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, DeletePbxAclGroupCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // DeletePbxAclGroupInput
 *   id: Number("int"), // required
 * };
 * const command = new DeletePbxAclGroupCommand(input);
 * const response = await client.send(command);
 * // { // DeletePbxAclGroupOutput
 * //   type: "result" || "error", // required
 * //   result: "STRING_VALUE", // required
 * // };
 *
 * ```
 *
 * @param DeletePbxAclGroupCommandInput - {@link DeletePbxAclGroupCommandInput}
 * @returns {@link DeletePbxAclGroupCommandOutput}
 * @see {@link DeletePbxAclGroupCommandInput} for command's `input` shape.
 * @see {@link DeletePbxAclGroupCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class DeletePbxAclGroupCommand extends DeletePbxAclGroupCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: DeletePbxAclGroupInput;
            output: DeletePbxAclGroupOutput;
        };
        sdk: {
            input: DeletePbxAclGroupCommandInput;
            output: DeletePbxAclGroupCommandOutput;
        };
    };
}
