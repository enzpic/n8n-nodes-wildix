import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CreatePbxAclGroupInput, CreatePbxAclGroupOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CreatePbxAclGroupCommand}.
 */
export interface CreatePbxAclGroupCommandInput extends CreatePbxAclGroupInput {
}
/**
 * @public
 *
 * The output of {@link CreatePbxAclGroupCommand}.
 */
export interface CreatePbxAclGroupCommandOutput extends CreatePbxAclGroupOutput, __MetadataBearer {
}
declare const CreatePbxAclGroupCommand_base: {
    new (input: CreatePbxAclGroupCommandInput): import("@smithy/smithy-client").CommandImpl<CreatePbxAclGroupCommandInput, CreatePbxAclGroupCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CreatePbxAclGroupCommandInput): import("@smithy/smithy-client").CommandImpl<CreatePbxAclGroupCommandInput, CreatePbxAclGroupCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CreatePbxAclGroupCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CreatePbxAclGroupCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CreatePbxAclGroupInput
 *   name: "STRING_VALUE", // required
 *   inherits: "STRING_VALUE",
 *   wcgrp: "STRING_VALUE",
 *   rules: [ // AclGroupRulesList // required
 *     { // AclGroupRule
 *       ability: "use" || "nouse" || "can" || "cannot" || "yes" || "no",
 *       group: "STRING_VALUE",
 *       rule: "STRING_VALUE",
 *     },
 *   ],
 * };
 * const command = new CreatePbxAclGroupCommand(input);
 * const response = await client.send(command);
 * // { // CreatePbxAclGroupOutput
 * //   type: "result" || "error", // required
 * //   result: { // AclGroup
 * //     id: Number("int"), // required
 * //     name: "STRING_VALUE", // required
 * //     dn: "STRING_VALUE", // required
 * //     wcgrp: "STRING_VALUE", // required
 * //     inherits: "STRING_VALUE", // required
 * //     rules: [ // AclGroupRulesList // required
 * //       { // AclGroupRule
 * //         ability: "use" || "nouse" || "can" || "cannot" || "yes" || "no",
 * //         group: "STRING_VALUE",
 * //         rule: "STRING_VALUE",
 * //       },
 * //     ],
 * //     adminRules: "STRING_VALUE", // required
 * //   },
 * // };
 *
 * ```
 *
 * @param CreatePbxAclGroupCommandInput - {@link CreatePbxAclGroupCommandInput}
 * @returns {@link CreatePbxAclGroupCommandOutput}
 * @see {@link CreatePbxAclGroupCommandInput} for command's `input` shape.
 * @see {@link CreatePbxAclGroupCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CreatePbxAclGroupCommand extends CreatePbxAclGroupCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CreatePbxAclGroupInput;
            output: CreatePbxAclGroupOutput;
        };
        sdk: {
            input: CreatePbxAclGroupCommandInput;
            output: CreatePbxAclGroupCommandOutput;
        };
    };
}
