import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { GetPbxesOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetPbxesCommand}.
 */
export interface GetPbxesCommandInput {
}
/**
 * @public
 *
 * The output of {@link GetPbxesCommand}.
 */
export interface GetPbxesCommandOutput extends GetPbxesOutput, __MetadataBearer {
}
declare const GetPbxesCommand_base: {
    new (input: GetPbxesCommandInput): import("@smithy/smithy-client").CommandImpl<GetPbxesCommandInput, GetPbxesCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [GetPbxesCommandInput]): import("@smithy/smithy-client").CommandImpl<GetPbxesCommandInput, GetPbxesCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Get list of PBXes.
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, GetPbxesCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, GetPbxesCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = {};
 * const command = new GetPbxesCommand(input);
 * const response = await client.send(command);
 * // { // GetPbxesOutput
 * //   type: "result" || "error", // required
 * //   result: { // GetPbxesResult
 * //     records: [ // PbxesList // required
 * //       { // Pbx
 * //         ip: "STRING_VALUE", // required
 * //         serial: "STRING_VALUE", // required
 * //         host: "STRING_VALUE", // required
 * //         isServer: true || false, // required
 * //         port: Number("int"), // required
 * //         failOver: "STRING_VALUE", // required
 * //         version: "STRING_VALUE", // required
 * //         isUpdateNeeded: true || false, // required
 * //         dn: "STRING_VALUE", // required
 * //       },
 * //     ],
 * //   },
 * // };
 *
 * ```
 *
 * @param GetPbxesCommandInput - {@link GetPbxesCommandInput}
 * @returns {@link GetPbxesCommandOutput}
 * @see {@link GetPbxesCommandInput} for command's `input` shape.
 * @see {@link GetPbxesCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class GetPbxesCommand extends GetPbxesCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: {};
            output: GetPbxesOutput;
        };
        sdk: {
            input: GetPbxesCommandInput;
            output: GetPbxesCommandOutput;
        };
    };
}
