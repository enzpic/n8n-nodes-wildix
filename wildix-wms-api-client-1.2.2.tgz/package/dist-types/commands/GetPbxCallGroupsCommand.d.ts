import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { GetPbxCallGroupsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetPbxCallGroupsCommand}.
 */
export interface GetPbxCallGroupsCommandInput {
}
/**
 * @public
 *
 * The output of {@link GetPbxCallGroupsCommand}.
 */
export interface GetPbxCallGroupsCommandOutput extends GetPbxCallGroupsOutput, __MetadataBearer {
}
declare const GetPbxCallGroupsCommand_base: {
    new (input: GetPbxCallGroupsCommandInput): import("@smithy/smithy-client").CommandImpl<GetPbxCallGroupsCommandInput, GetPbxCallGroupsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [GetPbxCallGroupsCommandInput]): import("@smithy/smithy-client").CommandImpl<GetPbxCallGroupsCommandInput, GetPbxCallGroupsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Get the list of all available Call groups on the PBX.
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, GetPbxCallGroupsCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, GetPbxCallGroupsCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = {};
 * const command = new GetPbxCallGroupsCommand(input);
 * const response = await client.send(command);
 * // { // GetPbxCallGroupsOutput
 * //   type: "result" || "error", // required
 * //   result: { // GetPbxCallGroupsResult
 * //     records: [ // PbxCallGroupList // required
 * //       { // PbxCallGroup
 * //         id: Number("int"), // required
 * //         title: "STRING_VALUE", // required
 * //         members: [ // PbxCallGroupMembers // required
 * //           "STRING_VALUE",
 * //         ],
 * //         settings: { // PbxCallGroupSettings
 * //           queueManager: "STRING_VALUE",
 * //           cid: "STRING_VALUE",
 * //           autoPause: "STRING_VALUE",
 * //           autoPauseTime: Number("int"),
 * //           autoPauseDelay: Number("int"),
 * //           autoPauseBusy: true || false,
 * //           autoPauseUnAvail: true || false,
 * //           maxLen: Number("int"),
 * //           retry: Number("int"),
 * //           ringInUse: true || false,
 * //           strategy: "STRING_VALUE",
 * //           defaultPriority: Number("int"),
 * //           timeout: Number("int"),
 * //           weight: Number("int"),
 * //           wrapUpTime: Number("int"),
 * //           rule: "STRING_VALUE",
 * //           announce: { // PbxCallGroupAnnounce
 * //             frequency: Number("int"),
 * //             holdTime: "STRING_VALUE",
 * //             roundSeconds: Number("int"),
 * //           },
 * //           exitAllMembers: { // PbxCallGroupExitAllMembers
 * //             busy: true || false,
 * //             paused: true || false,
 * //             ringing: true || false,
 * //           },
 * //           smsNumber: "STRING_VALUE",
 * //         },
 * //       },
 * //     ],
 * //     total: Number("int"), // required
 * //   },
 * // };
 *
 * ```
 *
 * @param GetPbxCallGroupsCommandInput - {@link GetPbxCallGroupsCommandInput}
 * @returns {@link GetPbxCallGroupsCommandOutput}
 * @see {@link GetPbxCallGroupsCommandInput} for command's `input` shape.
 * @see {@link GetPbxCallGroupsCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class GetPbxCallGroupsCommand extends GetPbxCallGroupsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: {};
            output: GetPbxCallGroupsOutput;
        };
        sdk: {
            input: GetPbxCallGroupsCommandInput;
            output: GetPbxCallGroupsCommandOutput;
        };
    };
}
