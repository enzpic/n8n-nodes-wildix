import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { GetCallQueuesSettingsInput, GetCallQueuesSettingsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetCallQueuesSettingsCommand}.
 */
export interface GetCallQueuesSettingsCommandInput extends GetCallQueuesSettingsInput {
}
/**
 * @public
 *
 * The output of {@link GetCallQueuesSettingsCommand}.
 */
export interface GetCallQueuesSettingsCommandOutput extends GetCallQueuesSettingsOutput, __MetadataBearer {
}
declare const GetCallQueuesSettingsCommand_base: {
    new (input: GetCallQueuesSettingsCommandInput): import("@smithy/smithy-client").CommandImpl<GetCallQueuesSettingsCommandInput, GetCallQueuesSettingsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: GetCallQueuesSettingsCommandInput): import("@smithy/smithy-client").CommandImpl<GetCallQueuesSettingsCommandInput, GetCallQueuesSettingsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Get the settings of a specific Call group on the PBX.
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, GetCallQueuesSettingsCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, GetCallQueuesSettingsCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // GetCallQueuesSettingsInput
 *   groupId: Number("int"), // required
 * };
 * const command = new GetCallQueuesSettingsCommand(input);
 * const response = await client.send(command);
 * // { // GetCallQueuesSettingsOutput
 * //   type: "result" || "error", // required
 * //   result: { // GetCallQueuesSettingsResult
 * //     id: Number("int"), // required
 * //     name: "STRING_VALUE", // required
 * //     members: [ // CallQueuesSettingsMembersList // required
 * //       { // CallQueuesSettingsMember
 * //         name: "STRING_VALUE", // required
 * //         stateInterface: "STRING_VALUE", // required
 * //         membership: "STRING_VALUE", // required
 * //         penalty: "STRING_VALUE", // required
 * //         callsTaken: "STRING_VALUE", // required
 * //         lastCall: "STRING_VALUE", // required
 * //         isInCall: "STRING_VALUE", // required
 * //         status: "STRING_VALUE", // required
 * //         paused: "STRING_VALUE", // required
 * //         actionID: "STRING_VALUE", // required
 * //       },
 * //     ],
 * //   },
 * // };
 *
 * ```
 *
 * @param GetCallQueuesSettingsCommandInput - {@link GetCallQueuesSettingsCommandInput}
 * @returns {@link GetCallQueuesSettingsCommandOutput}
 * @see {@link GetCallQueuesSettingsCommandInput} for command's `input` shape.
 * @see {@link GetCallQueuesSettingsCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class GetCallQueuesSettingsCommand extends GetCallQueuesSettingsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: GetCallQueuesSettingsInput;
            output: GetCallQueuesSettingsOutput;
        };
        sdk: {
            input: GetCallQueuesSettingsCommandInput;
            output: GetCallQueuesSettingsCommandOutput;
        };
    };
}
