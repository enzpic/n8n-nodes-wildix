import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { UpdatePbxOAuth2ClientInput, UpdatePbxOAuth2ClientOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link UpdatePbxOAuth2ClientCommand}.
 */
export interface UpdatePbxOAuth2ClientCommandInput extends UpdatePbxOAuth2ClientInput {
}
/**
 * @public
 *
 * The output of {@link UpdatePbxOAuth2ClientCommand}.
 */
export interface UpdatePbxOAuth2ClientCommandOutput extends UpdatePbxOAuth2ClientOutput, __MetadataBearer {
}
declare const UpdatePbxOAuth2ClientCommand_base: {
    new (input: UpdatePbxOAuth2ClientCommandInput): import("@smithy/smithy-client").CommandImpl<UpdatePbxOAuth2ClientCommandInput, UpdatePbxOAuth2ClientCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: UpdatePbxOAuth2ClientCommandInput): import("@smithy/smithy-client").CommandImpl<UpdatePbxOAuth2ClientCommandInput, UpdatePbxOAuth2ClientCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Update OAuth2 client in the PBX.
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, UpdatePbxOAuth2ClientCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, UpdatePbxOAuth2ClientCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // UpdatePbxOAuth2ClientInput
 *   id: "STRING_VALUE", // required
 *   name: "STRING_VALUE", // required
 *   redirectUri: [ // PbxOAuth2RedirectUrls // required
 *     "STRING_VALUE",
 *   ],
 * };
 * const command = new UpdatePbxOAuth2ClientCommand(input);
 * const response = await client.send(command);
 * // { // UpdatePbxOAuth2ClientOutput
 * //   type: "result" || "error", // required
 * //   result: { // PbxOAuth2Client
 * //     id: "STRING_VALUE", // required
 * //     name: "STRING_VALUE", // required
 * //     redirectUri: [ // PbxOAuth2RedirectUrls // required
 * //       "STRING_VALUE",
 * //     ],
 * //     secret: "STRING_VALUE", // required
 * //     created: Number("int"), // required
 * //     origins: [ // PbxOAuth2Origins // required
 * //       "STRING_VALUE",
 * //     ],
 * //     accessTokenTtl: Number("int"), // required
 * //   },
 * // };
 *
 * ```
 *
 * @param UpdatePbxOAuth2ClientCommandInput - {@link UpdatePbxOAuth2ClientCommandInput}
 * @returns {@link UpdatePbxOAuth2ClientCommandOutput}
 * @see {@link UpdatePbxOAuth2ClientCommandInput} for command's `input` shape.
 * @see {@link UpdatePbxOAuth2ClientCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsNotFoundException} (client fault)
 *
 * @throws {@link WmsValidationException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class UpdatePbxOAuth2ClientCommand extends UpdatePbxOAuth2ClientCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: UpdatePbxOAuth2ClientInput;
            output: UpdatePbxOAuth2ClientOutput;
        };
        sdk: {
            input: UpdatePbxOAuth2ClientCommandInput;
            output: UpdatePbxOAuth2ClientCommandOutput;
        };
    };
}
