import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { DeletePbxOAuth2ClientInput, DeletePbxOAuth2ClientOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link DeletePbxOAuth2ClientCommand}.
 */
export interface DeletePbxOAuth2ClientCommandInput extends DeletePbxOAuth2ClientInput {
}
/**
 * @public
 *
 * The output of {@link DeletePbxOAuth2ClientCommand}.
 */
export interface DeletePbxOAuth2ClientCommandOutput extends DeletePbxOAuth2ClientOutput, __MetadataBearer {
}
declare const DeletePbxOAuth2ClientCommand_base: {
    new (input: DeletePbxOAuth2ClientCommandInput): import("@smithy/smithy-client").CommandImpl<DeletePbxOAuth2ClientCommandInput, DeletePbxOAuth2ClientCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: DeletePbxOAuth2ClientCommandInput): import("@smithy/smithy-client").CommandImpl<DeletePbxOAuth2ClientCommandInput, DeletePbxOAuth2ClientCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Update OAuth2 client in the PBX.
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, DeletePbxOAuth2ClientCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, DeletePbxOAuth2ClientCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // DeletePbxOAuth2ClientInput
 *   id: "STRING_VALUE", // required
 * };
 * const command = new DeletePbxOAuth2ClientCommand(input);
 * const response = await client.send(command);
 * // { // DeletePbxOAuth2ClientOutput
 * //   type: "result" || "error", // required
 * //   result: "STRING_VALUE", // required
 * // };
 *
 * ```
 *
 * @param DeletePbxOAuth2ClientCommandInput - {@link DeletePbxOAuth2ClientCommandInput}
 * @returns {@link DeletePbxOAuth2ClientCommandOutput}
 * @see {@link DeletePbxOAuth2ClientCommandInput} for command's `input` shape.
 * @see {@link DeletePbxOAuth2ClientCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsNotFoundException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class DeletePbxOAuth2ClientCommand extends DeletePbxOAuth2ClientCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: DeletePbxOAuth2ClientInput;
            output: DeletePbxOAuth2ClientOutput;
        };
        sdk: {
            input: DeletePbxOAuth2ClientCommandInput;
            output: DeletePbxOAuth2ClientCommandOutput;
        };
    };
}
