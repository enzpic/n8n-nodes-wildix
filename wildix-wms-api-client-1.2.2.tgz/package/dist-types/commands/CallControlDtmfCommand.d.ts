import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CallControlDtmfInput, CallControlDtmfOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CallControlDtmfCommand}.
 */
export interface CallControlDtmfCommandInput extends CallControlDtmfInput {
}
/**
 * @public
 *
 * The output of {@link CallControlDtmfCommand}.
 */
export interface CallControlDtmfCommandOutput extends CallControlDtmfOutput, __MetadataBearer {
}
declare const CallControlDtmfCommand_base: {
    new (input: CallControlDtmfCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlDtmfCommandInput, CallControlDtmfCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CallControlDtmfCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlDtmfCommandInput, CallControlDtmfCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CallControlDtmfCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CallControlDtmfCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CallControlDtmfInput
 *   user: "STRING_VALUE",
 *   sipCallId: "STRING_VALUE", // required
 *   digits: "STRING_VALUE", // required
 * };
 * const command = new CallControlDtmfCommand(input);
 * const response = await client.send(command);
 * // { // CallControlDtmfOutput
 * //   message: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param CallControlDtmfCommandInput - {@link CallControlDtmfCommandInput}
 * @returns {@link CallControlDtmfCommandOutput}
 * @see {@link CallControlDtmfCommandInput} for command's `input` shape.
 * @see {@link CallControlDtmfCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link ChannelNotFoundException} (client fault)
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CallControlDtmfCommand extends CallControlDtmfCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CallControlDtmfInput;
            output: CallControlDtmfOutput;
        };
        sdk: {
            input: CallControlDtmfCommandInput;
            output: CallControlDtmfCommandOutput;
        };
    };
}
