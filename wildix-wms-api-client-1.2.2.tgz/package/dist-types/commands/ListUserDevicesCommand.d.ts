import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { ListUserDevicesInput, ListUserDevicesOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ListUserDevicesCommand}.
 */
export interface ListUserDevicesCommandInput extends ListUserDevicesInput {
}
/**
 * @public
 *
 * The output of {@link ListUserDevicesCommand}.
 */
export interface ListUserDevicesCommandOutput extends ListUserDevicesOutput, __MetadataBearer {
}
declare const ListUserDevicesCommand_base: {
    new (input: ListUserDevicesCommandInput): import("@smithy/smithy-client").CommandImpl<ListUserDevicesCommandInput, ListUserDevicesCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [ListUserDevicesCommandInput]): import("@smithy/smithy-client").CommandImpl<ListUserDevicesCommandInput, ListUserDevicesCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, ListUserDevicesCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, ListUserDevicesCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // ListUserDevicesInput
 *   user: "STRING_VALUE",
 * };
 * const command = new ListUserDevicesCommand(input);
 * const response = await client.send(command);
 * // { // ListUserDevicesOutput
 * //   devices: [ // DevicesList // required
 * //     { // UserDevice
 * //       userAgent: "STRING_VALUE", // required
 * //       contact: "STRING_VALUE", // required
 * //       active: true || false, // required
 * //     },
 * //   ],
 * //   activeDevice: {
 * //     userAgent: "STRING_VALUE", // required
 * //     contact: "STRING_VALUE", // required
 * //     active: true || false, // required
 * //   },
 * // };
 *
 * ```
 *
 * @param ListUserDevicesCommandInput - {@link ListUserDevicesCommandInput}
 * @returns {@link ListUserDevicesCommandOutput}
 * @see {@link ListUserDevicesCommandInput} for command's `input` shape.
 * @see {@link ListUserDevicesCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class ListUserDevicesCommand extends ListUserDevicesCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: ListUserDevicesInput;
            output: ListUserDevicesOutput;
        };
        sdk: {
            input: ListUserDevicesCommandInput;
            output: ListUserDevicesCommandOutput;
        };
    };
}
