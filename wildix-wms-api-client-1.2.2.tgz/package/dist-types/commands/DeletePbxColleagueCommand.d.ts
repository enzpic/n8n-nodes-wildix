import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { DeletePbxColleagueInput, DeletePbxColleagueOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link DeletePbxColleagueCommand}.
 */
export interface DeletePbxColleagueCommandInput extends DeletePbxColleagueInput {
}
/**
 * @public
 *
 * The output of {@link DeletePbxColleagueCommand}.
 */
export interface DeletePbxColleagueCommandOutput extends DeletePbxColleagueOutput, __MetadataBearer {
}
declare const DeletePbxColleagueCommand_base: {
    new (input: DeletePbxColleagueCommandInput): import("@smithy/smithy-client").CommandImpl<DeletePbxColleagueCommandInput, DeletePbxColleagueCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: DeletePbxColleagueCommandInput): import("@smithy/smithy-client").CommandImpl<DeletePbxColleagueCommandInput, DeletePbxColleagueCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, DeletePbxColleagueCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, DeletePbxColleagueCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // DeletePbxColleagueInput
 *   id: Number("int"), // required
 * };
 * const command = new DeletePbxColleagueCommand(input);
 * const response = await client.send(command);
 * // { // DeletePbxColleagueOutput
 * //   type: "result" || "error", // required
 * //   result: "STRING_VALUE", // required
 * // };
 *
 * ```
 *
 * @param DeletePbxColleagueCommandInput - {@link DeletePbxColleagueCommandInput}
 * @returns {@link DeletePbxColleagueCommandOutput}
 * @see {@link DeletePbxColleagueCommandInput} for command's `input` shape.
 * @see {@link DeletePbxColleagueCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class DeletePbxColleagueCommand extends DeletePbxColleagueCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: DeletePbxColleagueInput;
            output: DeletePbxColleagueOutput;
        };
        sdk: {
            input: DeletePbxColleagueCommandInput;
            output: DeletePbxColleagueCommandOutput;
        };
    };
}
