import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { GetPersonalInfoInput, GetPersonalInfoOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetPersonalInfoCommand}.
 */
export interface GetPersonalInfoCommandInput extends GetPersonalInfoInput {
}
/**
 * @public
 *
 * The output of {@link GetPersonalInfoCommand}.
 */
export interface GetPersonalInfoCommandOutput extends GetPersonalInfoOutput, __MetadataBearer {
}
declare const GetPersonalInfoCommand_base: {
    new (input: GetPersonalInfoCommandInput): import("@smithy/smithy-client").CommandImpl<GetPersonalInfoCommandInput, GetPersonalInfoCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [GetPersonalInfoCommandInput]): import("@smithy/smithy-client").CommandImpl<GetPersonalInfoCommandInput, GetPersonalInfoCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, GetPersonalInfoCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, GetPersonalInfoCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // GetPersonalInfoInput
 *   extension: [ // ColleaguesFilterList
 *     "STRING_VALUE",
 *   ],
 *   id: [
 *     "STRING_VALUE",
 *   ],
 *   officePhone: [
 *     "STRING_VALUE",
 *   ],
 *   mobilePhone: [
 *     "STRING_VALUE",
 *   ],
 *   name: [
 *     "STRING_VALUE",
 *   ],
 *   email: "<ColleaguesFilterList>",
 *   role: "<ColleaguesFilterList>",
 *   dialplan: "<ColleaguesFilterList>",
 *   faxDialplan: "<ColleaguesFilterList>",
 *   department: "<ColleaguesFilterList>",
 *   login: "<ColleaguesFilterList>",
 *   groupDn: "<ColleaguesFilterList>",
 *   pbxDn: "<ColleaguesFilterList>",
 *   licenseType: [ // ColleaguesFilterLicenseTypeList
 *     "basic" || "essential" || "business" || "premium" || "wizyconf",
 *   ],
 *   fields: [ // PbxColleaguesQueryFieldList
 *     "extension" || "officePhone" || "mobilePhone" || "name" || "email" || "role" || "groupDn" || "language" || "dialplan" || "faxDialplan" || "department" || "login" || "id" || "pbxDn" || "picture" || "sourceId" || "licenseType",
 *   ],
 *   searchFields: [
 *     "extension" || "officePhone" || "mobilePhone" || "name" || "email" || "role" || "groupDn" || "language" || "dialplan" || "faxDialplan" || "department" || "login" || "id" || "pbxDn" || "picture" || "sourceId" || "licenseType",
 *   ],
 *   search: "STRING_VALUE",
 *   sort: [
 *     "extension" || "officePhone" || "mobilePhone" || "name" || "email" || "role" || "groupDn" || "language" || "dialplan" || "faxDialplan" || "department" || "login" || "id" || "pbxDn" || "picture" || "sourceId" || "licenseType",
 *   ],
 *   start: Number("int"),
 *   count: Number("int"),
 *   dir: "asc" || "desc",
 *   searchStrategy: "contain" || "startsWith",
 * };
 * const command = new GetPersonalInfoCommand(input);
 * const response = await client.send(command);
 * // { // GetPersonalInfoOutput
 * //   type: "result" || "error", // required
 * //   result: { // PbxColleague
 * //     id: "STRING_VALUE", // required
 * //     name: "STRING_VALUE",
 * //     login: "STRING_VALUE",
 * //     extension: "STRING_VALUE", // required
 * //     officePhone: "STRING_VALUE",
 * //     mobilePhone: "STRING_VALUE",
 * //     faxNumber: "STRING_VALUE",
 * //     email: "STRING_VALUE",
 * //     pbxDn: "STRING_VALUE", // required
 * //     pbx: "STRING_VALUE", // required
 * //     role: "admin" || "user" || "fax" || "park_orbit" || "room", // required
 * //     groupName: "STRING_VALUE", // required
 * //     groupDn: "STRING_VALUE", // required
 * //     language: "STRING_VALUE", // required
 * //     dialplan: "STRING_VALUE", // required
 * //     faxDialplan: "STRING_VALUE", // required
 * //     department: "STRING_VALUE",
 * //     picture: "STRING_VALUE", // required
 * //     sourceId: "STRING_VALUE",
 * //     licenseType: "basic" || "essential" || "business" || "premium" || "wizyconf", // required
 * //     jid: "STRING_VALUE", // required
 * //   },
 * // };
 *
 * ```
 *
 * @param GetPersonalInfoCommandInput - {@link GetPersonalInfoCommandInput}
 * @returns {@link GetPersonalInfoCommandOutput}
 * @see {@link GetPersonalInfoCommandInput} for command's `input` shape.
 * @see {@link GetPersonalInfoCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class GetPersonalInfoCommand extends GetPersonalInfoCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: GetPersonalInfoInput;
            output: GetPersonalInfoOutput;
        };
        sdk: {
            input: GetPersonalInfoCommandInput;
            output: GetPersonalInfoCommandOutput;
        };
    };
}
