import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { OriginateInput, OriginateOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link OriginateCommand}.
 */
export interface OriginateCommandInput extends OriginateInput {
}
/**
 * @public
 *
 * The output of {@link OriginateCommand}.
 */
export interface OriginateCommandOutput extends OriginateOutput, __MetadataBearer {
}
declare const OriginateCommand_base: {
    new (input: OriginateCommandInput): import("@smithy/smithy-client").CommandImpl<OriginateCommandInput, OriginateCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: OriginateCommandInput): import("@smithy/smithy-client").CommandImpl<OriginateCommandInput, OriginateCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Originate
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, OriginateCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, OriginateCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // OriginateInput
 *   channel: "STRING_VALUE", // required
 *   exten: "STRING_VALUE",
 *   context: "STRING_VALUE",
 *   priority: "STRING_VALUE",
 *   application: "STRING_VALUE",
 *   data: "STRING_VALUE",
 *   timeout: "STRING_VALUE",
 *   callerid: "STRING_VALUE",
 *   variable: "STRING_VALUE",
 *   account: "STRING_VALUE",
 *   async: "STRING_VALUE",
 *   actionid: "STRING_VALUE",
 * };
 * const command = new OriginateCommand(input);
 * const response = await client.send(command);
 * // { // OriginateOutput
 * //   type: "result" || "error", // required
 * //   result: "Success", // required
 * // };
 *
 * ```
 *
 * @param OriginateCommandInput - {@link OriginateCommandInput}
 * @returns {@link OriginateCommandOutput}
 * @see {@link OriginateCommandInput} for command's `input` shape.
 * @see {@link OriginateCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class OriginateCommand extends OriginateCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: OriginateInput;
            output: OriginateOutput;
        };
        sdk: {
            input: OriginateCommandInput;
            output: OriginateCommandOutput;
        };
    };
}
