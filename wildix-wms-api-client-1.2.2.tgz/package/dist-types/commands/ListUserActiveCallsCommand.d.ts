import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { ListUserActiveCallsInput, ListUserActiveCallsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ListUserActiveCallsCommand}.
 */
export interface ListUserActiveCallsCommandInput extends ListUserActiveCallsInput {
}
/**
 * @public
 *
 * The output of {@link ListUserActiveCallsCommand}.
 */
export interface ListUserActiveCallsCommandOutput extends ListUserActiveCallsOutput, __MetadataBearer {
}
declare const ListUserActiveCallsCommand_base: {
    new (input: ListUserActiveCallsCommandInput): import("@smithy/smithy-client").CommandImpl<ListUserActiveCallsCommandInput, ListUserActiveCallsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [ListUserActiveCallsCommandInput]): import("@smithy/smithy-client").CommandImpl<ListUserActiveCallsCommandInput, ListUserActiveCallsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, ListUserActiveCallsCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, ListUserActiveCallsCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // ListUserActiveCallsInput
 *   user: "STRING_VALUE",
 * };
 * const command = new ListUserActiveCallsCommand(input);
 * const response = await client.send(command);
 * // { // ListUserActiveCallsOutput
 * //   calls: [ // Calls // required
 * //     { // Call
 * //       sipCallId: "STRING_VALUE", // required
 * //       callerNumber: "STRING_VALUE", // required
 * //       callerName: "STRING_VALUE",
 * //       calleeNumber: "STRING_VALUE", // required
 * //       calleeName: "STRING_VALUE",
 * //       state: "STRING_VALUE", // required
 * //       duration: Number("int"), // required
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param ListUserActiveCallsCommandInput - {@link ListUserActiveCallsCommandInput}
 * @returns {@link ListUserActiveCallsCommandOutput}
 * @see {@link ListUserActiveCallsCommandInput} for command's `input` shape.
 * @see {@link ListUserActiveCallsCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class ListUserActiveCallsCommand extends ListUserActiveCallsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: ListUserActiveCallsInput;
            output: ListUserActiveCallsOutput;
        };
        sdk: {
            input: ListUserActiveCallsCommandInput;
            output: ListUserActiveCallsCommandOutput;
        };
    };
}
