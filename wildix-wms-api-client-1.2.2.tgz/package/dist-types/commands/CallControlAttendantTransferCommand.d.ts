import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CallControlAttendantTransferInput, CallControlAttendantTransferOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CallControlAttendantTransferCommand}.
 */
export interface CallControlAttendantTransferCommandInput extends CallControlAttendantTransferInput {
}
/**
 * @public
 *
 * The output of {@link CallControlAttendantTransferCommand}.
 */
export interface CallControlAttendantTransferCommandOutput extends CallControlAttendantTransferOutput, __MetadataBearer {
}
declare const CallControlAttendantTransferCommand_base: {
    new (input: CallControlAttendantTransferCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlAttendantTransferCommandInput, CallControlAttendantTransferCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CallControlAttendantTransferCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlAttendantTransferCommandInput, CallControlAttendantTransferCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CallControlAttendantTransferCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CallControlAttendantTransferCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CallControlAttendantTransferInput
 *   user: "STRING_VALUE",
 *   sipCallId: "STRING_VALUE", // required
 *   destination: "STRING_VALUE", // required
 * };
 * const command = new CallControlAttendantTransferCommand(input);
 * const response = await client.send(command);
 * // { // CallControlAttendantTransferOutput
 * //   message: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param CallControlAttendantTransferCommandInput - {@link CallControlAttendantTransferCommandInput}
 * @returns {@link CallControlAttendantTransferCommandOutput}
 * @see {@link CallControlAttendantTransferCommandInput} for command's `input` shape.
 * @see {@link CallControlAttendantTransferCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link ChannelNotFoundException} (client fault)
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CallControlAttendantTransferCommand extends CallControlAttendantTransferCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CallControlAttendantTransferInput;
            output: CallControlAttendantTransferOutput;
        };
        sdk: {
            input: CallControlAttendantTransferCommandInput;
            output: CallControlAttendantTransferCommandOutput;
        };
    };
}
