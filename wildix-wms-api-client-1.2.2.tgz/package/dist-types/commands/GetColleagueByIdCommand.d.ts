import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { GetColleagueByIdInput, GetColleagueByIdOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetColleagueByIdCommand}.
 */
export interface GetColleagueByIdCommandInput extends GetColleagueByIdInput {
}
/**
 * @public
 *
 * The output of {@link GetColleagueByIdCommand}.
 */
export interface GetColleagueByIdCommandOutput extends GetColleagueByIdOutput, __MetadataBearer {
}
declare const GetColleagueByIdCommand_base: {
    new (input: GetColleagueByIdCommandInput): import("@smithy/smithy-client").CommandImpl<GetColleagueByIdCommandInput, GetColleagueByIdCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: GetColleagueByIdCommandInput): import("@smithy/smithy-client").CommandImpl<GetColleagueByIdCommandInput, GetColleagueByIdCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, GetColleagueByIdCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, GetColleagueByIdCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // GetColleagueByIdInput
 *   id: Number("int"), // required
 * };
 * const command = new GetColleagueByIdCommand(input);
 * const response = await client.send(command);
 * // { // GetColleagueByIdOutput
 * //   type: "result" || "error", // required
 * //   result: { // PbxColleague
 * //     id: "STRING_VALUE", // required
 * //     name: "STRING_VALUE",
 * //     login: "STRING_VALUE",
 * //     extension: "STRING_VALUE", // required
 * //     officePhone: "STRING_VALUE",
 * //     mobilePhone: "STRING_VALUE",
 * //     faxNumber: "STRING_VALUE",
 * //     email: "STRING_VALUE",
 * //     pbxDn: "STRING_VALUE", // required
 * //     pbx: "STRING_VALUE", // required
 * //     role: "admin" || "user" || "fax" || "park_orbit" || "room", // required
 * //     groupName: "STRING_VALUE", // required
 * //     groupDn: "STRING_VALUE", // required
 * //     language: "STRING_VALUE", // required
 * //     dialplan: "STRING_VALUE", // required
 * //     faxDialplan: "STRING_VALUE", // required
 * //     department: "STRING_VALUE",
 * //     picture: "STRING_VALUE", // required
 * //     sourceId: "STRING_VALUE",
 * //     licenseType: "basic" || "essential" || "business" || "premium" || "wizyconf", // required
 * //     jid: "STRING_VALUE", // required
 * //   },
 * // };
 *
 * ```
 *
 * @param GetColleagueByIdCommandInput - {@link GetColleagueByIdCommandInput}
 * @returns {@link GetColleagueByIdCommandOutput}
 * @see {@link GetColleagueByIdCommandInput} for command's `input` shape.
 * @see {@link GetColleagueByIdCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class GetColleagueByIdCommand extends GetColleagueByIdCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: GetColleagueByIdInput;
            output: GetColleagueByIdOutput;
        };
        sdk: {
            input: GetColleagueByIdCommandInput;
            output: GetColleagueByIdCommandOutput;
        };
    };
}
