import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { ListPbxDepartmentsInput, ListPbxDepartmentsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ListPbxDepartmentsCommand}.
 */
export interface ListPbxDepartmentsCommandInput extends ListPbxDepartmentsInput {
}
/**
 * @public
 *
 * The output of {@link ListPbxDepartmentsCommand}.
 */
export interface ListPbxDepartmentsCommandOutput extends ListPbxDepartmentsOutput, __MetadataBearer {
}
declare const ListPbxDepartmentsCommand_base: {
    new (input: ListPbxDepartmentsCommandInput): import("@smithy/smithy-client").CommandImpl<ListPbxDepartmentsCommandInput, ListPbxDepartmentsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [ListPbxDepartmentsCommandInput]): import("@smithy/smithy-client").CommandImpl<ListPbxDepartmentsCommandInput, ListPbxDepartmentsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, ListPbxDepartmentsCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, ListPbxDepartmentsCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = {};
 * const command = new ListPbxDepartmentsCommand(input);
 * const response = await client.send(command);
 * // { // ListPbxDepartmentsOutput
 * //   type: "result" || "error", // required
 * //   result: { // ListPbxDepartmentsResult
 * //     records: [ // PbxDepartmentsList // required
 * //       { // PbxDepartment
 * //         id: "STRING_VALUE", // required
 * //         name: "STRING_VALUE", // required
 * //         users: [ // PbxDepartmentUsers
 * //           "STRING_VALUE",
 * //         ],
 * //         items: [
 * //           {
 * //             id: "STRING_VALUE", // required
 * //             name: "STRING_VALUE", // required
 * //             users: [
 * //               "STRING_VALUE",
 * //             ],
 * //             items: "<PbxDepartmentsList>",
 * //           },
 * //         ],
 * //       },
 * //     ],
 * //   },
 * // };
 *
 * ```
 *
 * @param ListPbxDepartmentsCommandInput - {@link ListPbxDepartmentsCommandInput}
 * @returns {@link ListPbxDepartmentsCommandOutput}
 * @see {@link ListPbxDepartmentsCommandInput} for command's `input` shape.
 * @see {@link ListPbxDepartmentsCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class ListPbxDepartmentsCommand extends ListPbxDepartmentsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: {};
            output: ListPbxDepartmentsOutput;
        };
        sdk: {
            input: ListPbxDepartmentsCommandInput;
            output: ListPbxDepartmentsCommandOutput;
        };
    };
}
