import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CallControlUpdateContactInfoInput, CallControlUpdateContactInfoOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CallControlUpdateContactInfoCommand}.
 */
export interface CallControlUpdateContactInfoCommandInput extends CallControlUpdateContactInfoInput {
}
/**
 * @public
 *
 * The output of {@link CallControlUpdateContactInfoCommand}.
 */
export interface CallControlUpdateContactInfoCommandOutput extends CallControlUpdateContactInfoOutput, __MetadataBearer {
}
declare const CallControlUpdateContactInfoCommand_base: {
    new (input: CallControlUpdateContactInfoCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlUpdateContactInfoCommandInput, CallControlUpdateContactInfoCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CallControlUpdateContactInfoCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlUpdateContactInfoCommandInput, CallControlUpdateContactInfoCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CallControlUpdateContactInfoCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CallControlUpdateContactInfoCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CallControlUpdateContactInfoInput
 *   user: "STRING_VALUE",
 *   sipCallId: "STRING_VALUE", // required
 *   name: "STRING_VALUE",
 *   phone: "STRING_VALUE",
 * };
 * const command = new CallControlUpdateContactInfoCommand(input);
 * const response = await client.send(command);
 * // { // CallControlUpdateContactInfoOutput
 * //   message: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param CallControlUpdateContactInfoCommandInput - {@link CallControlUpdateContactInfoCommandInput}
 * @returns {@link CallControlUpdateContactInfoCommandOutput}
 * @see {@link CallControlUpdateContactInfoCommandInput} for command's `input` shape.
 * @see {@link CallControlUpdateContactInfoCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link ChannelNotFoundException} (client fault)
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CallControlUpdateContactInfoCommand extends CallControlUpdateContactInfoCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CallControlUpdateContactInfoInput;
            output: CallControlUpdateContactInfoOutput;
        };
        sdk: {
            input: CallControlUpdateContactInfoCommandInput;
            output: CallControlUpdateContactInfoCommandOutput;
        };
    };
}
