import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { GetPbxOAuth2ClientsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetPbxOAuth2ClientsCommand}.
 */
export interface GetPbxOAuth2ClientsCommandInput {
}
/**
 * @public
 *
 * The output of {@link GetPbxOAuth2ClientsCommand}.
 */
export interface GetPbxOAuth2ClientsCommandOutput extends GetPbxOAuth2ClientsOutput, __MetadataBearer {
}
declare const GetPbxOAuth2ClientsCommand_base: {
    new (input: GetPbxOAuth2ClientsCommandInput): import("@smithy/smithy-client").CommandImpl<GetPbxOAuth2ClientsCommandInput, GetPbxOAuth2ClientsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [GetPbxOAuth2ClientsCommandInput]): import("@smithy/smithy-client").CommandImpl<GetPbxOAuth2ClientsCommandInput, GetPbxOAuth2ClientsCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * Get the list of all OAuth2 clients on the PBX.
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, GetPbxOAuth2ClientsCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, GetPbxOAuth2ClientsCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = {};
 * const command = new GetPbxOAuth2ClientsCommand(input);
 * const response = await client.send(command);
 * // { // GetPbxOAuth2ClientsOutput
 * //   type: "result" || "error", // required
 * //   result: { // GetPbxOAuth2ClientsResult
 * //     records: [ // PbxOAuth2ClientList // required
 * //       { // PbxOAuth2ClientListProjection
 * //         id: "STRING_VALUE", // required
 * //         name: "STRING_VALUE", // required
 * //         redirectUri: [ // PbxOAuth2RedirectUrls // required
 * //           "STRING_VALUE",
 * //         ],
 * //         secret: "STRING_VALUE", // required
 * //         created: Number("int"), // required
 * //         expireTime: Number("int"), // required
 * //       },
 * //     ],
 * //   },
 * // };
 *
 * ```
 *
 * @param GetPbxOAuth2ClientsCommandInput - {@link GetPbxOAuth2ClientsCommandInput}
 * @returns {@link GetPbxOAuth2ClientsCommandOutput}
 * @see {@link GetPbxOAuth2ClientsCommandInput} for command's `input` shape.
 * @see {@link GetPbxOAuth2ClientsCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 * @public
 */
export declare class GetPbxOAuth2ClientsCommand extends GetPbxOAuth2ClientsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: {};
            output: GetPbxOAuth2ClientsOutput;
        };
        sdk: {
            input: GetPbxOAuth2ClientsCommandInput;
            output: GetPbxOAuth2ClientsCommandOutput;
        };
    };
}
