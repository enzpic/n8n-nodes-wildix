import { ServiceInputTypes, ServiceOutputTypes, WmsApiClientResolvedConfig } from "../WmsApiClient";
import { CallControlAnswerInput, CallControlAnswerOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CallControlAnswerCommand}.
 */
export interface CallControlAnswerCommandInput extends CallControlAnswerInput {
}
/**
 * @public
 *
 * The output of {@link CallControlAnswerCommand}.
 */
export interface CallControlAnswerCommandOutput extends CallControlAnswerOutput, __MetadataBearer {
}
declare const CallControlAnswerCommand_base: {
    new (input: CallControlAnswerCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlAnswerCommandInput, CallControlAnswerCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CallControlAnswerCommandInput): import("@smithy/smithy-client").CommandImpl<CallControlAnswerCommandInput, CallControlAnswerCommandOutput, WmsApiClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { WmsApiClient, CallControlAnswerCommand } from "@wildix/wms-api-client"; // ES Modules import
 * // const { WmsApiClient, CallControlAnswerCommand } = require("@wildix/wms-api-client"); // CommonJS import
 * const client = new WmsApiClient(config);
 * const input = { // CallControlAnswerInput
 *   user: "STRING_VALUE",
 *   sipCallId: "STRING_VALUE", // required
 *   device: "STRING_VALUE",
 * };
 * const command = new CallControlAnswerCommand(input);
 * const response = await client.send(command);
 * // { // CallControlAnswerOutput
 * //   message: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param CallControlAnswerCommandInput - {@link CallControlAnswerCommandInput}
 * @returns {@link CallControlAnswerCommandOutput}
 * @see {@link CallControlAnswerCommandInput} for command's `input` shape.
 * @see {@link CallControlAnswerCommandOutput} for command's `response` shape.
 * @see {@link WmsApiClientResolvedConfig | config} for WmsApiClient's `config` shape.
 *
 * @throws {@link ChannelNotFoundException} (client fault)
 *
 * @throws {@link WmsUnauthorizedException} (client fault)
 *
 * @throws {@link WmsForbiddenException} (client fault)
 *
 * @throws {@link WmsApiServiceException}
 * <p>Base exception class for all service exceptions from WmsApi service.</p>
 *
 *
 */
export declare class CallControlAnswerCommand extends CallControlAnswerCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CallControlAnswerInput;
            output: CallControlAnswerOutput;
        };
        sdk: {
            input: CallControlAnswerCommandInput;
            output: CallControlAnswerCommandOutput;
        };
    };
}
