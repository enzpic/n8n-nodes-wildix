import { WmsApiServiceException as __BaseException } from "../models/WmsApiServiceException";
import { ChannelNotFoundException, WmsForbiddenException, WmsNotFoundException, WmsUnauthorizedException, WmsValidationException, } from "../models/models_0";
import { loadRestJsonErrorCode, parseJsonBody as parseBody, parseJsonErrorBody as parseErrorBody, } from "@aws-sdk/core";
import { requestBuilder as rb } from "@smithy/core";
import { decorateServiceException as __decorateServiceException, expectNonNull as __expectNonNull, expectObject as __expectObject, expectString as __expectString, _json, collectBody, map, take, withBaseException, } from "@smithy/smithy-client";
export const se_CallControlAnswerCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/answer");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify(take(input, {
        'device': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_CallControlAttendantTransferCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/attendant-transfer");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify(take(input, {
        'destination': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_CallControlBlindTransferCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/blind-transfer");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify(take(input, {
        'destination': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_CallControlDtmfCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/dtmf");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify(take(input, {
        'digits': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_CallControlHangupCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/hangup");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify(take(input, {
        'reason': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_CallControlHoldCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/hold");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify(take(input, {
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_CallControlMakeCallCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/make-call");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify(take(input, {
        'destination': [],
        'device': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_CallControlUnholdCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/unhold");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify(take(input, {
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_CallControlUpdateContactInfoCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/update-contact-info");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify(take(input, {
        'name': [],
        'phone': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_CreatePbxAclGroupCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/pbx/aclgroups");
    let body;
    body = JSON.stringify(take(input, {
        'inherits': [],
        'name': [],
        'rules': _ => _json(_),
        'wcgrp': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_CreatePbxColleagueCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/PBX/Colleagues");
    let body;
    body = JSON.stringify(take(input, {
        'department': [],
        'dialplan': [],
        'email': [],
        'extension': [],
        'faxDialplan': [],
        'faxNumber': [],
        'groupDn': [],
        'language': [],
        'licenseType': [],
        'login': [],
        'mobilePhone': [],
        'name': [],
        'officePhone': [],
        'password': [],
        'role': [],
        'sipPassword': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_CreatePbxOAuth2ClientCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/pbx/applications/oauth2");
    let body;
    body = JSON.stringify(take(input, {
        'expireTime': [],
        'name': [],
        'redirectUri': _ => _json(_),
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_DeletePbxAclGroupCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/aclgroups/{id}");
    b.p('id', () => input.id.toString(), '{id}', false);
    let body;
    b.m("DELETE")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_DeletePbxColleagueCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/PBX/Colleagues/{id}");
    b.p('id', () => input.id.toString(), '{id}', false);
    let body;
    b.m("DELETE")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_DeletePbxOAuth2ClientCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/applications/oauth2/{id}");
    b.p('id', () => input.id, '{id}', false);
    let body;
    b.m("DELETE")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_GetCallQueuesSettingsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/settings/callqueues/{groupId}");
    b.p('groupId', () => input.groupId.toString(), '{groupId}', false);
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_GetColleagueByIdCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/Colleagues/{id}");
    b.p('id', () => input.id.toString(), '{id}', false);
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_GetPbxAclGroupsPermissionsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/aclgroups/permissions");
    const query = map({
        [_gr]: [() => input.groups !== void 0, () => ((input[_g] || []))],
        [_pe]: [() => input.permissions !== void 0, () => ((input[_p] || []))],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_GetPbxCallGroupsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/Dialplan/CallGroups");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_GetPbxColleaguesCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/PBX/Colleagues");
    const query = map({
        [_f]: [() => input.extension !== void 0, () => ((input[_e] || []))],
        [_fi]: [() => input.id !== void 0, () => ((input[_i] || []))],
        [_fP]: [() => input.officePhone !== void 0, () => ((input[_oP] || []))],
        [_fPi]: [() => input.mobilePhone !== void 0, () => ((input[_mP] || []))],
        [_fil]: [() => input.name !== void 0, () => ((input[_n] || []))],
        [_filt]: [() => input.email !== void 0, () => ((input[_em] || []))],
        [_filte]: [() => input.role !== void 0, () => ((input[_r] || []))],
        [_filter]: [() => input.dialplan !== void 0, () => ((input[_d] || []))],
        [_fDi]: [() => input.faxDialplan !== void 0, () => ((input[_fD] || []))],
        [_filterd]: [() => input.department !== void 0, () => ((input[_de] || []))],
        [_filterl]: [() => input.login !== void 0, () => ((input[_l] || []))],
        [_fDil]: [() => input.groupDn !== void 0, () => ((input[_gD] || []))],
        [_fDilt]: [() => input.pbxDn !== void 0, () => ((input[_pD] || []))],
        [_fT]: [() => input.licenseType !== void 0, () => ((input[_lT] || []))],
        [_fie]: [() => input.fields !== void 0, () => ((input[_fie] || []).join(','))],
        [_sF]: [() => input.searchFields !== void 0, () => ((input[_sF] || []).join(','))],
        [_s]: [, input[_s]],
        [_so]: [() => input.sort !== void 0, () => ((input[_so] || []))],
        [_st]: [() => input.start !== void 0, () => (input[_st].toString())],
        [_c]: [() => input.count !== void 0, () => (input[_c].toString())],
        [_di]: [, input[_di]],
        [_sS]: [, input[_sS]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_GetPbxesCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/network/pbxes");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_GetPbxOAuth2ClientsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/applications/oauth2");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_GetPersonalInfoCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/personal/info");
    const query = map({
        [_f]: [() => input.extension !== void 0, () => ((input[_e] || []))],
        [_fi]: [() => input.id !== void 0, () => ((input[_i] || []))],
        [_fP]: [() => input.officePhone !== void 0, () => ((input[_oP] || []))],
        [_fPi]: [() => input.mobilePhone !== void 0, () => ((input[_mP] || []))],
        [_fil]: [() => input.name !== void 0, () => ((input[_n] || []))],
        [_filt]: [() => input.email !== void 0, () => ((input[_em] || []))],
        [_filte]: [() => input.role !== void 0, () => ((input[_r] || []))],
        [_filter]: [() => input.dialplan !== void 0, () => ((input[_d] || []))],
        [_fDi]: [() => input.faxDialplan !== void 0, () => ((input[_fD] || []))],
        [_filterd]: [() => input.department !== void 0, () => ((input[_de] || []))],
        [_filterl]: [() => input.login !== void 0, () => ((input[_l] || []))],
        [_fDil]: [() => input.groupDn !== void 0, () => ((input[_gD] || []))],
        [_fDilt]: [() => input.pbxDn !== void 0, () => ((input[_pD] || []))],
        [_fT]: [() => input.licenseType !== void 0, () => ((input[_lT] || []))],
        [_fie]: [() => input.fields !== void 0, () => ((input[_fie] || []))],
        [_sF]: [() => input.searchFields !== void 0, () => ((input[_sF] || []))],
        [_s]: [, input[_s]],
        [_so]: [() => input.sort !== void 0, () => ((input[_so] || []))],
        [_st]: [() => input.start !== void 0, () => (input[_st].toString())],
        [_c]: [() => input.count !== void 0, () => (input[_c].toString())],
        [_di]: [, input[_di]],
        [_sS]: [, input[_sS]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_ListPbxDepartmentsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/Departments");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_ListPbxGroupsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/Groups");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_ListUserActiveCallsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v2/call-control/list-calls");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_ListUserDevicesCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v2/call-control/list-devices");
    const query = map({
        [_u]: [, input[_u]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_NotificationsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/notifications");
    let body;
    body = JSON.stringify(take(input, {
        'broadcastId': [],
        'broadcastMessage': [],
        'confirmationTimeout': [],
        'customRid': [],
        'event': [],
        'from': [],
        'notificationType': [],
        'origin': [],
        'playFrequency': [],
        'priority': [],
        'queueTimeout': [],
        'skipTranscribe': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_OriginateCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/originate");
    let body;
    body = JSON.stringify(take(input, {
        'account': [],
        'actionid': [],
        'application': [],
        'async': [],
        'callerid': [],
        'channel': [],
        'context': [],
        'data': [],
        'exten': [],
        'priority': [],
        'timeout': [],
        'variable': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_OriginateCallCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/originate/call");
    let body;
    body = JSON.stringify(take(input, {
        'name': [],
        'number': [],
        'postpone': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_ReloadBroadcastsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/api/v1/broadcasts/reload");
    let body;
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_UpdatePbxOAuth2ClientCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/pbx/applications/oauth2/{id}");
    b.p('id', () => input.id, '{id}', false);
    let body;
    body = JSON.stringify(take(input, {
        'name': [],
        'redirectUri': _ => _json(_),
    }));
    b.m("PUT")
        .h(headers)
        .b(body);
    return b.build();
};
export const de_CallControlAnswerCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'message': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CallControlAttendantTransferCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'message': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CallControlBlindTransferCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'message': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CallControlDtmfCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'message': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CallControlHangupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'message': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CallControlHoldCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'message': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CallControlMakeCallCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'message': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CallControlUnholdCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'message': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CallControlUpdateContactInfoCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'message': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CreatePbxAclGroupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CreatePbxColleagueCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CreatePbxOAuth2ClientCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_DeletePbxAclGroupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_DeletePbxColleagueCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_DeletePbxOAuth2ClientCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetCallQueuesSettingsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetColleagueByIdCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetPbxAclGroupsPermissionsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetPbxCallGroupsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetPbxColleaguesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetPbxesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetPbxOAuth2ClientsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetPersonalInfoCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListPbxDepartmentsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _ => de_ListPbxDepartmentsResult(_, context),
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListPbxGroupsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListUserActiveCallsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'calls': _json,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListUserDevicesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'activeDevice': _json,
        'devices': _json,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_NotificationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_OriginateCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_OriginateCallCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ReloadBroadcastsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_UpdatePbxOAuth2ClientCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
const de_CommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "ChannelNotFoundException":
        case "wildix.wms.api#ChannelNotFoundException":
            throw await de_ChannelNotFoundExceptionRes(parsedOutput, context);
        case "WmsForbiddenException":
        case "wildix.wms.api#WmsForbiddenException":
            throw await de_WmsForbiddenExceptionRes(parsedOutput, context);
        case "WmsUnauthorizedException":
        case "wildix.wms.api#WmsUnauthorizedException":
            throw await de_WmsUnauthorizedExceptionRes(parsedOutput, context);
        case "WmsValidationException":
        case "wildix.wms.api#WmsValidationException":
            throw await de_WmsValidationExceptionRes(parsedOutput, context);
        case "WmsNotFoundException":
        case "wildix.wms.api#WmsNotFoundException":
            throw await de_WmsNotFoundExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const throwDefaultError = withBaseException(__BaseException);
const de_ChannelNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'reason': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new ChannelNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_WmsForbiddenExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'reason': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new WmsForbiddenException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_WmsNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'reason': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new WmsNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_WmsUnauthorizedExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'reason': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new WmsUnauthorizedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_WmsValidationExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'errors': _json,
        'reason': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new WmsValidationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ListPbxDepartmentsResult = (output, context) => {
    return take(output, {
        'records': (_) => de_PbxDepartmentsList(_, context),
    });
};
const de_PbxDepartment = (output, context) => {
    return take(output, {
        'id': __expectString,
        'items': (_) => de_PbxDepartmentsList(_, context),
        'name': __expectString,
        'users': _json,
    });
};
const de_PbxDepartmentsList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_PbxDepartment(entry, context);
    });
    return retVal;
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBodyString = (streamBody, context) => collectBody(streamBody, context).then(body => context.utf8Encoder(body));
const _c = "count";
const _d = "dialplan";
const _de = "department";
const _di = "dir";
const _e = "extension";
const _em = "email";
const _f = "filter[extension][]";
const _fD = "faxDialplan";
const _fDi = "filter[faxDialplan][]";
const _fDil = "filter[groupDn][]";
const _fDilt = "filter[pbxDn][]";
const _fP = "filter[officePhone][]";
const _fPi = "filter[mobilePhone][]";
const _fT = "filter[licenseType][]";
const _fi = "filter[id][]";
const _fie = "fields";
const _fil = "filter[name][]";
const _filt = "filter[email][]";
const _filte = "filter[role][]";
const _filter = "filter[dialplan][]";
const _filterd = "filter[department][]";
const _filterl = "filter[login][]";
const _g = "groups";
const _gD = "groupDn";
const _gr = "groups[]";
const _i = "id";
const _l = "login";
const _lT = "licenseType";
const _mP = "mobilePhone";
const _n = "name";
const _oP = "officePhone";
const _p = "permissions";
const _pD = "pbxDn";
const _pe = "permissions[]";
const _r = "role";
const _s = "search";
const _sF = "searchFields";
const _sS = "searchStrategy";
const _so = "sort";
const _st = "start";
const _u = "user";
