import { de_CallControlUpdateContactInfoCommand, se_CallControlUpdateContactInfoCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CallControlUpdateContactInfoCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CallControlUpdateContactInfo", {})
    .n("WmsApiClient", "CallControlUpdateContactInfoCommand")
    .f(void 0, void 0)
    .ser(se_CallControlUpdateContactInfoCommand)
    .de(de_CallControlUpdateContactInfoCommand)
    .build() {
}
