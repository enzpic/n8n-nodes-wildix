import { de_DeletePbxAclGroupCommand, se_DeletePbxAclGroupCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class DeletePbxAclGroupCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "DeletePbxAclGroup", {})
    .n("WmsApiClient", "DeletePbxAclGroupCommand")
    .f(void 0, void 0)
    .ser(se_DeletePbxAclGroupCommand)
    .de(de_DeletePbxAclGroupCommand)
    .build() {
}
