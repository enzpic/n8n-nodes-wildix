import { de_CallControlAnswerCommand, se_CallControlAnswerCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CallControlAnswerCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CallControlAnswer", {})
    .n("WmsApiClient", "CallControlAnswerCommand")
    .f(void 0, void 0)
    .ser(se_CallControlAnswerCommand)
    .de(de_CallControlAnswerCommand)
    .build() {
}
