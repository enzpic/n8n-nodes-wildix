import { de_GetPbxColleaguesCommand, se_GetPbxColleaguesCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetPbxColleaguesCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "GetPbxColleagues", {})
    .n("WmsApiClient", "GetPbxColleaguesCommand")
    .f(void 0, void 0)
    .ser(se_GetPbxColleaguesCommand)
    .de(de_GetPbxColleaguesCommand)
    .build() {
}
