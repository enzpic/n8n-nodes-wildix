import { de_CallControlBlindTransferCommand, se_CallControlBlindTransferCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CallControlBlindTransferCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CallControlBlindTransfer", {})
    .n("WmsApiClient", "CallControlBlindTransferCommand")
    .f(void 0, void 0)
    .ser(se_CallControlBlindTransferCommand)
    .de(de_CallControlBlindTransferCommand)
    .build() {
}
