import { de_CreatePbxColleagueCommand, se_CreatePbxColleagueCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CreatePbxColleagueCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CreatePbxColleague", {})
    .n("WmsApiClient", "CreatePbxColleagueCommand")
    .f(void 0, void 0)
    .ser(se_CreatePbxColleagueCommand)
    .de(de_CreatePbxColleagueCommand)
    .build() {
}
