import { de_ReloadBroadcastsCommand, se_ReloadBroadcastsCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class ReloadBroadcastsCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "ReloadBroadcasts", {})
    .n("WmsApiClient", "ReloadBroadcastsCommand")
    .f(void 0, void 0)
    .ser(se_ReloadBroadcastsCommand)
    .de(de_ReloadBroadcastsCommand)
    .build() {
}
