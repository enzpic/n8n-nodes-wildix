import { de_ListPbxDepartmentsCommand, se_ListPbxDepartmentsCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class ListPbxDepartmentsCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "ListPbxDepartments", {})
    .n("WmsApiClient", "ListPbxDepartmentsCommand")
    .f(void 0, void 0)
    .ser(se_ListPbxDepartmentsCommand)
    .de(de_ListPbxDepartmentsCommand)
    .build() {
}
