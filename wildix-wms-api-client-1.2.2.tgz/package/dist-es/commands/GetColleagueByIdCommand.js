import { de_GetColleagueByIdCommand, se_GetColleagueByIdCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetColleagueByIdCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "GetColleagueById", {})
    .n("WmsApiClient", "GetColleagueByIdCommand")
    .f(void 0, void 0)
    .ser(se_GetColleagueByIdCommand)
    .de(de_GetColleagueByIdCommand)
    .build() {
}
