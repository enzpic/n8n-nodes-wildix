import { de_GetPbxCallGroupsCommand, se_GetPbxCallGroupsCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetPbxCallGroupsCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "GetPbxCallGroups", {})
    .n("WmsApiClient", "GetPbxCallGroupsCommand")
    .f(void 0, void 0)
    .ser(se_GetPbxCallGroupsCommand)
    .de(de_GetPbxCallGroupsCommand)
    .build() {
}
