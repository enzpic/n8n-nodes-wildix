import { de_DeletePbxColleagueCommand, se_DeletePbxColleagueCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class DeletePbxColleagueCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "DeletePbxColleague", {})
    .n("WmsApiClient", "DeletePbxColleagueCommand")
    .f(void 0, void 0)
    .ser(se_DeletePbxColleagueCommand)
    .de(de_DeletePbxColleagueCommand)
    .build() {
}
