import { de_UpdatePbxOAuth2ClientCommand, se_UpdatePbxOAuth2ClientCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class UpdatePbxOAuth2ClientCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "UpdatePbxOAuth2Client", {})
    .n("WmsApiClient", "UpdatePbxOAuth2ClientCommand")
    .f(void 0, void 0)
    .ser(se_UpdatePbxOAuth2ClientCommand)
    .de(de_UpdatePbxOAuth2ClientCommand)
    .build() {
}
