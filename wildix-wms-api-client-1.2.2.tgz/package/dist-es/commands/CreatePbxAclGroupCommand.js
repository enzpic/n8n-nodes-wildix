import { de_CreatePbxAclGroupCommand, se_CreatePbxAclGroupCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CreatePbxAclGroupCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CreatePbxAclGroup", {})
    .n("WmsApiClient", "CreatePbxAclGroupCommand")
    .f(void 0, void 0)
    .ser(se_CreatePbxAclGroupCommand)
    .de(de_CreatePbxAclGroupCommand)
    .build() {
}
