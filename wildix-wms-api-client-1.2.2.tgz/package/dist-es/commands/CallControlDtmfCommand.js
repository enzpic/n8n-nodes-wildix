import { de_CallControlDtmfCommand, se_CallControlDtmfCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CallControlDtmfCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CallControlDtmf", {})
    .n("WmsApiClient", "CallControlDtmfCommand")
    .f(void 0, void 0)
    .ser(se_CallControlDtmfCommand)
    .de(de_CallControlDtmfCommand)
    .build() {
}
