import { de_OriginateCommand, se_OriginateCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class OriginateCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "Originate", {})
    .n("WmsApiClient", "OriginateCommand")
    .f(void 0, void 0)
    .ser(se_OriginateCommand)
    .de(de_OriginateCommand)
    .build() {
}
