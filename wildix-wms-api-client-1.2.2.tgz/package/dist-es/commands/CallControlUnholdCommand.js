import { de_CallControlUnholdCommand, se_CallControlUnholdCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CallControlUnholdCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CallControlUnhold", {})
    .n("WmsApiClient", "CallControlUnholdCommand")
    .f(void 0, void 0)
    .ser(se_CallControlUnholdCommand)
    .de(de_CallControlUnholdCommand)
    .build() {
}
