import { de_NotificationsCommand, se_NotificationsCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class NotificationsCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "Notifications", {})
    .n("WmsApiClient", "NotificationsCommand")
    .f(void 0, void 0)
    .ser(se_NotificationsCommand)
    .de(de_NotificationsCommand)
    .build() {
}
