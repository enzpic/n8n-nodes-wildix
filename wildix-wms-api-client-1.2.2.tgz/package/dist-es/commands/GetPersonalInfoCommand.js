import { de_GetPersonalInfoCommand, se_GetPersonalInfoCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetPersonalInfoCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "GetPersonalInfo", {})
    .n("WmsApiClient", "GetPersonalInfoCommand")
    .f(void 0, void 0)
    .ser(se_GetPersonalInfoCommand)
    .de(de_GetPersonalInfoCommand)
    .build() {
}
