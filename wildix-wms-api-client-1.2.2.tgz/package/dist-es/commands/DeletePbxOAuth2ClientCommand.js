import { de_DeletePbxOAuth2ClientCommand, se_DeletePbxOAuth2ClientCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class DeletePbxOAuth2ClientCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "DeletePbxOAuth2Client", {})
    .n("WmsApiClient", "DeletePbxOAuth2ClientCommand")
    .f(void 0, void 0)
    .ser(se_DeletePbxOAuth2ClientCommand)
    .de(de_DeletePbxOAuth2ClientCommand)
    .build() {
}
