import { de_CallControlHangupCommand, se_CallControlHangupCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CallControlHangupCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CallControlHangup", {})
    .n("WmsApiClient", "CallControlHangupCommand")
    .f(void 0, void 0)
    .ser(se_CallControlHangupCommand)
    .de(de_CallControlHangupCommand)
    .build() {
}
