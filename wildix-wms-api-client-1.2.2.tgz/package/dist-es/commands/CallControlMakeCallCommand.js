import { de_CallControlMakeCallCommand, se_CallControlMakeCallCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CallControlMakeCallCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CallControlMakeCall", {})
    .n("WmsApiClient", "CallControlMakeCallCommand")
    .f(void 0, void 0)
    .ser(se_CallControlMakeCallCommand)
    .de(de_CallControlMakeCallCommand)
    .build() {
}
