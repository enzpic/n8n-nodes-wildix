import { de_CreatePbxOAuth2ClientCommand, se_CreatePbxOAuth2ClientCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CreatePbxOAuth2ClientCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CreatePbxOAuth2Client", {})
    .n("WmsApiClient", "CreatePbxOAuth2ClientCommand")
    .f(void 0, void 0)
    .ser(se_CreatePbxOAuth2ClientCommand)
    .de(de_CreatePbxOAuth2ClientCommand)
    .build() {
}
