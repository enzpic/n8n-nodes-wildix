import { de_ListUserActiveCallsCommand, se_ListUserActiveCallsCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class ListUserActiveCallsCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "ListUserActiveCalls", {})
    .n("WmsApiClient", "ListUserActiveCallsCommand")
    .f(void 0, void 0)
    .ser(se_ListUserActiveCallsCommand)
    .de(de_ListUserActiveCallsCommand)
    .build() {
}
