import { de_CallControlAttendantTransferCommand, se_CallControlAttendantTransferCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CallControlAttendantTransferCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "CallControlAttendantTransfer", {})
    .n("WmsApiClient", "CallControlAttendantTransferCommand")
    .f(void 0, void 0)
    .ser(se_CallControlAttendantTransferCommand)
    .de(de_CallControlAttendantTransferCommand)
    .build() {
}
