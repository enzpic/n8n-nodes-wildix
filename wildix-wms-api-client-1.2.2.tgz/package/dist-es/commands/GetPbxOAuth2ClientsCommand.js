import { de_GetPbxOAuth2ClientsCommand, se_GetPbxOAuth2ClientsCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetPbxOAuth2ClientsCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "GetPbxOAuth2Clients", {})
    .n("WmsApiClient", "GetPbxOAuth2ClientsCommand")
    .f(void 0, void 0)
    .ser(se_GetPbxOAuth2ClientsCommand)
    .de(de_GetPbxOAuth2ClientsCommand)
    .build() {
}
