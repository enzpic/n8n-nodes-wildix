import { de_ListUserDevicesCommand, se_ListUserDevicesCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class ListUserDevicesCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "ListUserDevices", {})
    .n("WmsApiClient", "ListUserDevicesCommand")
    .f(void 0, void 0)
    .ser(se_ListUserDevicesCommand)
    .de(de_ListUserDevicesCommand)
    .build() {
}
