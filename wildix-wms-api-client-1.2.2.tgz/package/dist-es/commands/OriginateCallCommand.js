import { de_OriginateCallCommand, se_OriginateCallCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class OriginateCallCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "OriginateCall", {})
    .n("WmsApiClient", "OriginateCallCommand")
    .f(void 0, void 0)
    .ser(se_OriginateCallCommand)
    .de(de_OriginateCallCommand)
    .build() {
}
