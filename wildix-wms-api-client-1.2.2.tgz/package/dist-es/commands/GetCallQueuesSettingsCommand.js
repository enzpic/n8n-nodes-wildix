import { de_GetCallQueuesSettingsCommand, se_GetCallQueuesSettingsCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetCallQueuesSettingsCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "GetCallQueuesSettings", {})
    .n("WmsApiClient", "GetCallQueuesSettingsCommand")
    .f(void 0, void 0)
    .ser(se_GetCallQueuesSettingsCommand)
    .de(de_GetCallQueuesSettingsCommand)
    .build() {
}
