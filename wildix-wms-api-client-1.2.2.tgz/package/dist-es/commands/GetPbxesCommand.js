import { de_GetPbxesCommand, se_GetPbxesCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetPbxesCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "GetPbxes", {})
    .n("WmsApiClient", "GetPbxesCommand")
    .f(void 0, void 0)
    .ser(se_GetPbxesCommand)
    .de(de_GetPbxesCommand)
    .build() {
}
