import { de_GetPbxAclGroupsPermissionsCommand, se_GetPbxAclGroupsPermissionsCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetPbxAclGroupsPermissionsCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("WmsApi", "GetPbxAclGroupsPermissions", {})
    .n("WmsApiClient", "GetPbxAclGroupsPermissionsCommand")
    .f(void 0, void 0)
    .ser(se_GetPbxAclGroupsPermissionsCommand)
    .de(de_GetPbxAclGroupsPermissionsCommand)
    .build() {
}
