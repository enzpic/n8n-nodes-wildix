import { WmsApiClient, } from "./WmsApiClient";
import { CallControlAnswerCommand, } from "./commands/CallControlAnswerCommand";
import { CallControlAttendantTransferCommand, } from "./commands/CallControlAttendantTransferCommand";
import { CallControlBlindTransferCommand, } from "./commands/CallControlBlindTransferCommand";
import { CallControlDtmfCommand, } from "./commands/CallControlDtmfCommand";
import { CallControlHangupCommand, } from "./commands/CallControlHangupCommand";
import { CallControlHoldCommand, } from "./commands/CallControlHoldCommand";
import { CallControlMakeCallCommand, } from "./commands/CallControlMakeCallCommand";
import { CallControlUnholdCommand, } from "./commands/CallControlUnholdCommand";
import { CallControlUpdateContactInfoCommand, } from "./commands/CallControlUpdateContactInfoCommand";
import { CreatePbxAclGroupCommand, } from "./commands/CreatePbxAclGroupCommand";
import { CreatePbxColleagueCommand, } from "./commands/CreatePbxColleagueCommand";
import { CreatePbxOAuth2ClientCommand, } from "./commands/CreatePbxOAuth2ClientCommand";
import { DeletePbxAclGroupCommand, } from "./commands/DeletePbxAclGroupCommand";
import { DeletePbxColleagueCommand, } from "./commands/DeletePbxColleagueCommand";
import { DeletePbxOAuth2ClientCommand, } from "./commands/DeletePbxOAuth2ClientCommand";
import { GetCallQueuesSettingsCommand, } from "./commands/GetCallQueuesSettingsCommand";
import { GetColleagueByIdCommand, } from "./commands/GetColleagueByIdCommand";
import { GetPbxAclGroupsPermissionsCommand, } from "./commands/GetPbxAclGroupsPermissionsCommand";
import { GetPbxCallGroupsCommand, } from "./commands/GetPbxCallGroupsCommand";
import { GetPbxColleaguesCommand, } from "./commands/GetPbxColleaguesCommand";
import { GetPbxOAuth2ClientsCommand, } from "./commands/GetPbxOAuth2ClientsCommand";
import { GetPbxesCommand, } from "./commands/GetPbxesCommand";
import { GetPersonalInfoCommand, } from "./commands/GetPersonalInfoCommand";
import { ListPbxDepartmentsCommand, } from "./commands/ListPbxDepartmentsCommand";
import { ListPbxGroupsCommand, } from "./commands/ListPbxGroupsCommand";
import { ListUserActiveCallsCommand, } from "./commands/ListUserActiveCallsCommand";
import { ListUserDevicesCommand, } from "./commands/ListUserDevicesCommand";
import { NotificationsCommand, } from "./commands/NotificationsCommand";
import { OriginateCallCommand, } from "./commands/OriginateCallCommand";
import { OriginateCommand, } from "./commands/OriginateCommand";
import { ReloadBroadcastsCommand, } from "./commands/ReloadBroadcastsCommand";
import { UpdatePbxOAuth2ClientCommand, } from "./commands/UpdatePbxOAuth2ClientCommand";
import { createAggregatedClient } from "@smithy/smithy-client";
const commands = {
    CallControlAnswerCommand,
    CallControlAttendantTransferCommand,
    CallControlBlindTransferCommand,
    CallControlDtmfCommand,
    CallControlHangupCommand,
    CallControlHoldCommand,
    CallControlMakeCallCommand,
    CallControlUnholdCommand,
    CallControlUpdateContactInfoCommand,
    CreatePbxAclGroupCommand,
    CreatePbxColleagueCommand,
    CreatePbxOAuth2ClientCommand,
    DeletePbxAclGroupCommand,
    DeletePbxColleagueCommand,
    DeletePbxOAuth2ClientCommand,
    GetCallQueuesSettingsCommand,
    GetColleagueByIdCommand,
    GetPbxAclGroupsPermissionsCommand,
    GetPbxCallGroupsCommand,
    GetPbxColleaguesCommand,
    GetPbxesCommand,
    GetPbxOAuth2ClientsCommand,
    GetPersonalInfoCommand,
    ListPbxDepartmentsCommand,
    ListPbxGroupsCommand,
    ListUserActiveCallsCommand,
    ListUserDevicesCommand,
    NotificationsCommand,
    OriginateCommand,
    OriginateCallCommand,
    ReloadBroadcastsCommand,
    UpdatePbxOAuth2ClientCommand,
};
export class WmsApi extends WmsApiClient {
}
createAggregatedClient(commands, WmsApi);
