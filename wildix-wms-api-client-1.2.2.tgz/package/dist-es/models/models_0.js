import { WmsApiServiceException as __BaseException } from "./WmsApiServiceException";
export const PbxLicenseType = {
    BASIC: "basic",
    BUSINESS: "business",
    ESSENTIAL: "essential",
    PREMIUM: "premium",
    WIZYCONF: "wizyconf",
};
export const AclGroupPermissionAbility = {
    CAN: "can",
    CANNOT: "cannot",
    NO: "no",
    NOUSE: "nouse",
    USE: "use",
    YES: "yes",
};
export const ResponseType = {
    ERROR: "error",
    RESULT: "result",
};
export class ChannelNotFoundException extends __BaseException {
    name = "ChannelNotFoundException";
    $fault = "client";
    type;
    reason;
    constructor(opts) {
        super({
            name: "ChannelNotFoundException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, ChannelNotFoundException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
    }
}
export class WmsForbiddenException extends __BaseException {
    name = "WmsForbiddenException";
    $fault = "client";
    type;
    reason;
    constructor(opts) {
        super({
            name: "WmsForbiddenException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, WmsForbiddenException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
    }
}
export class WmsUnauthorizedException extends __BaseException {
    name = "WmsUnauthorizedException";
    $fault = "client";
    type;
    reason;
    constructor(opts) {
        super({
            name: "WmsUnauthorizedException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, WmsUnauthorizedException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
    }
}
export const PbxColleagueRole = {
    ADMIN: "admin",
    FAX: "fax",
    PARK_ORBIT: "park_orbit",
    ROOM: "room",
    USER: "user",
};
export class WmsValidationException extends __BaseException {
    name = "WmsValidationException";
    $fault = "client";
    type;
    reason;
    errors;
    constructor(opts) {
        super({
            name: "WmsValidationException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, WmsValidationException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
        this.errors = opts.errors;
    }
}
export class WmsNotFoundException extends __BaseException {
    name = "WmsNotFoundException";
    $fault = "client";
    type;
    reason;
    constructor(opts) {
        super({
            name: "WmsNotFoundException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, WmsNotFoundException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
    }
}
export const GetPbxColleaguesDir = {
    ASC: "asc",
    DESC: "desc",
};
export const PbxColleaguesQueryField = {
    DEPARTMENT: "department",
    DIALPLAN: "dialplan",
    EMAIL: "email",
    EXTENSION: "extension",
    FAX_DIALPLAN: "faxDialplan",
    GROUP_DN: "groupDn",
    ID: "id",
    LANGUAGE: "language",
    LICENSE_TYPE: "licenseType",
    LOGIN: "login",
    MOBILE_PHONE: "mobilePhone",
    NAME: "name",
    OFFICE_PHONE: "officePhone",
    PBX_DN: "pbxDn",
    PICTURE: "picture",
    ROLE: "role",
    SOURCE_ID: "sourceId",
};
export const PbxColleaguesSearchStrategy = {
    CONTAIN: "contain",
    STARTS_WITH: "startsWith",
};
export const ResponseResult = {
    SUCCESS: "Success",
};
