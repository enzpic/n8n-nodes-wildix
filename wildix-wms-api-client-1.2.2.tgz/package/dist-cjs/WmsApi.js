"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WmsApi = void 0;
const WmsApiClient_1 = require("./WmsApiClient");
const CallControlAnswerCommand_1 = require("./commands/CallControlAnswerCommand");
const CallControlAttendantTransferCommand_1 = require("./commands/CallControlAttendantTransferCommand");
const CallControlBlindTransferCommand_1 = require("./commands/CallControlBlindTransferCommand");
const CallControlDtmfCommand_1 = require("./commands/CallControlDtmfCommand");
const CallControlHangupCommand_1 = require("./commands/CallControlHangupCommand");
const CallControlHoldCommand_1 = require("./commands/CallControlHoldCommand");
const CallControlMakeCallCommand_1 = require("./commands/CallControlMakeCallCommand");
const CallControlUnholdCommand_1 = require("./commands/CallControlUnholdCommand");
const CallControlUpdateContactInfoCommand_1 = require("./commands/CallControlUpdateContactInfoCommand");
const CreatePbxAclGroupCommand_1 = require("./commands/CreatePbxAclGroupCommand");
const CreatePbxColleagueCommand_1 = require("./commands/CreatePbxColleagueCommand");
const CreatePbxOAuth2ClientCommand_1 = require("./commands/CreatePbxOAuth2ClientCommand");
const DeletePbxAclGroupCommand_1 = require("./commands/DeletePbxAclGroupCommand");
const DeletePbxColleagueCommand_1 = require("./commands/DeletePbxColleagueCommand");
const DeletePbxOAuth2ClientCommand_1 = require("./commands/DeletePbxOAuth2ClientCommand");
const GetCallQueuesSettingsCommand_1 = require("./commands/GetCallQueuesSettingsCommand");
const GetColleagueByIdCommand_1 = require("./commands/GetColleagueByIdCommand");
const GetPbxAclGroupsPermissionsCommand_1 = require("./commands/GetPbxAclGroupsPermissionsCommand");
const GetPbxCallGroupsCommand_1 = require("./commands/GetPbxCallGroupsCommand");
const GetPbxColleaguesCommand_1 = require("./commands/GetPbxColleaguesCommand");
const GetPbxOAuth2ClientsCommand_1 = require("./commands/GetPbxOAuth2ClientsCommand");
const GetPbxesCommand_1 = require("./commands/GetPbxesCommand");
const GetPersonalInfoCommand_1 = require("./commands/GetPersonalInfoCommand");
const ListPbxDepartmentsCommand_1 = require("./commands/ListPbxDepartmentsCommand");
const ListPbxGroupsCommand_1 = require("./commands/ListPbxGroupsCommand");
const ListUserActiveCallsCommand_1 = require("./commands/ListUserActiveCallsCommand");
const ListUserDevicesCommand_1 = require("./commands/ListUserDevicesCommand");
const NotificationsCommand_1 = require("./commands/NotificationsCommand");
const OriginateCallCommand_1 = require("./commands/OriginateCallCommand");
const OriginateCommand_1 = require("./commands/OriginateCommand");
const ReloadBroadcastsCommand_1 = require("./commands/ReloadBroadcastsCommand");
const UpdatePbxOAuth2ClientCommand_1 = require("./commands/UpdatePbxOAuth2ClientCommand");
const smithy_client_1 = require("@smithy/smithy-client");
const commands = {
    CallControlAnswerCommand: CallControlAnswerCommand_1.CallControlAnswerCommand,
    CallControlAttendantTransferCommand: CallControlAttendantTransferCommand_1.CallControlAttendantTransferCommand,
    CallControlBlindTransferCommand: CallControlBlindTransferCommand_1.CallControlBlindTransferCommand,
    CallControlDtmfCommand: CallControlDtmfCommand_1.CallControlDtmfCommand,
    CallControlHangupCommand: CallControlHangupCommand_1.CallControlHangupCommand,
    CallControlHoldCommand: CallControlHoldCommand_1.CallControlHoldCommand,
    CallControlMakeCallCommand: CallControlMakeCallCommand_1.CallControlMakeCallCommand,
    CallControlUnholdCommand: CallControlUnholdCommand_1.CallControlUnholdCommand,
    CallControlUpdateContactInfoCommand: CallControlUpdateContactInfoCommand_1.CallControlUpdateContactInfoCommand,
    CreatePbxAclGroupCommand: CreatePbxAclGroupCommand_1.CreatePbxAclGroupCommand,
    CreatePbxColleagueCommand: CreatePbxColleagueCommand_1.CreatePbxColleagueCommand,
    CreatePbxOAuth2ClientCommand: CreatePbxOAuth2ClientCommand_1.CreatePbxOAuth2ClientCommand,
    DeletePbxAclGroupCommand: DeletePbxAclGroupCommand_1.DeletePbxAclGroupCommand,
    DeletePbxColleagueCommand: DeletePbxColleagueCommand_1.DeletePbxColleagueCommand,
    DeletePbxOAuth2ClientCommand: DeletePbxOAuth2ClientCommand_1.DeletePbxOAuth2ClientCommand,
    GetCallQueuesSettingsCommand: GetCallQueuesSettingsCommand_1.GetCallQueuesSettingsCommand,
    GetColleagueByIdCommand: GetColleagueByIdCommand_1.GetColleagueByIdCommand,
    GetPbxAclGroupsPermissionsCommand: GetPbxAclGroupsPermissionsCommand_1.GetPbxAclGroupsPermissionsCommand,
    GetPbxCallGroupsCommand: GetPbxCallGroupsCommand_1.GetPbxCallGroupsCommand,
    GetPbxColleaguesCommand: GetPbxColleaguesCommand_1.GetPbxColleaguesCommand,
    GetPbxesCommand: GetPbxesCommand_1.GetPbxesCommand,
    GetPbxOAuth2ClientsCommand: GetPbxOAuth2ClientsCommand_1.GetPbxOAuth2ClientsCommand,
    GetPersonalInfoCommand: GetPersonalInfoCommand_1.GetPersonalInfoCommand,
    ListPbxDepartmentsCommand: ListPbxDepartmentsCommand_1.ListPbxDepartmentsCommand,
    ListPbxGroupsCommand: ListPbxGroupsCommand_1.ListPbxGroupsCommand,
    ListUserActiveCallsCommand: ListUserActiveCallsCommand_1.ListUserActiveCallsCommand,
    ListUserDevicesCommand: ListUserDevicesCommand_1.ListUserDevicesCommand,
    NotificationsCommand: NotificationsCommand_1.NotificationsCommand,
    OriginateCommand: OriginateCommand_1.OriginateCommand,
    OriginateCallCommand: OriginateCallCommand_1.OriginateCallCommand,
    ReloadBroadcastsCommand: ReloadBroadcastsCommand_1.ReloadBroadcastsCommand,
    UpdatePbxOAuth2ClientCommand: UpdatePbxOAuth2ClientCommand_1.UpdatePbxOAuth2ClientCommand,
};
class WmsApi extends WmsApiClient_1.WmsApiClient {
}
exports.WmsApi = WmsApi;
(0, smithy_client_1.createAggregatedClient)(commands, WmsApi);
