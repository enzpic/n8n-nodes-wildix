"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseResult = exports.PbxColleaguesSearchStrategy = exports.PbxColleaguesQueryField = exports.GetPbxColleaguesDir = exports.WmsNotFoundException = exports.WmsValidationException = exports.PbxColleagueRole = exports.WmsUnauthorizedException = exports.WmsForbiddenException = exports.ChannelNotFoundException = exports.ResponseType = exports.AclGroupPermissionAbility = exports.PbxLicenseType = void 0;
const WmsApiServiceException_1 = require("./WmsApiServiceException");
exports.PbxLicenseType = {
    BASIC: "basic",
    BUSINESS: "business",
    ESSENTIAL: "essential",
    PREMIUM: "premium",
    WIZYCONF: "wizyconf",
};
exports.AclGroupPermissionAbility = {
    CAN: "can",
    CANNOT: "cannot",
    NO: "no",
    NOUSE: "nouse",
    USE: "use",
    YES: "yes",
};
exports.ResponseType = {
    ERROR: "error",
    RESULT: "result",
};
class ChannelNotFoundException extends WmsApiServiceException_1.WmsApiServiceException {
    name = "ChannelNotFoundException";
    $fault = "client";
    type;
    reason;
    constructor(opts) {
        super({
            name: "ChannelNotFoundException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, ChannelNotFoundException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
    }
}
exports.ChannelNotFoundException = ChannelNotFoundException;
class WmsForbiddenException extends WmsApiServiceException_1.WmsApiServiceException {
    name = "WmsForbiddenException";
    $fault = "client";
    type;
    reason;
    constructor(opts) {
        super({
            name: "WmsForbiddenException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, WmsForbiddenException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
    }
}
exports.WmsForbiddenException = WmsForbiddenException;
class WmsUnauthorizedException extends WmsApiServiceException_1.WmsApiServiceException {
    name = "WmsUnauthorizedException";
    $fault = "client";
    type;
    reason;
    constructor(opts) {
        super({
            name: "WmsUnauthorizedException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, WmsUnauthorizedException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
    }
}
exports.WmsUnauthorizedException = WmsUnauthorizedException;
exports.PbxColleagueRole = {
    ADMIN: "admin",
    FAX: "fax",
    PARK_ORBIT: "park_orbit",
    ROOM: "room",
    USER: "user",
};
class WmsValidationException extends WmsApiServiceException_1.WmsApiServiceException {
    name = "WmsValidationException";
    $fault = "client";
    type;
    reason;
    errors;
    constructor(opts) {
        super({
            name: "WmsValidationException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, WmsValidationException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
        this.errors = opts.errors;
    }
}
exports.WmsValidationException = WmsValidationException;
class WmsNotFoundException extends WmsApiServiceException_1.WmsApiServiceException {
    name = "WmsNotFoundException";
    $fault = "client";
    type;
    reason;
    constructor(opts) {
        super({
            name: "WmsNotFoundException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, WmsNotFoundException.prototype);
        this.type = opts.type;
        this.reason = opts.reason;
    }
}
exports.WmsNotFoundException = WmsNotFoundException;
exports.GetPbxColleaguesDir = {
    ASC: "asc",
    DESC: "desc",
};
exports.PbxColleaguesQueryField = {
    DEPARTMENT: "department",
    DIALPLAN: "dialplan",
    EMAIL: "email",
    EXTENSION: "extension",
    FAX_DIALPLAN: "faxDialplan",
    GROUP_DN: "groupDn",
    ID: "id",
    LANGUAGE: "language",
    LICENSE_TYPE: "licenseType",
    LOGIN: "login",
    MOBILE_PHONE: "mobilePhone",
    NAME: "name",
    OFFICE_PHONE: "officePhone",
    PBX_DN: "pbxDn",
    PICTURE: "picture",
    ROLE: "role",
    SOURCE_ID: "sourceId",
};
exports.PbxColleaguesSearchStrategy = {
    CONTAIN: "contain",
    STARTS_WITH: "startsWith",
};
exports.ResponseResult = {
    SUCCESS: "Success",
};
