"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WmsApiClient = exports.__Client = void 0;
const runtimeConfig_1 = require("./runtimeConfig");
const runtimeExtensions_1 = require("./runtimeExtensions");
const middleware_user_agent_1 = require("@aws-sdk/middleware-user-agent");
const middleware_content_length_1 = require("@smithy/middleware-content-length");
const middleware_retry_1 = require("@smithy/middleware-retry");
const smithy_client_1 = require("@smithy/smithy-client");
Object.defineProperty(exports, "__Client", { enumerable: true, get: function () { return smithy_client_1.Client; } });
const smithy_utils_1 = require("@wildix/smithy-utils");
class WmsApiClient extends smithy_client_1.Client {
    config;
    constructor(...[configuration]) {
        let _config_0 = (0, runtimeConfig_1.getRuntimeConfig)(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        let _config_1 = (0, middleware_user_agent_1.resolveUserAgentConfig)(_config_0);
        let _config_2 = (0, middleware_retry_1.resolveRetryConfig)(_config_1);
        let _config_3 = (0, runtimeExtensions_1.resolveRuntimeExtensions)(_config_2, configuration?.extensions || []);
        const hostname = configuration.domain.endsWith("wildixin.com") ? configuration.domain : `${configuration.domain}.wildixin.com`;
        const endpoint = () => {
            return {
                hostname,
                protocol: "https",
                port: configuration.port ? String(configuration.port) : '443',
                path: ''
            };
        };
        const config = { ..._config_3, endpoint };
        this.config = config;
        this.middlewareStack.add(smithy_utils_1.authorizationMiddleware.bind(this, configuration.token), { step: "build" });
        this.middlewareStack.use((0, middleware_user_agent_1.getUserAgentPlugin)(this.config));
        this.middlewareStack.use((0, middleware_retry_1.getRetryPlugin)(this.config));
        this.middlewareStack.use((0, middleware_content_length_1.getContentLengthPlugin)(this.config));
    }
    destroy() {
        super.destroy();
    }
}
exports.WmsApiClient = WmsApiClient;
