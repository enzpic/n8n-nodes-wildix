"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.de_GetPbxAclGroupsPermissionsCommand = exports.de_GetColleagueByIdCommand = exports.de_GetCallQueuesSettingsCommand = exports.de_DeletePbxOAuth2ClientCommand = exports.de_DeletePbxColleagueCommand = exports.de_DeletePbxAclGroupCommand = exports.de_CreatePbxOAuth2ClientCommand = exports.de_CreatePbxColleagueCommand = exports.de_CreatePbxAclGroupCommand = exports.de_CallControlUpdateContactInfoCommand = exports.de_CallControlUnholdCommand = exports.de_CallControlMakeCallCommand = exports.de_CallControlHoldCommand = exports.de_CallControlHangupCommand = exports.de_CallControlDtmfCommand = exports.de_CallControlBlindTransferCommand = exports.de_CallControlAttendantTransferCommand = exports.de_CallControlAnswerCommand = exports.se_UpdatePbxOAuth2ClientCommand = exports.se_ReloadBroadcastsCommand = exports.se_OriginateCallCommand = exports.se_OriginateCommand = exports.se_NotificationsCommand = exports.se_ListUserDevicesCommand = exports.se_ListUserActiveCallsCommand = exports.se_ListPbxGroupsCommand = exports.se_ListPbxDepartmentsCommand = exports.se_GetPersonalInfoCommand = exports.se_GetPbxOAuth2ClientsCommand = exports.se_GetPbxesCommand = exports.se_GetPbxColleaguesCommand = exports.se_GetPbxCallGroupsCommand = exports.se_GetPbxAclGroupsPermissionsCommand = exports.se_GetColleagueByIdCommand = exports.se_GetCallQueuesSettingsCommand = exports.se_DeletePbxOAuth2ClientCommand = exports.se_DeletePbxColleagueCommand = exports.se_DeletePbxAclGroupCommand = exports.se_CreatePbxOAuth2ClientCommand = exports.se_CreatePbxColleagueCommand = exports.se_CreatePbxAclGroupCommand = exports.se_CallControlUpdateContactInfoCommand = exports.se_CallControlUnholdCommand = exports.se_CallControlMakeCallCommand = exports.se_CallControlHoldCommand = exports.se_CallControlHangupCommand = exports.se_CallControlDtmfCommand = exports.se_CallControlBlindTransferCommand = exports.se_CallControlAttendantTransferCommand = exports.se_CallControlAnswerCommand = void 0;
exports.de_UpdatePbxOAuth2ClientCommand = exports.de_ReloadBroadcastsCommand = exports.de_OriginateCallCommand = exports.de_OriginateCommand = exports.de_NotificationsCommand = exports.de_ListUserDevicesCommand = exports.de_ListUserActiveCallsCommand = exports.de_ListPbxGroupsCommand = exports.de_ListPbxDepartmentsCommand = exports.de_GetPersonalInfoCommand = exports.de_GetPbxOAuth2ClientsCommand = exports.de_GetPbxesCommand = exports.de_GetPbxColleaguesCommand = exports.de_GetPbxCallGroupsCommand = void 0;
const WmsApiServiceException_1 = require("../models/WmsApiServiceException");
const models_0_1 = require("../models/models_0");
const core_1 = require("@aws-sdk/core");
const core_2 = require("@smithy/core");
const smithy_client_1 = require("@smithy/smithy-client");
const se_CallControlAnswerCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/answer");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'device': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_CallControlAnswerCommand = se_CallControlAnswerCommand;
const se_CallControlAttendantTransferCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/attendant-transfer");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'destination': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_CallControlAttendantTransferCommand = se_CallControlAttendantTransferCommand;
const se_CallControlBlindTransferCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/blind-transfer");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'destination': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_CallControlBlindTransferCommand = se_CallControlBlindTransferCommand;
const se_CallControlDtmfCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/dtmf");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'digits': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_CallControlDtmfCommand = se_CallControlDtmfCommand;
const se_CallControlHangupCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/hangup");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'reason': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_CallControlHangupCommand = se_CallControlHangupCommand;
const se_CallControlHoldCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/hold");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_CallControlHoldCommand = se_CallControlHoldCommand;
const se_CallControlMakeCallCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/make-call");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'destination': [],
        'device': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_CallControlMakeCallCommand = se_CallControlMakeCallCommand;
const se_CallControlUnholdCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/unhold");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_CallControlUnholdCommand = se_CallControlUnholdCommand;
const se_CallControlUpdateContactInfoCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v2/call-control/update-contact-info");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'name': [],
        'phone': [],
        'sipCallId': [],
    }));
    b.m("POST")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_CallControlUpdateContactInfoCommand = se_CallControlUpdateContactInfoCommand;
const se_CreatePbxAclGroupCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/pbx/aclgroups");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'inherits': [],
        'name': [],
        'rules': _ => (0, smithy_client_1._json)(_),
        'wcgrp': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_CreatePbxAclGroupCommand = se_CreatePbxAclGroupCommand;
const se_CreatePbxColleagueCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/PBX/Colleagues");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'department': [],
        'dialplan': [],
        'email': [],
        'extension': [],
        'faxDialplan': [],
        'faxNumber': [],
        'groupDn': [],
        'language': [],
        'licenseType': [],
        'login': [],
        'mobilePhone': [],
        'name': [],
        'officePhone': [],
        'password': [],
        'role': [],
        'sipPassword': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_CreatePbxColleagueCommand = se_CreatePbxColleagueCommand;
const se_CreatePbxOAuth2ClientCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/pbx/applications/oauth2");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'expireTime': [],
        'name': [],
        'redirectUri': _ => (0, smithy_client_1._json)(_),
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_CreatePbxOAuth2ClientCommand = se_CreatePbxOAuth2ClientCommand;
const se_DeletePbxAclGroupCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/aclgroups/{id}");
    b.p('id', () => input.id.toString(), '{id}', false);
    let body;
    b.m("DELETE")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_DeletePbxAclGroupCommand = se_DeletePbxAclGroupCommand;
const se_DeletePbxColleagueCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/PBX/Colleagues/{id}");
    b.p('id', () => input.id.toString(), '{id}', false);
    let body;
    b.m("DELETE")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_DeletePbxColleagueCommand = se_DeletePbxColleagueCommand;
const se_DeletePbxOAuth2ClientCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/applications/oauth2/{id}");
    b.p('id', () => input.id, '{id}', false);
    let body;
    b.m("DELETE")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_DeletePbxOAuth2ClientCommand = se_DeletePbxOAuth2ClientCommand;
const se_GetCallQueuesSettingsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/settings/callqueues/{groupId}");
    b.p('groupId', () => input.groupId.toString(), '{groupId}', false);
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_GetCallQueuesSettingsCommand = se_GetCallQueuesSettingsCommand;
const se_GetColleagueByIdCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/Colleagues/{id}");
    b.p('id', () => input.id.toString(), '{id}', false);
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_GetColleagueByIdCommand = se_GetColleagueByIdCommand;
const se_GetPbxAclGroupsPermissionsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/aclgroups/permissions");
    const query = (0, smithy_client_1.map)({
        [_gr]: [() => input.groups !== void 0, () => ((input[_g] || []))],
        [_pe]: [() => input.permissions !== void 0, () => ((input[_p] || []))],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_GetPbxAclGroupsPermissionsCommand = se_GetPbxAclGroupsPermissionsCommand;
const se_GetPbxCallGroupsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/Dialplan/CallGroups");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_GetPbxCallGroupsCommand = se_GetPbxCallGroupsCommand;
const se_GetPbxColleaguesCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/PBX/Colleagues");
    const query = (0, smithy_client_1.map)({
        [_f]: [() => input.extension !== void 0, () => ((input[_e] || []))],
        [_fi]: [() => input.id !== void 0, () => ((input[_i] || []))],
        [_fP]: [() => input.officePhone !== void 0, () => ((input[_oP] || []))],
        [_fPi]: [() => input.mobilePhone !== void 0, () => ((input[_mP] || []))],
        [_fil]: [() => input.name !== void 0, () => ((input[_n] || []))],
        [_filt]: [() => input.email !== void 0, () => ((input[_em] || []))],
        [_filte]: [() => input.role !== void 0, () => ((input[_r] || []))],
        [_filter]: [() => input.dialplan !== void 0, () => ((input[_d] || []))],
        [_fDi]: [() => input.faxDialplan !== void 0, () => ((input[_fD] || []))],
        [_filterd]: [() => input.department !== void 0, () => ((input[_de] || []))],
        [_filterl]: [() => input.login !== void 0, () => ((input[_l] || []))],
        [_fDil]: [() => input.groupDn !== void 0, () => ((input[_gD] || []))],
        [_fDilt]: [() => input.pbxDn !== void 0, () => ((input[_pD] || []))],
        [_fT]: [() => input.licenseType !== void 0, () => ((input[_lT] || []))],
        [_fie]: [() => input.fields !== void 0, () => ((input[_fie] || []).join(','))],
        [_sF]: [() => input.searchFields !== void 0, () => ((input[_sF] || []).join(','))],
        [_s]: [, input[_s]],
        [_so]: [() => input.sort !== void 0, () => ((input[_so] || []))],
        [_st]: [() => input.start !== void 0, () => (input[_st].toString())],
        [_c]: [() => input.count !== void 0, () => (input[_c].toString())],
        [_di]: [, input[_di]],
        [_sS]: [, input[_sS]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_GetPbxColleaguesCommand = se_GetPbxColleaguesCommand;
const se_GetPbxesCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/network/pbxes");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_GetPbxesCommand = se_GetPbxesCommand;
const se_GetPbxOAuth2ClientsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/pbx/applications/oauth2");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_GetPbxOAuth2ClientsCommand = se_GetPbxOAuth2ClientsCommand;
const se_GetPersonalInfoCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/personal/info");
    const query = (0, smithy_client_1.map)({
        [_f]: [() => input.extension !== void 0, () => ((input[_e] || []))],
        [_fi]: [() => input.id !== void 0, () => ((input[_i] || []))],
        [_fP]: [() => input.officePhone !== void 0, () => ((input[_oP] || []))],
        [_fPi]: [() => input.mobilePhone !== void 0, () => ((input[_mP] || []))],
        [_fil]: [() => input.name !== void 0, () => ((input[_n] || []))],
        [_filt]: [() => input.email !== void 0, () => ((input[_em] || []))],
        [_filte]: [() => input.role !== void 0, () => ((input[_r] || []))],
        [_filter]: [() => input.dialplan !== void 0, () => ((input[_d] || []))],
        [_fDi]: [() => input.faxDialplan !== void 0, () => ((input[_fD] || []))],
        [_filterd]: [() => input.department !== void 0, () => ((input[_de] || []))],
        [_filterl]: [() => input.login !== void 0, () => ((input[_l] || []))],
        [_fDil]: [() => input.groupDn !== void 0, () => ((input[_gD] || []))],
        [_fDilt]: [() => input.pbxDn !== void 0, () => ((input[_pD] || []))],
        [_fT]: [() => input.licenseType !== void 0, () => ((input[_lT] || []))],
        [_fie]: [() => input.fields !== void 0, () => ((input[_fie] || []))],
        [_sF]: [() => input.searchFields !== void 0, () => ((input[_sF] || []))],
        [_s]: [, input[_s]],
        [_so]: [() => input.sort !== void 0, () => ((input[_so] || []))],
        [_st]: [() => input.start !== void 0, () => (input[_st].toString())],
        [_c]: [() => input.count !== void 0, () => (input[_c].toString())],
        [_di]: [, input[_di]],
        [_sS]: [, input[_sS]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_GetPersonalInfoCommand = se_GetPersonalInfoCommand;
const se_ListPbxDepartmentsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/Departments");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_ListPbxDepartmentsCommand = se_ListPbxDepartmentsCommand;
const se_ListPbxGroupsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/Groups");
    let body;
    b.m("GET")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_ListPbxGroupsCommand = se_ListPbxGroupsCommand;
const se_ListUserActiveCallsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v2/call-control/list-calls");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_ListUserActiveCallsCommand = se_ListUserActiveCallsCommand;
const se_ListUserDevicesCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v2/call-control/list-devices");
    const query = (0, smithy_client_1.map)({
        [_u]: [, input[_u]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_ListUserDevicesCommand = se_ListUserDevicesCommand;
const se_NotificationsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/notifications");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'broadcastId': [],
        'broadcastMessage': [],
        'confirmationTimeout': [],
        'customRid': [],
        'event': [],
        'from': [],
        'notificationType': [],
        'origin': [],
        'playFrequency': [],
        'priority': [],
        'queueTimeout': [],
        'skipTranscribe': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_NotificationsCommand = se_NotificationsCommand;
const se_OriginateCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/originate");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'account': [],
        'actionid': [],
        'application': [],
        'async': [],
        'callerid': [],
        'channel': [],
        'context': [],
        'data': [],
        'exten': [],
        'priority': [],
        'timeout': [],
        'variable': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_OriginateCommand = se_OriginateCommand;
const se_OriginateCallCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/originate/call");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'name': [],
        'number': [],
        'postpone': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_OriginateCallCommand = se_OriginateCallCommand;
const se_ReloadBroadcastsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/api/v1/broadcasts/reload");
    let body;
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_ReloadBroadcastsCommand = se_ReloadBroadcastsCommand;
const se_UpdatePbxOAuth2ClientCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/api/v1/pbx/applications/oauth2/{id}");
    b.p('id', () => input.id, '{id}', false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'name': [],
        'redirectUri': _ => (0, smithy_client_1._json)(_),
    }));
    b.m("PUT")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_UpdatePbxOAuth2ClientCommand = se_UpdatePbxOAuth2ClientCommand;
const de_CallControlAnswerCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'message': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CallControlAnswerCommand = de_CallControlAnswerCommand;
const de_CallControlAttendantTransferCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'message': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CallControlAttendantTransferCommand = de_CallControlAttendantTransferCommand;
const de_CallControlBlindTransferCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'message': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CallControlBlindTransferCommand = de_CallControlBlindTransferCommand;
const de_CallControlDtmfCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'message': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CallControlDtmfCommand = de_CallControlDtmfCommand;
const de_CallControlHangupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'message': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CallControlHangupCommand = de_CallControlHangupCommand;
const de_CallControlHoldCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'message': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CallControlHoldCommand = de_CallControlHoldCommand;
const de_CallControlMakeCallCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'message': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CallControlMakeCallCommand = de_CallControlMakeCallCommand;
const de_CallControlUnholdCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'message': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CallControlUnholdCommand = de_CallControlUnholdCommand;
const de_CallControlUpdateContactInfoCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'message': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CallControlUpdateContactInfoCommand = de_CallControlUpdateContactInfoCommand;
const de_CreatePbxAclGroupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CreatePbxAclGroupCommand = de_CreatePbxAclGroupCommand;
const de_CreatePbxColleagueCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CreatePbxColleagueCommand = de_CreatePbxColleagueCommand;
const de_CreatePbxOAuth2ClientCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CreatePbxOAuth2ClientCommand = de_CreatePbxOAuth2ClientCommand;
const de_DeletePbxAclGroupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_DeletePbxAclGroupCommand = de_DeletePbxAclGroupCommand;
const de_DeletePbxColleagueCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_DeletePbxColleagueCommand = de_DeletePbxColleagueCommand;
const de_DeletePbxOAuth2ClientCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_DeletePbxOAuth2ClientCommand = de_DeletePbxOAuth2ClientCommand;
const de_GetCallQueuesSettingsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetCallQueuesSettingsCommand = de_GetCallQueuesSettingsCommand;
const de_GetColleagueByIdCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetColleagueByIdCommand = de_GetColleagueByIdCommand;
const de_GetPbxAclGroupsPermissionsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetPbxAclGroupsPermissionsCommand = de_GetPbxAclGroupsPermissionsCommand;
const de_GetPbxCallGroupsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetPbxCallGroupsCommand = de_GetPbxCallGroupsCommand;
const de_GetPbxColleaguesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetPbxColleaguesCommand = de_GetPbxColleaguesCommand;
const de_GetPbxesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetPbxesCommand = de_GetPbxesCommand;
const de_GetPbxOAuth2ClientsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetPbxOAuth2ClientsCommand = de_GetPbxOAuth2ClientsCommand;
const de_GetPersonalInfoCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetPersonalInfoCommand = de_GetPersonalInfoCommand;
const de_ListPbxDepartmentsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': _ => de_ListPbxDepartmentsResult(_, context),
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListPbxDepartmentsCommand = de_ListPbxDepartmentsCommand;
const de_ListPbxGroupsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListPbxGroupsCommand = de_ListPbxGroupsCommand;
const de_ListUserActiveCallsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'calls': smithy_client_1._json,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListUserActiveCallsCommand = de_ListUserActiveCallsCommand;
const de_ListUserDevicesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'activeDevice': smithy_client_1._json,
        'devices': smithy_client_1._json,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListUserDevicesCommand = de_ListUserDevicesCommand;
const de_NotificationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_NotificationsCommand = de_NotificationsCommand;
const de_OriginateCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_OriginateCommand = de_OriginateCommand;
const de_OriginateCallCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_OriginateCallCommand = de_OriginateCallCommand;
const de_ReloadBroadcastsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ReloadBroadcastsCommand = de_ReloadBroadcastsCommand;
const de_UpdatePbxOAuth2ClientCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_UpdatePbxOAuth2ClientCommand = de_UpdatePbxOAuth2ClientCommand;
const de_CommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await (0, core_1.parseJsonErrorBody)(output.body, context)
    };
    const errorCode = (0, core_1.loadRestJsonErrorCode)(output, parsedOutput.body);
    switch (errorCode) {
        case "ChannelNotFoundException":
        case "wildix.wms.api#ChannelNotFoundException":
            throw await de_ChannelNotFoundExceptionRes(parsedOutput, context);
        case "WmsForbiddenException":
        case "wildix.wms.api#WmsForbiddenException":
            throw await de_WmsForbiddenExceptionRes(parsedOutput, context);
        case "WmsUnauthorizedException":
        case "wildix.wms.api#WmsUnauthorizedException":
            throw await de_WmsUnauthorizedExceptionRes(parsedOutput, context);
        case "WmsValidationException":
        case "wildix.wms.api#WmsValidationException":
            throw await de_WmsValidationExceptionRes(parsedOutput, context);
        case "WmsNotFoundException":
        case "wildix.wms.api#WmsNotFoundException":
            throw await de_WmsNotFoundExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const throwDefaultError = (0, smithy_client_1.withBaseException)(WmsApiServiceException_1.WmsApiServiceException);
const de_ChannelNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'reason': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.ChannelNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_WmsForbiddenExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'reason': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.WmsForbiddenException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_WmsNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'reason': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.WmsNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_WmsUnauthorizedExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'reason': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.WmsUnauthorizedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_WmsValidationExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'errors': smithy_client_1._json,
        'reason': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.WmsValidationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ListPbxDepartmentsResult = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'records': (_) => de_PbxDepartmentsList(_, context),
    });
};
const de_PbxDepartment = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'id': smithy_client_1.expectString,
        'items': (_) => de_PbxDepartmentsList(_, context),
        'name': smithy_client_1.expectString,
        'users': smithy_client_1._json,
    });
};
const de_PbxDepartmentsList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_PbxDepartment(entry, context);
    });
    return retVal;
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBodyString = (streamBody, context) => (0, smithy_client_1.collectBody)(streamBody, context).then(body => context.utf8Encoder(body));
const _c = "count";
const _d = "dialplan";
const _de = "department";
const _di = "dir";
const _e = "extension";
const _em = "email";
const _f = "filter[extension][]";
const _fD = "faxDialplan";
const _fDi = "filter[faxDialplan][]";
const _fDil = "filter[groupDn][]";
const _fDilt = "filter[pbxDn][]";
const _fP = "filter[officePhone][]";
const _fPi = "filter[mobilePhone][]";
const _fT = "filter[licenseType][]";
const _fi = "filter[id][]";
const _fie = "fields";
const _fil = "filter[name][]";
const _filt = "filter[email][]";
const _filte = "filter[role][]";
const _filter = "filter[dialplan][]";
const _filterd = "filter[department][]";
const _filterl = "filter[login][]";
const _g = "groups";
const _gD = "groupDn";
const _gr = "groups[]";
const _i = "id";
const _l = "login";
const _lT = "licenseType";
const _mP = "mobilePhone";
const _n = "name";
const _oP = "officePhone";
const _p = "permissions";
const _pD = "pbxDn";
const _pe = "permissions[]";
const _r = "role";
const _s = "search";
const _sF = "searchFields";
const _sS = "searchStrategy";
const _so = "sort";
const _st = "start";
const _u = "user";
