import { ClassoundClient } from "./ClassoundClient";
import { CleanupTangoEsimOrderCommandInput, CleanupTangoEsimOrderCommandOutput } from "./commands/CleanupTangoEsimOrderCommand";
import { CreateNumbersOrderCommandInput, CreateNumbersOrderCommandOutput } from "./commands/CreateNumbersOrderCommand";
import { CreateTangoEsimOrderCommandInput, CreateTangoEsimOrderCommandOutput } from "./commands/CreateTangoEsimOrderCommand";
import { DeleteEsimEndpointCommandInput, DeleteEsimEndpointCommandOutput } from "./commands/DeleteEsimEndpointCommand";
import { GetEsimQrCodeCommandInput, GetEsimQrCodeCommandOutput } from "./commands/GetEsimQrCodeCommand";
import { GetEsimStatusCommandInput, GetEsimStatusCommandOutput } from "./commands/GetEsimStatusCommand";
import { GetSmsHistoryCommandInput, GetSmsHistoryCommandOutput } from "./commands/GetSmsHistoryCommand";
import { ListEsimBundlesCommandInput, ListEsimBundlesCommandOutput } from "./commands/ListEsimBundlesCommand";
import { ListEsimSubscribersCommandInput, ListEsimSubscribersCommandOutput } from "./commands/ListEsimSubscribersCommand";
import { ListSmsNumbersCommandInput, ListSmsNumbersCommandOutput } from "./commands/ListSmsNumbersCommand";
import { ListWhatsAppNumbersCommandInput, ListWhatsAppNumbersCommandOutput } from "./commands/ListWhatsAppNumbersCommand";
import { ListWhatsAppTemplatesCommandInput, ListWhatsAppTemplatesCommandOutput } from "./commands/ListWhatsAppTemplatesCommand";
import { ProvisionEsimSubscriberCommandInput, ProvisionEsimSubscriberCommandOutput } from "./commands/ProvisionEsimSubscriberCommand";
import { RefreshEsimQrCodeCommandInput, RefreshEsimQrCodeCommandOutput } from "./commands/RefreshEsimQrCodeCommand";
import { SendSmsCommandInput, SendSmsCommandOutput } from "./commands/SendSmsCommand";
import { SendSmsFromApplicationCommandInput, SendSmsFromApplicationCommandOutput } from "./commands/SendSmsFromApplicationCommand";
import { SendWhatsAppInteractiveMessageCommandInput, SendWhatsAppInteractiveMessageCommandOutput } from "./commands/SendWhatsAppInteractiveMessageCommand";
import { SendWhatsAppMessageCommandInput, SendWhatsAppMessageCommandOutput } from "./commands/SendWhatsAppMessageCommand";
import { SendWhatsAppTemplateCommandInput, SendWhatsAppTemplateCommandOutput } from "./commands/SendWhatsAppTemplateCommand";
import { SyncEsimTransformsCommandInput, SyncEsimTransformsCommandOutput } from "./commands/SyncEsimTransformsCommand";
import { TerminateEsimSubscriberCommandInput, TerminateEsimSubscriberCommandOutput } from "./commands/TerminateEsimSubscriberCommand";
import { UpdateEsimSubscriberCommandInput, UpdateEsimSubscriberCommandOutput } from "./commands/UpdateEsimSubscriberCommand";
import { HttpHandlerOptions as __HttpHandlerOptions } from "@smithy/types";
export interface Classound {
    /**
     * @see {@link CleanupTangoEsimOrderCommand}
     */
    cleanupTangoEsimOrder(args: CleanupTangoEsimOrderCommandInput, options?: __HttpHandlerOptions): Promise<CleanupTangoEsimOrderCommandOutput>;
    cleanupTangoEsimOrder(args: CleanupTangoEsimOrderCommandInput, cb: (err: any, data?: CleanupTangoEsimOrderCommandOutput) => void): void;
    cleanupTangoEsimOrder(args: CleanupTangoEsimOrderCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CleanupTangoEsimOrderCommandOutput) => void): void;
    /**
     * @see {@link CreateNumbersOrderCommand}
     */
    createNumbersOrder(args: CreateNumbersOrderCommandInput, options?: __HttpHandlerOptions): Promise<CreateNumbersOrderCommandOutput>;
    createNumbersOrder(args: CreateNumbersOrderCommandInput, cb: (err: any, data?: CreateNumbersOrderCommandOutput) => void): void;
    createNumbersOrder(args: CreateNumbersOrderCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CreateNumbersOrderCommandOutput) => void): void;
    /**
     * @see {@link CreateTangoEsimOrderCommand}
     */
    createTangoEsimOrder(args: CreateTangoEsimOrderCommandInput, options?: __HttpHandlerOptions): Promise<CreateTangoEsimOrderCommandOutput>;
    createTangoEsimOrder(args: CreateTangoEsimOrderCommandInput, cb: (err: any, data?: CreateTangoEsimOrderCommandOutput) => void): void;
    createTangoEsimOrder(args: CreateTangoEsimOrderCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: CreateTangoEsimOrderCommandOutput) => void): void;
    /**
     * @see {@link DeleteEsimEndpointCommand}
     */
    deleteEsimEndpoint(args: DeleteEsimEndpointCommandInput, options?: __HttpHandlerOptions): Promise<DeleteEsimEndpointCommandOutput>;
    deleteEsimEndpoint(args: DeleteEsimEndpointCommandInput, cb: (err: any, data?: DeleteEsimEndpointCommandOutput) => void): void;
    deleteEsimEndpoint(args: DeleteEsimEndpointCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: DeleteEsimEndpointCommandOutput) => void): void;
    /**
     * @see {@link GetEsimQrCodeCommand}
     */
    getEsimQrCode(args: GetEsimQrCodeCommandInput, options?: __HttpHandlerOptions): Promise<GetEsimQrCodeCommandOutput>;
    getEsimQrCode(args: GetEsimQrCodeCommandInput, cb: (err: any, data?: GetEsimQrCodeCommandOutput) => void): void;
    getEsimQrCode(args: GetEsimQrCodeCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetEsimQrCodeCommandOutput) => void): void;
    /**
     * @see {@link GetEsimStatusCommand}
     */
    getEsimStatus(args: GetEsimStatusCommandInput, options?: __HttpHandlerOptions): Promise<GetEsimStatusCommandOutput>;
    getEsimStatus(args: GetEsimStatusCommandInput, cb: (err: any, data?: GetEsimStatusCommandOutput) => void): void;
    getEsimStatus(args: GetEsimStatusCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetEsimStatusCommandOutput) => void): void;
    /**
     * @see {@link GetSmsHistoryCommand}
     */
    getSmsHistory(): Promise<GetSmsHistoryCommandOutput>;
    getSmsHistory(args: GetSmsHistoryCommandInput, options?: __HttpHandlerOptions): Promise<GetSmsHistoryCommandOutput>;
    getSmsHistory(args: GetSmsHistoryCommandInput, cb: (err: any, data?: GetSmsHistoryCommandOutput) => void): void;
    getSmsHistory(args: GetSmsHistoryCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetSmsHistoryCommandOutput) => void): void;
    /**
     * @see {@link ListEsimBundlesCommand}
     */
    listEsimBundles(): Promise<ListEsimBundlesCommandOutput>;
    listEsimBundles(args: ListEsimBundlesCommandInput, options?: __HttpHandlerOptions): Promise<ListEsimBundlesCommandOutput>;
    listEsimBundles(args: ListEsimBundlesCommandInput, cb: (err: any, data?: ListEsimBundlesCommandOutput) => void): void;
    listEsimBundles(args: ListEsimBundlesCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ListEsimBundlesCommandOutput) => void): void;
    /**
     * @see {@link ListEsimSubscribersCommand}
     */
    listEsimSubscribers(): Promise<ListEsimSubscribersCommandOutput>;
    listEsimSubscribers(args: ListEsimSubscribersCommandInput, options?: __HttpHandlerOptions): Promise<ListEsimSubscribersCommandOutput>;
    listEsimSubscribers(args: ListEsimSubscribersCommandInput, cb: (err: any, data?: ListEsimSubscribersCommandOutput) => void): void;
    listEsimSubscribers(args: ListEsimSubscribersCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ListEsimSubscribersCommandOutput) => void): void;
    /**
     * @see {@link ListSmsNumbersCommand}
     */
    listSmsNumbers(args: ListSmsNumbersCommandInput, options?: __HttpHandlerOptions): Promise<ListSmsNumbersCommandOutput>;
    listSmsNumbers(args: ListSmsNumbersCommandInput, cb: (err: any, data?: ListSmsNumbersCommandOutput) => void): void;
    listSmsNumbers(args: ListSmsNumbersCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ListSmsNumbersCommandOutput) => void): void;
    /**
     * @see {@link ListWhatsAppNumbersCommand}
     */
    listWhatsAppNumbers(args: ListWhatsAppNumbersCommandInput, options?: __HttpHandlerOptions): Promise<ListWhatsAppNumbersCommandOutput>;
    listWhatsAppNumbers(args: ListWhatsAppNumbersCommandInput, cb: (err: any, data?: ListWhatsAppNumbersCommandOutput) => void): void;
    listWhatsAppNumbers(args: ListWhatsAppNumbersCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ListWhatsAppNumbersCommandOutput) => void): void;
    /**
     * @see {@link ListWhatsAppTemplatesCommand}
     */
    listWhatsAppTemplates(args: ListWhatsAppTemplatesCommandInput, options?: __HttpHandlerOptions): Promise<ListWhatsAppTemplatesCommandOutput>;
    listWhatsAppTemplates(args: ListWhatsAppTemplatesCommandInput, cb: (err: any, data?: ListWhatsAppTemplatesCommandOutput) => void): void;
    listWhatsAppTemplates(args: ListWhatsAppTemplatesCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ListWhatsAppTemplatesCommandOutput) => void): void;
    /**
     * @see {@link ProvisionEsimSubscriberCommand}
     */
    provisionEsimSubscriber(args: ProvisionEsimSubscriberCommandInput, options?: __HttpHandlerOptions): Promise<ProvisionEsimSubscriberCommandOutput>;
    provisionEsimSubscriber(args: ProvisionEsimSubscriberCommandInput, cb: (err: any, data?: ProvisionEsimSubscriberCommandOutput) => void): void;
    provisionEsimSubscriber(args: ProvisionEsimSubscriberCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ProvisionEsimSubscriberCommandOutput) => void): void;
    /**
     * @see {@link RefreshEsimQrCodeCommand}
     */
    refreshEsimQrCode(args: RefreshEsimQrCodeCommandInput, options?: __HttpHandlerOptions): Promise<RefreshEsimQrCodeCommandOutput>;
    refreshEsimQrCode(args: RefreshEsimQrCodeCommandInput, cb: (err: any, data?: RefreshEsimQrCodeCommandOutput) => void): void;
    refreshEsimQrCode(args: RefreshEsimQrCodeCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: RefreshEsimQrCodeCommandOutput) => void): void;
    /**
     * @see {@link SendSmsCommand}
     */
    sendSms(args: SendSmsCommandInput, options?: __HttpHandlerOptions): Promise<SendSmsCommandOutput>;
    sendSms(args: SendSmsCommandInput, cb: (err: any, data?: SendSmsCommandOutput) => void): void;
    sendSms(args: SendSmsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: SendSmsCommandOutput) => void): void;
    /**
     * @see {@link SendSmsFromApplicationCommand}
     */
    sendSmsFromApplication(args: SendSmsFromApplicationCommandInput, options?: __HttpHandlerOptions): Promise<SendSmsFromApplicationCommandOutput>;
    sendSmsFromApplication(args: SendSmsFromApplicationCommandInput, cb: (err: any, data?: SendSmsFromApplicationCommandOutput) => void): void;
    sendSmsFromApplication(args: SendSmsFromApplicationCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: SendSmsFromApplicationCommandOutput) => void): void;
    /**
     * @see {@link SendWhatsAppInteractiveMessageCommand}
     */
    sendWhatsAppInteractiveMessage(args: SendWhatsAppInteractiveMessageCommandInput, options?: __HttpHandlerOptions): Promise<SendWhatsAppInteractiveMessageCommandOutput>;
    sendWhatsAppInteractiveMessage(args: SendWhatsAppInteractiveMessageCommandInput, cb: (err: any, data?: SendWhatsAppInteractiveMessageCommandOutput) => void): void;
    sendWhatsAppInteractiveMessage(args: SendWhatsAppInteractiveMessageCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: SendWhatsAppInteractiveMessageCommandOutput) => void): void;
    /**
     * @see {@link SendWhatsAppMessageCommand}
     */
    sendWhatsAppMessage(args: SendWhatsAppMessageCommandInput, options?: __HttpHandlerOptions): Promise<SendWhatsAppMessageCommandOutput>;
    sendWhatsAppMessage(args: SendWhatsAppMessageCommandInput, cb: (err: any, data?: SendWhatsAppMessageCommandOutput) => void): void;
    sendWhatsAppMessage(args: SendWhatsAppMessageCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: SendWhatsAppMessageCommandOutput) => void): void;
    /**
     * @see {@link SendWhatsAppTemplateCommand}
     */
    sendWhatsAppTemplate(args: SendWhatsAppTemplateCommandInput, options?: __HttpHandlerOptions): Promise<SendWhatsAppTemplateCommandOutput>;
    sendWhatsAppTemplate(args: SendWhatsAppTemplateCommandInput, cb: (err: any, data?: SendWhatsAppTemplateCommandOutput) => void): void;
    sendWhatsAppTemplate(args: SendWhatsAppTemplateCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: SendWhatsAppTemplateCommandOutput) => void): void;
    /**
     * @see {@link SyncEsimTransformsCommand}
     */
    syncEsimTransforms(args: SyncEsimTransformsCommandInput, options?: __HttpHandlerOptions): Promise<SyncEsimTransformsCommandOutput>;
    syncEsimTransforms(args: SyncEsimTransformsCommandInput, cb: (err: any, data?: SyncEsimTransformsCommandOutput) => void): void;
    syncEsimTransforms(args: SyncEsimTransformsCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: SyncEsimTransformsCommandOutput) => void): void;
    /**
     * @see {@link TerminateEsimSubscriberCommand}
     */
    terminateEsimSubscriber(args: TerminateEsimSubscriberCommandInput, options?: __HttpHandlerOptions): Promise<TerminateEsimSubscriberCommandOutput>;
    terminateEsimSubscriber(args: TerminateEsimSubscriberCommandInput, cb: (err: any, data?: TerminateEsimSubscriberCommandOutput) => void): void;
    terminateEsimSubscriber(args: TerminateEsimSubscriberCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: TerminateEsimSubscriberCommandOutput) => void): void;
    /**
     * @see {@link UpdateEsimSubscriberCommand}
     */
    updateEsimSubscriber(args: UpdateEsimSubscriberCommandInput, options?: __HttpHandlerOptions): Promise<UpdateEsimSubscriberCommandOutput>;
    updateEsimSubscriber(args: UpdateEsimSubscriberCommandInput, cb: (err: any, data?: UpdateEsimSubscriberCommandOutput) => void): void;
    updateEsimSubscriber(args: UpdateEsimSubscriberCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: UpdateEsimSubscriberCommandOutput) => void): void;
}
/**
 * @public
 */
export declare class Classound extends ClassoundClient implements Classound {
}
