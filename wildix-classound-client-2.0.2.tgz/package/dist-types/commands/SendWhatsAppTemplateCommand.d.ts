import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { SendWhatsAppTemplateInput, SendWhatsAppTemplateOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link SendWhatsAppTemplateCommand}.
 */
export interface SendWhatsAppTemplateCommandInput extends SendWhatsAppTemplateInput {
}
/**
 * @public
 *
 * The output of {@link SendWhatsAppTemplateCommand}.
 */
export interface SendWhatsAppTemplateCommandOutput extends SendWhatsAppTemplateOutput, __MetadataBearer {
}
declare const SendWhatsAppTemplateCommand_base: {
    new (input: SendWhatsAppTemplateCommandInput): import("@smithy/smithy-client").CommandImpl<SendWhatsAppTemplateCommandInput, SendWhatsAppTemplateCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: SendWhatsAppTemplateCommandInput): import("@smithy/smithy-client").CommandImpl<SendWhatsAppTemplateCommandInput, SendWhatsAppTemplateCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, SendWhatsAppTemplateCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, SendWhatsAppTemplateCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // SendWhatsAppTemplateInput
 *   to: "STRING_VALUE", // required
 *   company: "STRING_VALUE", // required
 *   pbx: "STRING_VALUE", // required
 *   extension: "STRING_VALUE", // required
 *   from: "STRING_VALUE", // required
 *   channelId: "STRING_VALUE",
 *   messageId: "STRING_VALUE",
 *   userId: "STRING_VALUE",
 *   template: { // TemplateWithParameters
 *     name: "STRING_VALUE", // required
 *     parameters: [ // ListTemplateParameter
 *       { // TemplateParameter
 *         name: "STRING_VALUE", // required
 *         value: "STRING_VALUE", // required
 *       },
 *     ],
 *   },
 * };
 * const command = new SendWhatsAppTemplateCommand(input);
 * const response = await client.send(command);
 * // { // SendWhatsAppTemplateOutput
 * //   type: "STRING_VALUE", // required
 * //   success: true || false, // required
 * //   status: "STRING_VALUE", // required
 * //   id: "STRING_VALUE", // required
 * //   company: "STRING_VALUE", // required
 * //   data: { // SendWhatsAppTemplateData
 * //     from: "STRING_VALUE",
 * //     to: "STRING_VALUE",
 * //     template: { // TemplateWithParameters
 * //       name: "STRING_VALUE", // required
 * //       parameters: [ // ListTemplateParameter
 * //         { // TemplateParameter
 * //           name: "STRING_VALUE", // required
 * //           value: "STRING_VALUE", // required
 * //         },
 * //       ],
 * //     },
 * //     pbx: "STRING_VALUE",
 * //     extension: "STRING_VALUE",
 * //   },
 * // };
 *
 * ```
 *
 * @param SendWhatsAppTemplateCommandInput - {@link SendWhatsAppTemplateCommandInput}
 * @returns {@link SendWhatsAppTemplateCommandOutput}
 * @see {@link SendWhatsAppTemplateCommandInput} for command's `input` shape.
 * @see {@link SendWhatsAppTemplateCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class SendWhatsAppTemplateCommand extends SendWhatsAppTemplateCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: SendWhatsAppTemplateInput;
            output: SendWhatsAppTemplateOutput;
        };
        sdk: {
            input: SendWhatsAppTemplateCommandInput;
            output: SendWhatsAppTemplateCommandOutput;
        };
    };
}
