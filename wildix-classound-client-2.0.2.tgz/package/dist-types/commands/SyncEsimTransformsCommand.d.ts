import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { SyncEsimTransformsInput, SyncEsimTransformsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link SyncEsimTransformsCommand}.
 */
export interface SyncEsimTransformsCommandInput extends SyncEsimTransformsInput {
}
/**
 * @public
 *
 * The output of {@link SyncEsimTransformsCommand}.
 */
export interface SyncEsimTransformsCommandOutput extends SyncEsimTransformsOutput, __MetadataBearer {
}
declare const SyncEsimTransformsCommand_base: {
    new (input: SyncEsimTransformsCommandInput): import("@smithy/smithy-client").CommandImpl<SyncEsimTransformsCommandInput, SyncEsimTransformsCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: SyncEsimTransformsCommandInput): import("@smithy/smithy-client").CommandImpl<SyncEsimTransformsCommandInput, SyncEsimTransformsCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, SyncEsimTransformsCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, SyncEsimTransformsCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // SyncEsimTransformsInput
 *   companyId: "STRING_VALUE",
 *   transforms: [ // TransformEntryList // required
 *     { // TransformEntry
 *       extension: "STRING_VALUE", // required
 *       e164: "STRING_VALUE", // required
 *     },
 *   ],
 * };
 * const command = new SyncEsimTransformsCommand(input);
 * const response = await client.send(command);
 * // { // SyncEsimTransformsOutput
 * //   companyId: "STRING_VALUE", // required
 * //   added: Number("int"), // required
 * //   updated: Number("int"), // required
 * //   deleted: Number("int"), // required
 * //   errors: [ // TransformErrorList
 * //     { // TransformError
 * //       action: "STRING_VALUE",
 * //       extension: "STRING_VALUE",
 * //       error: "STRING_VALUE",
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param SyncEsimTransformsCommandInput - {@link SyncEsimTransformsCommandInput}
 * @returns {@link SyncEsimTransformsCommandOutput}
 * @see {@link SyncEsimTransformsCommandInput} for command's `input` shape.
 * @see {@link SyncEsimTransformsCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class SyncEsimTransformsCommand extends SyncEsimTransformsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: SyncEsimTransformsInput;
            output: SyncEsimTransformsOutput;
        };
        sdk: {
            input: SyncEsimTransformsCommandInput;
            output: SyncEsimTransformsCommandOutput;
        };
    };
}
