import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { ProvisionEsimSubscriberInput, ProvisionEsimSubscriberOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ProvisionEsimSubscriberCommand}.
 */
export interface ProvisionEsimSubscriberCommandInput extends ProvisionEsimSubscriberInput {
}
/**
 * @public
 *
 * The output of {@link ProvisionEsimSubscriberCommand}.
 */
export interface ProvisionEsimSubscriberCommandOutput extends ProvisionEsimSubscriberOutput, __MetadataBearer {
}
declare const ProvisionEsimSubscriberCommand_base: {
    new (input: ProvisionEsimSubscriberCommandInput): import("@smithy/smithy-client").CommandImpl<ProvisionEsimSubscriberCommandInput, ProvisionEsimSubscriberCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: ProvisionEsimSubscriberCommandInput): import("@smithy/smithy-client").CommandImpl<ProvisionEsimSubscriberCommandInput, ProvisionEsimSubscriberCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, ProvisionEsimSubscriberCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, ProvisionEsimSubscriberCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // ProvisionEsimSubscriberInput
 *   companyId: "STRING_VALUE",
 *   uid: "STRING_VALUE", // required
 *   serial: "STRING_VALUE", // required
 *   host: "STRING_VALUE", // required
 *   extension: "STRING_VALUE", // required
 *   phone: "STRING_VALUE", // required
 *   email: "STRING_VALUE", // required
 *   firstName: "STRING_VALUE",
 *   lastName: "STRING_VALUE",
 *   userPassword: "STRING_VALUE", // required
 *   bundle: "PLAN-VC-MSG-2G" || "PLAN-VC-MSG-4G" || "PLAN-VC-MSG-10G" || "PLAN-VC-MSG-20G" || "PLAN-VC-MSG-UNLTD" || "PLAN-VC-MSG-BKGND",
 * };
 * const command = new ProvisionEsimSubscriberCommand(input);
 * const response = await client.send(command);
 * // { // ProvisionEsimSubscriberOutput
 * //   status: "PROVISIONED" || "ALREADY_PROVISIONED", // required
 * //   companyId: "STRING_VALUE", // required
 * //   uid: "STRING_VALUE", // required
 * //   extension: "STRING_VALUE", // required
 * //   phone: "STRING_VALUE", // required
 * //   subUID: "STRING_VALUE", // required
 * //   iccid: "STRING_VALUE", // required
 * //   activationCode: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param ProvisionEsimSubscriberCommandInput - {@link ProvisionEsimSubscriberCommandInput}
 * @returns {@link ProvisionEsimSubscriberCommandOutput}
 * @see {@link ProvisionEsimSubscriberCommandInput} for command's `input` shape.
 * @see {@link ProvisionEsimSubscriberCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class ProvisionEsimSubscriberCommand extends ProvisionEsimSubscriberCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: ProvisionEsimSubscriberInput;
            output: ProvisionEsimSubscriberOutput;
        };
        sdk: {
            input: ProvisionEsimSubscriberCommandInput;
            output: ProvisionEsimSubscriberCommandOutput;
        };
    };
}
