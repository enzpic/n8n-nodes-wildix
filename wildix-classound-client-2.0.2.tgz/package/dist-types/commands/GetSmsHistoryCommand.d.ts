import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { GetSmsHistoryInput, GetSmsHistoryOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetSmsHistoryCommand}.
 */
export interface GetSmsHistoryCommandInput extends GetSmsHistoryInput {
}
/**
 * @public
 *
 * The output of {@link GetSmsHistoryCommand}.
 */
export interface GetSmsHistoryCommandOutput extends GetSmsHistoryOutput, __MetadataBearer {
}
declare const GetSmsHistoryCommand_base: {
    new (input: GetSmsHistoryCommandInput): import("@smithy/smithy-client").CommandImpl<GetSmsHistoryCommandInput, GetSmsHistoryCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [GetSmsHistoryCommandInput]): import("@smithy/smithy-client").CommandImpl<GetSmsHistoryCommandInput, GetSmsHistoryCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, GetSmsHistoryCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, GetSmsHistoryCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // GetSmsHistoryInput
 *   from: "STRING_VALUE",
 *   to: "STRING_VALUE",
 *   companyId: "STRING_VALUE",
 * };
 * const command = new GetSmsHistoryCommand(input);
 * const response = await client.send(command);
 * // { // GetSmsHistoryOutput
 * //   type: "STRING_VALUE",
 * //   result: [ // GetSmsHistoryList
 * //     { // GetSmsHistoryRecord
 * //       from: "STRING_VALUE",
 * //       to: "STRING_VALUE",
 * //       messageId: "STRING_VALUE",
 * //       messageText: "STRING_VALUE",
 * //       time: Number("int"),
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param GetSmsHistoryCommandInput - {@link GetSmsHistoryCommandInput}
 * @returns {@link GetSmsHistoryCommandOutput}
 * @see {@link GetSmsHistoryCommandInput} for command's `input` shape.
 * @see {@link GetSmsHistoryCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class GetSmsHistoryCommand extends GetSmsHistoryCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: GetSmsHistoryInput;
            output: GetSmsHistoryOutput;
        };
        sdk: {
            input: GetSmsHistoryCommandInput;
            output: GetSmsHistoryCommandOutput;
        };
    };
}
