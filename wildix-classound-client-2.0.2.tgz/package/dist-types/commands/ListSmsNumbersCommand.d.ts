import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { ListSmsNumbersInput, ListSmsNumbersOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ListSmsNumbersCommand}.
 */
export interface ListSmsNumbersCommandInput extends ListSmsNumbersInput {
}
/**
 * @public
 *
 * The output of {@link ListSmsNumbersCommand}.
 */
export interface ListSmsNumbersCommandOutput extends ListSmsNumbersOutput, __MetadataBearer {
}
declare const ListSmsNumbersCommand_base: {
    new (input: ListSmsNumbersCommandInput): import("@smithy/smithy-client").CommandImpl<ListSmsNumbersCommandInput, ListSmsNumbersCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: ListSmsNumbersCommandInput): import("@smithy/smithy-client").CommandImpl<ListSmsNumbersCommandInput, ListSmsNumbersCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, ListSmsNumbersCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, ListSmsNumbersCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // ListSmsNumbersInput
 *   companyId: "STRING_VALUE", // required
 * };
 * const command = new ListSmsNumbersCommand(input);
 * const response = await client.send(command);
 * // { // ListSmsNumbersOutput
 * //   type: "STRING_VALUE", // required
 * //   success: true || false, // required
 * //   timestamp: Number("long"), // required
 * //   result: { // SmsNumbersResult
 * //     companyId: "STRING_VALUE", // required
 * //     numbers: [ // PhoneNumberList
 * //       "STRING_VALUE",
 * //     ],
 * //   },
 * // };
 *
 * ```
 *
 * @param ListSmsNumbersCommandInput - {@link ListSmsNumbersCommandInput}
 * @returns {@link ListSmsNumbersCommandOutput}
 * @see {@link ListSmsNumbersCommandInput} for command's `input` shape.
 * @see {@link ListSmsNumbersCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class ListSmsNumbersCommand extends ListSmsNumbersCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: ListSmsNumbersInput;
            output: ListSmsNumbersOutput;
        };
        sdk: {
            input: ListSmsNumbersCommandInput;
            output: ListSmsNumbersCommandOutput;
        };
    };
}
