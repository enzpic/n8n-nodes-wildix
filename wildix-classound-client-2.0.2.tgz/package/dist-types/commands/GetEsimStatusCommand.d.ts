import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { GetEsimStatusInput, GetEsimStatusOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetEsimStatusCommand}.
 */
export interface GetEsimStatusCommandInput extends GetEsimStatusInput {
}
/**
 * @public
 *
 * The output of {@link GetEsimStatusCommand}.
 */
export interface GetEsimStatusCommandOutput extends GetEsimStatusOutput, __MetadataBearer {
}
declare const GetEsimStatusCommand_base: {
    new (input: GetEsimStatusCommandInput): import("@smithy/smithy-client").CommandImpl<GetEsimStatusCommandInput, GetEsimStatusCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: GetEsimStatusCommandInput): import("@smithy/smithy-client").CommandImpl<GetEsimStatusCommandInput, GetEsimStatusCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, GetEsimStatusCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, GetEsimStatusCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // GetEsimStatusInput
 *   companyId: "STRING_VALUE",
 *   uid: "STRING_VALUE", // required
 * };
 * const command = new GetEsimStatusCommand(input);
 * const response = await client.send(command);
 * // { // GetEsimStatusOutput
 * //   companyId: "STRING_VALUE", // required
 * //   uid: "STRING_VALUE", // required
 * //   extension: "STRING_VALUE",
 * //   phone: "STRING_VALUE",
 * //   iccid: "STRING_VALUE",
 * //   esimStatus: "STRING_VALUE", // required
 * //   subUID: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param GetEsimStatusCommandInput - {@link GetEsimStatusCommandInput}
 * @returns {@link GetEsimStatusCommandOutput}
 * @see {@link GetEsimStatusCommandInput} for command's `input` shape.
 * @see {@link GetEsimStatusCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class GetEsimStatusCommand extends GetEsimStatusCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: GetEsimStatusInput;
            output: GetEsimStatusOutput;
        };
        sdk: {
            input: GetEsimStatusCommandInput;
            output: GetEsimStatusCommandOutput;
        };
    };
}
