import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { DeleteEsimEndpointInput, DeleteEsimEndpointOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link DeleteEsimEndpointCommand}.
 */
export interface DeleteEsimEndpointCommandInput extends DeleteEsimEndpointInput {
}
/**
 * @public
 *
 * The output of {@link DeleteEsimEndpointCommand}.
 */
export interface DeleteEsimEndpointCommandOutput extends DeleteEsimEndpointOutput, __MetadataBearer {
}
declare const DeleteEsimEndpointCommand_base: {
    new (input: DeleteEsimEndpointCommandInput): import("@smithy/smithy-client").CommandImpl<DeleteEsimEndpointCommandInput, DeleteEsimEndpointCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: DeleteEsimEndpointCommandInput): import("@smithy/smithy-client").CommandImpl<DeleteEsimEndpointCommandInput, DeleteEsimEndpointCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, DeleteEsimEndpointCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, DeleteEsimEndpointCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // DeleteEsimEndpointInput
 *   companyId: "STRING_VALUE",
 *   serial: "STRING_VALUE", // required
 * };
 * const command = new DeleteEsimEndpointCommand(input);
 * const response = await client.send(command);
 * // { // DeleteEsimEndpointOutput
 * //   status: "STRING_VALUE", // required
 * //   companyId: "STRING_VALUE", // required
 * //   serial: "STRING_VALUE", // required
 * // };
 *
 * ```
 *
 * @param DeleteEsimEndpointCommandInput - {@link DeleteEsimEndpointCommandInput}
 * @returns {@link DeleteEsimEndpointCommandOutput}
 * @see {@link DeleteEsimEndpointCommandInput} for command's `input` shape.
 * @see {@link DeleteEsimEndpointCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class DeleteEsimEndpointCommand extends DeleteEsimEndpointCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: DeleteEsimEndpointInput;
            output: DeleteEsimEndpointOutput;
        };
        sdk: {
            input: DeleteEsimEndpointCommandInput;
            output: DeleteEsimEndpointCommandOutput;
        };
    };
}
