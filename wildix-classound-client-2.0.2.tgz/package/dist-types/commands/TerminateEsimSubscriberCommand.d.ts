import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { TerminateEsimSubscriberInput, TerminateEsimSubscriberOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link TerminateEsimSubscriberCommand}.
 */
export interface TerminateEsimSubscriberCommandInput extends TerminateEsimSubscriberInput {
}
/**
 * @public
 *
 * The output of {@link TerminateEsimSubscriberCommand}.
 */
export interface TerminateEsimSubscriberCommandOutput extends TerminateEsimSubscriberOutput, __MetadataBearer {
}
declare const TerminateEsimSubscriberCommand_base: {
    new (input: TerminateEsimSubscriberCommandInput): import("@smithy/smithy-client").CommandImpl<TerminateEsimSubscriberCommandInput, TerminateEsimSubscriberCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: TerminateEsimSubscriberCommandInput): import("@smithy/smithy-client").CommandImpl<TerminateEsimSubscriberCommandInput, TerminateEsimSubscriberCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, TerminateEsimSubscriberCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, TerminateEsimSubscriberCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // TerminateEsimSubscriberInput
 *   companyId: "STRING_VALUE",
 *   uid: "STRING_VALUE", // required
 * };
 * const command = new TerminateEsimSubscriberCommand(input);
 * const response = await client.send(command);
 * // { // TerminateEsimSubscriberOutput
 * //   status: "TERMINATED", // required
 * //   companyId: "STRING_VALUE", // required
 * //   uid: "STRING_VALUE", // required
 * //   extension: "STRING_VALUE",
 * //   subUID: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param TerminateEsimSubscriberCommandInput - {@link TerminateEsimSubscriberCommandInput}
 * @returns {@link TerminateEsimSubscriberCommandOutput}
 * @see {@link TerminateEsimSubscriberCommandInput} for command's `input` shape.
 * @see {@link TerminateEsimSubscriberCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class TerminateEsimSubscriberCommand extends TerminateEsimSubscriberCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: TerminateEsimSubscriberInput;
            output: TerminateEsimSubscriberOutput;
        };
        sdk: {
            input: TerminateEsimSubscriberCommandInput;
            output: TerminateEsimSubscriberCommandOutput;
        };
    };
}
