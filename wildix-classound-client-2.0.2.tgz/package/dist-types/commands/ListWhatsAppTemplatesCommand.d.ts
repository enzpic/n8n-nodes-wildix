import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { ListWhatsAppTemplatesInput, ListWhatsAppTemplatesOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ListWhatsAppTemplatesCommand}.
 */
export interface ListWhatsAppTemplatesCommandInput extends ListWhatsAppTemplatesInput {
}
/**
 * @public
 *
 * The output of {@link ListWhatsAppTemplatesCommand}.
 */
export interface ListWhatsAppTemplatesCommandOutput extends ListWhatsAppTemplatesOutput, __MetadataBearer {
}
declare const ListWhatsAppTemplatesCommand_base: {
    new (input: ListWhatsAppTemplatesCommandInput): import("@smithy/smithy-client").CommandImpl<ListWhatsAppTemplatesCommandInput, ListWhatsAppTemplatesCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: ListWhatsAppTemplatesCommandInput): import("@smithy/smithy-client").CommandImpl<ListWhatsAppTemplatesCommandInput, ListWhatsAppTemplatesCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, ListWhatsAppTemplatesCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, ListWhatsAppTemplatesCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // ListWhatsAppTemplatesInput
 *   did: "STRING_VALUE", // required
 * };
 * const command = new ListWhatsAppTemplatesCommand(input);
 * const response = await client.send(command);
 * // { // ListWhatsAppTemplatesOutput
 * //   type: "STRING_VALUE", // required
 * //   success: true || false, // required
 * //   did: "STRING_VALUE", // required
 * //   data: [ // TemplateList // required
 * //     { // Template
 * //       name: "STRING_VALUE", // required
 * //       parameterFormat: "NAMED", // required
 * //       components: [ // ComponentList // required
 * //         { // Component
 * //           type: "HEADER" || "BODY" || "FOOTER" || "BUTTONS", // required
 * //           format: "TEXT" || "IMAGE", // required
 * //           text: "STRING_VALUE",
 * //           example: { // ComponentExample
 * //             headerHandle: [ // StringList
 * //               "STRING_VALUE",
 * //             ],
 * //             bodyTextNamedParams: [ // BodyTextNamedParamList
 * //               { // BodyTextNamedParam
 * //                 paramName: "STRING_VALUE", // required
 * //                 example: "STRING_VALUE", // required
 * //               },
 * //             ],
 * //           },
 * //           buttons: [ // ButtonList
 * //             { // Button
 * //               type: "QUICK_REPLY" || "URL" || "PHONE_NUMBER" || "OTP" || "MPM" || "CATALOG" || "FLOW" || "VOICE_CALL" || "APP", // required
 * //               text: "STRING_VALUE", // required
 * //               flowId: Number("long"),
 * //               flowAction: "STRING_VALUE",
 * //               navigateScreen: "STRING_VALUE",
 * //             },
 * //           ],
 * //         },
 * //       ],
 * //       language: "STRING_VALUE", // required
 * //       status: "APPROVED" || "PAUSED" || "REJECTED", // required
 * //       category: "MARKETING" || "UTILITY" || "AUTHENTICATION", // required
 * //       subCategory: "STRING_VALUE",
 * //       id: "STRING_VALUE", // required
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param ListWhatsAppTemplatesCommandInput - {@link ListWhatsAppTemplatesCommandInput}
 * @returns {@link ListWhatsAppTemplatesCommandOutput}
 * @see {@link ListWhatsAppTemplatesCommandInput} for command's `input` shape.
 * @see {@link ListWhatsAppTemplatesCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class ListWhatsAppTemplatesCommand extends ListWhatsAppTemplatesCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: ListWhatsAppTemplatesInput;
            output: ListWhatsAppTemplatesOutput;
        };
        sdk: {
            input: ListWhatsAppTemplatesCommandInput;
            output: ListWhatsAppTemplatesCommandOutput;
        };
    };
}
