import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { ListEsimSubscribersInput, ListEsimSubscribersOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ListEsimSubscribersCommand}.
 */
export interface ListEsimSubscribersCommandInput extends ListEsimSubscribersInput {
}
/**
 * @public
 *
 * The output of {@link ListEsimSubscribersCommand}.
 */
export interface ListEsimSubscribersCommandOutput extends ListEsimSubscribersOutput, __MetadataBearer {
}
declare const ListEsimSubscribersCommand_base: {
    new (input: ListEsimSubscribersCommandInput): import("@smithy/smithy-client").CommandImpl<ListEsimSubscribersCommandInput, ListEsimSubscribersCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [ListEsimSubscribersCommandInput]): import("@smithy/smithy-client").CommandImpl<ListEsimSubscribersCommandInput, ListEsimSubscribersCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, ListEsimSubscribersCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, ListEsimSubscribersCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // ListEsimSubscribersInput
 *   companyId: "STRING_VALUE",
 *   limit: Number("int"),
 *   offset: Number("int"),
 * };
 * const command = new ListEsimSubscribersCommand(input);
 * const response = await client.send(command);
 * // { // ListEsimSubscribersOutput
 * //   companyId: "STRING_VALUE", // required
 * //   subscribers: [ // SubscriberItemList // required
 * //     { // SubscriberItem
 * //       uid: "STRING_VALUE", // required
 * //       extension: "STRING_VALUE",
 * //       phone: "STRING_VALUE",
 * //       email: "STRING_VALUE",
 * //       iccid: "STRING_VALUE",
 * //       subUID: "STRING_VALUE",
 * //       serial: "STRING_VALUE",
 * //       bundle: "STRING_VALUE",
 * //       firstName: "STRING_VALUE",
 * //       lastName: "STRING_VALUE",
 * //       status: "STRING_VALUE",
 * //     },
 * //   ],
 * //   total: Number("int"), // required
 * //   limit: Number("int"), // required
 * //   offset: Number("int"), // required
 * // };
 *
 * ```
 *
 * @param ListEsimSubscribersCommandInput - {@link ListEsimSubscribersCommandInput}
 * @returns {@link ListEsimSubscribersCommandOutput}
 * @see {@link ListEsimSubscribersCommandInput} for command's `input` shape.
 * @see {@link ListEsimSubscribersCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class ListEsimSubscribersCommand extends ListEsimSubscribersCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: ListEsimSubscribersInput;
            output: ListEsimSubscribersOutput;
        };
        sdk: {
            input: ListEsimSubscribersCommandInput;
            output: ListEsimSubscribersCommandOutput;
        };
    };
}
