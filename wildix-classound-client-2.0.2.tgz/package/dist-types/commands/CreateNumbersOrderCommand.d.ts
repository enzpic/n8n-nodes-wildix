import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { CreateNumbersOrderInput, CreateNumbersOrderOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CreateNumbersOrderCommand}.
 */
export interface CreateNumbersOrderCommandInput extends CreateNumbersOrderInput {
}
/**
 * @public
 *
 * The output of {@link CreateNumbersOrderCommand}.
 */
export interface CreateNumbersOrderCommandOutput extends CreateNumbersOrderOutput, __MetadataBearer {
}
declare const CreateNumbersOrderCommand_base: {
    new (input: CreateNumbersOrderCommandInput): import("@smithy/smithy-client").CommandImpl<CreateNumbersOrderCommandInput, CreateNumbersOrderCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CreateNumbersOrderCommandInput): import("@smithy/smithy-client").CommandImpl<CreateNumbersOrderCommandInput, CreateNumbersOrderCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, CreateNumbersOrderCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, CreateNumbersOrderCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // CreateNumbersOrderInput
 *   companyId: "STRING_VALUE", // required
 *   requestId: "STRING_VALUE", // required
 *   customerOrderId: "STRING_VALUE", // required
 *   webhookUrl: "STRING_VALUE", // required
 *   webhookToken: "STRING_VALUE", // required
 *   data: { // OrderSearchCriteria
 *     country: "STRING_VALUE", // required
 *     state: "STRING_VALUE",
 *     quantity: Number("int"), // required
 *     city: "STRING_VALUE",
 *     zip: "STRING_VALUE",
 *   },
 * };
 * const command = new CreateNumbersOrderCommand(input);
 * const response = await client.send(command);
 * // { // CreateNumbersOrderOutput
 * //   status: "STRING_VALUE", // required
 * //   supplierOrderId: "STRING_VALUE",
 * //   requestId: "STRING_VALUE",
 * //   customerOrderId: "STRING_VALUE",
 * //   orderStatus: "STRING_VALUE",
 * //   message: "STRING_VALUE",
 * //   testMode: true || false,
 * // };
 *
 * ```
 *
 * @param CreateNumbersOrderCommandInput - {@link CreateNumbersOrderCommandInput}
 * @returns {@link CreateNumbersOrderCommandOutput}
 * @see {@link CreateNumbersOrderCommandInput} for command's `input` shape.
 * @see {@link CreateNumbersOrderCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class CreateNumbersOrderCommand extends CreateNumbersOrderCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CreateNumbersOrderInput;
            output: CreateNumbersOrderOutput;
        };
        sdk: {
            input: CreateNumbersOrderCommandInput;
            output: CreateNumbersOrderCommandOutput;
        };
    };
}
