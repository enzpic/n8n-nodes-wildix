import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { SendSmsInput, SendSmsOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link SendSmsCommand}.
 */
export interface SendSmsCommandInput extends SendSmsInput {
}
/**
 * @public
 *
 * The output of {@link SendSmsCommand}.
 */
export interface SendSmsCommandOutput extends SendSmsOutput, __MetadataBearer {
}
declare const SendSmsCommand_base: {
    new (input: SendSmsCommandInput): import("@smithy/smithy-client").CommandImpl<SendSmsCommandInput, SendSmsCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: SendSmsCommandInput): import("@smithy/smithy-client").CommandImpl<SendSmsCommandInput, SendSmsCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, SendSmsCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, SendSmsCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // SendSmsInput
 *   from: "STRING_VALUE", // required
 *   to: "STRING_VALUE", // required
 *   pbx: "STRING_VALUE", // required
 *   company: "STRING_VALUE", // required
 *   message: "STRING_VALUE", // required
 *   extension: "STRING_VALUE", // required
 *   media: [ // StringList
 *     "STRING_VALUE",
 *   ],
 *   userId: "STRING_VALUE",
 *   channelId: "STRING_VALUE",
 *   messageId: "STRING_VALUE",
 * };
 * const command = new SendSmsCommand(input);
 * const response = await client.send(command);
 * // { // SendSmsOutput
 * //   type: "STRING_VALUE",
 * //   success: true || false,
 * //   status: "STRING_VALUE",
 * //   id: [ // StringList
 * //     "STRING_VALUE",
 * //   ],
 * //   company: "STRING_VALUE",
 * //   data: { // SendSmsOutputData
 * //     from: "STRING_VALUE",
 * //     to: "STRING_VALUE",
 * //     message: "STRING_VALUE",
 * //     pbx: "STRING_VALUE",
 * //     extension: "STRING_VALUE",
 * //   },
 * // };
 *
 * ```
 *
 * @param SendSmsCommandInput - {@link SendSmsCommandInput}
 * @returns {@link SendSmsCommandOutput}
 * @see {@link SendSmsCommandInput} for command's `input` shape.
 * @see {@link SendSmsCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class SendSmsCommand extends SendSmsCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: SendSmsInput;
            output: SendSmsOutput;
        };
        sdk: {
            input: SendSmsCommandInput;
            output: SendSmsCommandOutput;
        };
    };
}
