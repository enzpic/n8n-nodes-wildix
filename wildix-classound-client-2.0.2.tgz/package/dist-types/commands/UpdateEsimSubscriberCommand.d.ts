import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { UpdateEsimSubscriberInput, UpdateEsimSubscriberOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link UpdateEsimSubscriberCommand}.
 */
export interface UpdateEsimSubscriberCommandInput extends UpdateEsimSubscriberInput {
}
/**
 * @public
 *
 * The output of {@link UpdateEsimSubscriberCommand}.
 */
export interface UpdateEsimSubscriberCommandOutput extends UpdateEsimSubscriberOutput, __MetadataBearer {
}
declare const UpdateEsimSubscriberCommand_base: {
    new (input: UpdateEsimSubscriberCommandInput): import("@smithy/smithy-client").CommandImpl<UpdateEsimSubscriberCommandInput, UpdateEsimSubscriberCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: UpdateEsimSubscriberCommandInput): import("@smithy/smithy-client").CommandImpl<UpdateEsimSubscriberCommandInput, UpdateEsimSubscriberCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, UpdateEsimSubscriberCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, UpdateEsimSubscriberCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // UpdateEsimSubscriberInput
 *   companyId: "STRING_VALUE",
 *   uid: "STRING_VALUE", // required
 *   extension: "STRING_VALUE",
 *   email: "STRING_VALUE",
 *   firstName: "STRING_VALUE",
 *   lastName: "STRING_VALUE",
 *   phone: "STRING_VALUE",
 *   userPassword: "STRING_VALUE",
 *   bundle: "PLAN-VC-MSG-2G" || "PLAN-VC-MSG-4G" || "PLAN-VC-MSG-10G" || "PLAN-VC-MSG-20G" || "PLAN-VC-MSG-UNLTD" || "PLAN-VC-MSG-BKGND",
 * };
 * const command = new UpdateEsimSubscriberCommand(input);
 * const response = await client.send(command);
 * // { // UpdateEsimSubscriberOutput
 * //   status: "UPDATED", // required
 * //   companyId: "STRING_VALUE", // required
 * //   uid: "STRING_VALUE", // required
 * //   updatedFields: [ // StringList // required
 * //     "STRING_VALUE",
 * //   ],
 * // };
 *
 * ```
 *
 * @param UpdateEsimSubscriberCommandInput - {@link UpdateEsimSubscriberCommandInput}
 * @returns {@link UpdateEsimSubscriberCommandOutput}
 * @see {@link UpdateEsimSubscriberCommandInput} for command's `input` shape.
 * @see {@link UpdateEsimSubscriberCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class UpdateEsimSubscriberCommand extends UpdateEsimSubscriberCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: UpdateEsimSubscriberInput;
            output: UpdateEsimSubscriberOutput;
        };
        sdk: {
            input: UpdateEsimSubscriberCommandInput;
            output: UpdateEsimSubscriberCommandOutput;
        };
    };
}
