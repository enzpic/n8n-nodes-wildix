import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { SendWhatsAppMessageInput, SendWhatsAppMessageOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link SendWhatsAppMessageCommand}.
 */
export interface SendWhatsAppMessageCommandInput extends SendWhatsAppMessageInput {
}
/**
 * @public
 *
 * The output of {@link SendWhatsAppMessageCommand}.
 */
export interface SendWhatsAppMessageCommandOutput extends SendWhatsAppMessageOutput, __MetadataBearer {
}
declare const SendWhatsAppMessageCommand_base: {
    new (input: SendWhatsAppMessageCommandInput): import("@smithy/smithy-client").CommandImpl<SendWhatsAppMessageCommandInput, SendWhatsAppMessageCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: SendWhatsAppMessageCommandInput): import("@smithy/smithy-client").CommandImpl<SendWhatsAppMessageCommandInput, SendWhatsAppMessageCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, SendWhatsAppMessageCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, SendWhatsAppMessageCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // SendWhatsAppMessageInput
 *   from: "STRING_VALUE", // required
 *   to: "STRING_VALUE", // required
 *   pbx: "STRING_VALUE", // required
 *   company: "STRING_VALUE", // required
 *   message: "STRING_VALUE", // required
 *   extension: "STRING_VALUE", // required
 *   media: [ // StringList
 *     "STRING_VALUE",
 *   ],
 *   userId: "STRING_VALUE",
 *   channelId: "STRING_VALUE",
 *   messageId: "STRING_VALUE",
 * };
 * const command = new SendWhatsAppMessageCommand(input);
 * const response = await client.send(command);
 * // { // SendWhatsAppMessageOutput
 * //   type: "STRING_VALUE",
 * //   success: true || false,
 * //   company: "STRING_VALUE",
 * //   status: "STRING_VALUE",
 * //   id: [ // StringList
 * //     "STRING_VALUE",
 * //   ],
 * //   data: { // SendWhatsAppMessageData
 * //     from: "STRING_VALUE",
 * //     to: "STRING_VALUE",
 * //     pbx: "STRING_VALUE",
 * //     company: "STRING_VALUE",
 * //     message: "STRING_VALUE",
 * //     extension: "STRING_VALUE",
 * //     media: [
 * //       "STRING_VALUE",
 * //     ],
 * //     userId: "STRING_VALUE",
 * //     channelId: "STRING_VALUE",
 * //     messageId: "STRING_VALUE",
 * //   },
 * // };
 *
 * ```
 *
 * @param SendWhatsAppMessageCommandInput - {@link SendWhatsAppMessageCommandInput}
 * @returns {@link SendWhatsAppMessageCommandOutput}
 * @see {@link SendWhatsAppMessageCommandInput} for command's `input` shape.
 * @see {@link SendWhatsAppMessageCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class SendWhatsAppMessageCommand extends SendWhatsAppMessageCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: SendWhatsAppMessageInput;
            output: SendWhatsAppMessageOutput;
        };
        sdk: {
            input: SendWhatsAppMessageCommandInput;
            output: SendWhatsAppMessageCommandOutput;
        };
    };
}
