import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { SendWhatsAppInteractiveMessageInput, SendWhatsAppInteractiveMessageOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link SendWhatsAppInteractiveMessageCommand}.
 */
export interface SendWhatsAppInteractiveMessageCommandInput extends SendWhatsAppInteractiveMessageInput {
}
/**
 * @public
 *
 * The output of {@link SendWhatsAppInteractiveMessageCommand}.
 */
export interface SendWhatsAppInteractiveMessageCommandOutput extends SendWhatsAppInteractiveMessageOutput, __MetadataBearer {
}
declare const SendWhatsAppInteractiveMessageCommand_base: {
    new (input: SendWhatsAppInteractiveMessageCommandInput): import("@smithy/smithy-client").CommandImpl<SendWhatsAppInteractiveMessageCommandInput, SendWhatsAppInteractiveMessageCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: SendWhatsAppInteractiveMessageCommandInput): import("@smithy/smithy-client").CommandImpl<SendWhatsAppInteractiveMessageCommandInput, SendWhatsAppInteractiveMessageCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, SendWhatsAppInteractiveMessageCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, SendWhatsAppInteractiveMessageCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // SendWhatsAppInteractiveMessageInput
 *   from: "STRING_VALUE", // required
 *   to: "STRING_VALUE", // required
 *   pbx: "STRING_VALUE", // required
 *   company: "STRING_VALUE", // required
 *   message: { // InteractiveMessage
 *     type: "list" || "button", // required
 *     header: { // InteractiveHeader
 *       type: "text" || "image", // required
 *       text: "STRING_VALUE",
 *       image: { // InteractiveMedia
 *         id: "STRING_VALUE", // required
 *         link: "STRING_VALUE", // required
 *         filename: "STRING_VALUE",
 *       },
 *       video: {
 *         id: "STRING_VALUE", // required
 *         link: "STRING_VALUE", // required
 *         filename: "STRING_VALUE",
 *       },
 *       document: {
 *         id: "STRING_VALUE", // required
 *         link: "STRING_VALUE", // required
 *         filename: "STRING_VALUE",
 *       },
 *     },
 *     body: { // InteractiveBody
 *       text: "STRING_VALUE", // required
 *     },
 *     footer: { // InteractiveFooter
 *       text: "STRING_VALUE", // required
 *     },
 *     action: { // InteractiveAction
 *       buttons: [ // InteractiveButtonList
 *         { // InteractiveButton
 *           type: "reply", // required
 *           reply: { // InteractiveButtonReply
 *             id: "STRING_VALUE", // required
 *             title: "STRING_VALUE", // required
 *           },
 *         },
 *       ],
 *       sections: [ // InteractiveSectionList
 *         { // InteractiveSection
 *           title: "STRING_VALUE", // required
 *           rows: [ // InteractiveRowList // required
 *             { // InteractiveRow
 *               id: "STRING_VALUE", // required
 *               title: "STRING_VALUE", // required
 *               description: "STRING_VALUE",
 *             },
 *           ],
 *         },
 *       ],
 *     },
 *   },
 *   extension: "STRING_VALUE", // required
 *   userId: "STRING_VALUE",
 *   channelId: "STRING_VALUE",
 *   messageId: "STRING_VALUE",
 * };
 * const command = new SendWhatsAppInteractiveMessageCommand(input);
 * const response = await client.send(command);
 * // { // SendWhatsAppInteractiveMessageOutput
 * //   type: "STRING_VALUE",
 * //   success: true || false,
 * //   company: "STRING_VALUE",
 * //   status: "STRING_VALUE",
 * //   id: [ // StringList
 * //     "STRING_VALUE",
 * //   ],
 * //   data: { // SendWhatsAppInteractiveMessageData
 * //     from: "STRING_VALUE",
 * //     to: "STRING_VALUE",
 * //     pbx: "STRING_VALUE",
 * //     company: "STRING_VALUE",
 * //     message: { // InteractiveMessage
 * //       type: "list" || "button", // required
 * //       header: { // InteractiveHeader
 * //         type: "text" || "image", // required
 * //         text: "STRING_VALUE",
 * //         image: { // InteractiveMedia
 * //           id: "STRING_VALUE", // required
 * //           link: "STRING_VALUE", // required
 * //           filename: "STRING_VALUE",
 * //         },
 * //         video: {
 * //           id: "STRING_VALUE", // required
 * //           link: "STRING_VALUE", // required
 * //           filename: "STRING_VALUE",
 * //         },
 * //         document: {
 * //           id: "STRING_VALUE", // required
 * //           link: "STRING_VALUE", // required
 * //           filename: "STRING_VALUE",
 * //         },
 * //       },
 * //       body: { // InteractiveBody
 * //         text: "STRING_VALUE", // required
 * //       },
 * //       footer: { // InteractiveFooter
 * //         text: "STRING_VALUE", // required
 * //       },
 * //       action: { // InteractiveAction
 * //         buttons: [ // InteractiveButtonList
 * //           { // InteractiveButton
 * //             type: "reply", // required
 * //             reply: { // InteractiveButtonReply
 * //               id: "STRING_VALUE", // required
 * //               title: "STRING_VALUE", // required
 * //             },
 * //           },
 * //         ],
 * //         sections: [ // InteractiveSectionList
 * //           { // InteractiveSection
 * //             title: "STRING_VALUE", // required
 * //             rows: [ // InteractiveRowList // required
 * //               { // InteractiveRow
 * //                 id: "STRING_VALUE", // required
 * //                 title: "STRING_VALUE", // required
 * //                 description: "STRING_VALUE",
 * //               },
 * //             ],
 * //           },
 * //         ],
 * //       },
 * //     },
 * //     extension: "STRING_VALUE",
 * //   },
 * // };
 *
 * ```
 *
 * @param SendWhatsAppInteractiveMessageCommandInput - {@link SendWhatsAppInteractiveMessageCommandInput}
 * @returns {@link SendWhatsAppInteractiveMessageCommandOutput}
 * @see {@link SendWhatsAppInteractiveMessageCommandInput} for command's `input` shape.
 * @see {@link SendWhatsAppInteractiveMessageCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class SendWhatsAppInteractiveMessageCommand extends SendWhatsAppInteractiveMessageCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: SendWhatsAppInteractiveMessageInput;
            output: SendWhatsAppInteractiveMessageOutput;
        };
        sdk: {
            input: SendWhatsAppInteractiveMessageCommandInput;
            output: SendWhatsAppInteractiveMessageCommandOutput;
        };
    };
}
