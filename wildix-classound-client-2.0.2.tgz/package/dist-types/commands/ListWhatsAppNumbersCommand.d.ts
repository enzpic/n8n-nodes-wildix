import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { ListWhatsAppNumbersInput, ListWhatsAppNumbersOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ListWhatsAppNumbersCommand}.
 */
export interface ListWhatsAppNumbersCommandInput extends ListWhatsAppNumbersInput {
}
/**
 * @public
 *
 * The output of {@link ListWhatsAppNumbersCommand}.
 */
export interface ListWhatsAppNumbersCommandOutput extends ListWhatsAppNumbersOutput, __MetadataBearer {
}
declare const ListWhatsAppNumbersCommand_base: {
    new (input: ListWhatsAppNumbersCommandInput): import("@smithy/smithy-client").CommandImpl<ListWhatsAppNumbersCommandInput, ListWhatsAppNumbersCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: ListWhatsAppNumbersCommandInput): import("@smithy/smithy-client").CommandImpl<ListWhatsAppNumbersCommandInput, ListWhatsAppNumbersCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, ListWhatsAppNumbersCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, ListWhatsAppNumbersCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // ListWhatsAppNumbersInput
 *   companyId: "STRING_VALUE", // required
 * };
 * const command = new ListWhatsAppNumbersCommand(input);
 * const response = await client.send(command);
 * // { // ListWhatsAppNumbersOutput
 * //   type: "STRING_VALUE", // required
 * //   success: true || false, // required
 * //   timestamp: Number("long"), // required
 * //   result: { // WhatsAppNumbersResult
 * //     companyId: "STRING_VALUE", // required
 * //     numbers: [ // PhoneNumberList
 * //       "STRING_VALUE",
 * //     ],
 * //   },
 * // };
 *
 * ```
 *
 * @param ListWhatsAppNumbersCommandInput - {@link ListWhatsAppNumbersCommandInput}
 * @returns {@link ListWhatsAppNumbersCommandOutput}
 * @see {@link ListWhatsAppNumbersCommandInput} for command's `input` shape.
 * @see {@link ListWhatsAppNumbersCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class ListWhatsAppNumbersCommand extends ListWhatsAppNumbersCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: ListWhatsAppNumbersInput;
            output: ListWhatsAppNumbersOutput;
        };
        sdk: {
            input: ListWhatsAppNumbersCommandInput;
            output: ListWhatsAppNumbersCommandOutput;
        };
    };
}
