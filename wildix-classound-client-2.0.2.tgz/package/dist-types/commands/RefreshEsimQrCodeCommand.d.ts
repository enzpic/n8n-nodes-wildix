import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { RefreshEsimQrCodeInput, RefreshEsimQrCodeOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link RefreshEsimQrCodeCommand}.
 */
export interface RefreshEsimQrCodeCommandInput extends RefreshEsimQrCodeInput {
}
/**
 * @public
 *
 * The output of {@link RefreshEsimQrCodeCommand}.
 */
export interface RefreshEsimQrCodeCommandOutput extends RefreshEsimQrCodeOutput, __MetadataBearer {
}
declare const RefreshEsimQrCodeCommand_base: {
    new (input: RefreshEsimQrCodeCommandInput): import("@smithy/smithy-client").CommandImpl<RefreshEsimQrCodeCommandInput, RefreshEsimQrCodeCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: RefreshEsimQrCodeCommandInput): import("@smithy/smithy-client").CommandImpl<RefreshEsimQrCodeCommandInput, RefreshEsimQrCodeCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, RefreshEsimQrCodeCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, RefreshEsimQrCodeCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // RefreshEsimQrCodeInput
 *   companyId: "STRING_VALUE",
 *   uid: "STRING_VALUE", // required
 * };
 * const command = new RefreshEsimQrCodeCommand(input);
 * const response = await client.send(command);
 * // { // RefreshEsimQrCodeOutput
 * //   companyId: "STRING_VALUE", // required
 * //   uid: "STRING_VALUE", // required
 * //   extension: "STRING_VALUE",
 * //   iccid: "STRING_VALUE", // required
 * //   activationCode: "STRING_VALUE", // required
 * //   phone: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param RefreshEsimQrCodeCommandInput - {@link RefreshEsimQrCodeCommandInput}
 * @returns {@link RefreshEsimQrCodeCommandOutput}
 * @see {@link RefreshEsimQrCodeCommandInput} for command's `input` shape.
 * @see {@link RefreshEsimQrCodeCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class RefreshEsimQrCodeCommand extends RefreshEsimQrCodeCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: RefreshEsimQrCodeInput;
            output: RefreshEsimQrCodeOutput;
        };
        sdk: {
            input: RefreshEsimQrCodeCommandInput;
            output: RefreshEsimQrCodeCommandOutput;
        };
    };
}
