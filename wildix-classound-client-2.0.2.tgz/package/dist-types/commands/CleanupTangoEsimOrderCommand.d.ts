import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { CleanupTangoEsimOrderInput, CleanupTangoEsimOrderOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CleanupTangoEsimOrderCommand}.
 */
export interface CleanupTangoEsimOrderCommandInput extends CleanupTangoEsimOrderInput {
}
/**
 * @public
 *
 * The output of {@link CleanupTangoEsimOrderCommand}.
 */
export interface CleanupTangoEsimOrderCommandOutput extends CleanupTangoEsimOrderOutput, __MetadataBearer {
}
declare const CleanupTangoEsimOrderCommand_base: {
    new (input: CleanupTangoEsimOrderCommandInput): import("@smithy/smithy-client").CommandImpl<CleanupTangoEsimOrderCommandInput, CleanupTangoEsimOrderCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CleanupTangoEsimOrderCommandInput): import("@smithy/smithy-client").CommandImpl<CleanupTangoEsimOrderCommandInput, CleanupTangoEsimOrderCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, CleanupTangoEsimOrderCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, CleanupTangoEsimOrderCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // CleanupTangoEsimOrderInput
 *   orderId: "STRING_VALUE", // required
 * };
 * const command = new CleanupTangoEsimOrderCommand(input);
 * const response = await client.send(command);
 * // { // CleanupTangoEsimOrderOutput
 * //   status: "CLEANED", // required
 * //   orderId: "STRING_VALUE", // required
 * //   simsReleased: Number("int"), // required
 * //   steps: { // CleanupStepsMap // required
 * //     "<keys>": "STRING_VALUE",
 * //   },
 * // };
 *
 * ```
 *
 * @param CleanupTangoEsimOrderCommandInput - {@link CleanupTangoEsimOrderCommandInput}
 * @returns {@link CleanupTangoEsimOrderCommandOutput}
 * @see {@link CleanupTangoEsimOrderCommandInput} for command's `input` shape.
 * @see {@link CleanupTangoEsimOrderCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class CleanupTangoEsimOrderCommand extends CleanupTangoEsimOrderCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CleanupTangoEsimOrderInput;
            output: CleanupTangoEsimOrderOutput;
        };
        sdk: {
            input: CleanupTangoEsimOrderCommandInput;
            output: CleanupTangoEsimOrderCommandOutput;
        };
    };
}
