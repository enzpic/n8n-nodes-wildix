import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { CreateTangoEsimOrderInput, CreateTangoEsimOrderOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link CreateTangoEsimOrderCommand}.
 */
export interface CreateTangoEsimOrderCommandInput extends CreateTangoEsimOrderInput {
}
/**
 * @public
 *
 * The output of {@link CreateTangoEsimOrderCommand}.
 */
export interface CreateTangoEsimOrderCommandOutput extends CreateTangoEsimOrderOutput, __MetadataBearer {
}
declare const CreateTangoEsimOrderCommand_base: {
    new (input: CreateTangoEsimOrderCommandInput): import("@smithy/smithy-client").CommandImpl<CreateTangoEsimOrderCommandInput, CreateTangoEsimOrderCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: CreateTangoEsimOrderCommandInput): import("@smithy/smithy-client").CommandImpl<CreateTangoEsimOrderCommandInput, CreateTangoEsimOrderCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, CreateTangoEsimOrderCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, CreateTangoEsimOrderCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // CreateTangoEsimOrderInput
 *   partnerId: "STRING_VALUE", // required
 *   partnerName: "STRING_VALUE", // required
 *   companyId: "STRING_VALUE", // required
 *   companyName: "STRING_VALUE", // required
 *   countryCode: "STRING_VALUE", // required
 *   quantity: Number("int"), // required
 *   requestId: "STRING_VALUE", // required
 *   partnerEmail: "STRING_VALUE",
 *   bundle: "PLAN-VC-MSG-2G" || "PLAN-VC-MSG-4G" || "PLAN-VC-MSG-10G" || "PLAN-VC-MSG-20G" || "PLAN-VC-MSG-UNLTD" || "PLAN-VC-MSG-BKGND", // required
 *   homeLocations: [ // StringList // required
 *     "STRING_VALUE",
 *   ],
 *   partnerAddress: "STRING_VALUE", // required
 *   partnerPostCode: "STRING_VALUE", // required
 *   partnerContactNumber: "STRING_VALUE", // required
 *   partnerAddress2: "STRING_VALUE",
 *   partnerTown: "STRING_VALUE",
 *   partnerCounty: "STRING_VALUE",
 *   partnerDescription: "STRING_VALUE",
 * };
 * const command = new CreateTangoEsimOrderCommand(input);
 * const response = await client.send(command);
 * // { // CreateTangoEsimOrderOutput
 * //   status: "SUCCESS", // required
 * //   orderId: "STRING_VALUE", // required
 * //   requestId: "STRING_VALUE", // required
 * //   partnerId: "STRING_VALUE", // required
 * //   companyId: "STRING_VALUE", // required
 * //   countryCode: "STRING_VALUE", // required
 * //   quantity: Number("int"), // required
 * //   totalReserved: Number("int"), // required
 * //   bundle: "PLAN-VC-MSG-2G" || "PLAN-VC-MSG-4G" || "PLAN-VC-MSG-10G" || "PLAN-VC-MSG-20G" || "PLAN-VC-MSG-UNLTD" || "PLAN-VC-MSG-BKGND",
 * // };
 *
 * ```
 *
 * @param CreateTangoEsimOrderCommandInput - {@link CreateTangoEsimOrderCommandInput}
 * @returns {@link CreateTangoEsimOrderCommandOutput}
 * @see {@link CreateTangoEsimOrderCommandInput} for command's `input` shape.
 * @see {@link CreateTangoEsimOrderCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class CreateTangoEsimOrderCommand extends CreateTangoEsimOrderCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: CreateTangoEsimOrderInput;
            output: CreateTangoEsimOrderOutput;
        };
        sdk: {
            input: CreateTangoEsimOrderCommandInput;
            output: CreateTangoEsimOrderCommandOutput;
        };
    };
}
