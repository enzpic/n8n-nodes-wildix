import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { GetEsimQrCodeInput, GetEsimQrCodeOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetEsimQrCodeCommand}.
 */
export interface GetEsimQrCodeCommandInput extends GetEsimQrCodeInput {
}
/**
 * @public
 *
 * The output of {@link GetEsimQrCodeCommand}.
 */
export interface GetEsimQrCodeCommandOutput extends GetEsimQrCodeOutput, __MetadataBearer {
}
declare const GetEsimQrCodeCommand_base: {
    new (input: GetEsimQrCodeCommandInput): import("@smithy/smithy-client").CommandImpl<GetEsimQrCodeCommandInput, GetEsimQrCodeCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: GetEsimQrCodeCommandInput): import("@smithy/smithy-client").CommandImpl<GetEsimQrCodeCommandInput, GetEsimQrCodeCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, GetEsimQrCodeCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, GetEsimQrCodeCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // GetEsimQrCodeInput
 *   companyId: "STRING_VALUE",
 *   uid: "STRING_VALUE", // required
 * };
 * const command = new GetEsimQrCodeCommand(input);
 * const response = await client.send(command);
 * // { // GetEsimQrCodeOutput
 * //   companyId: "STRING_VALUE", // required
 * //   uid: "STRING_VALUE", // required
 * //   extension: "STRING_VALUE",
 * //   iccid: "STRING_VALUE", // required
 * //   activationCode: "STRING_VALUE", // required
 * //   phone: "STRING_VALUE",
 * // };
 *
 * ```
 *
 * @param GetEsimQrCodeCommandInput - {@link GetEsimQrCodeCommandInput}
 * @returns {@link GetEsimQrCodeCommandOutput}
 * @see {@link GetEsimQrCodeCommandInput} for command's `input` shape.
 * @see {@link GetEsimQrCodeCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link NotFoundError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class GetEsimQrCodeCommand extends GetEsimQrCodeCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: GetEsimQrCodeInput;
            output: GetEsimQrCodeOutput;
        };
        sdk: {
            input: GetEsimQrCodeCommandInput;
            output: GetEsimQrCodeCommandOutput;
        };
    };
}
