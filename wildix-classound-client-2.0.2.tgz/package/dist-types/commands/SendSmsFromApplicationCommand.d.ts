import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { SendSmsFromApplicationInput, SendSmsFromApplicationOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link SendSmsFromApplicationCommand}.
 */
export interface SendSmsFromApplicationCommandInput extends SendSmsFromApplicationInput {
}
/**
 * @public
 *
 * The output of {@link SendSmsFromApplicationCommand}.
 */
export interface SendSmsFromApplicationCommandOutput extends SendSmsFromApplicationOutput, __MetadataBearer {
}
declare const SendSmsFromApplicationCommand_base: {
    new (input: SendSmsFromApplicationCommandInput): import("@smithy/smithy-client").CommandImpl<SendSmsFromApplicationCommandInput, SendSmsFromApplicationCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: SendSmsFromApplicationCommandInput): import("@smithy/smithy-client").CommandImpl<SendSmsFromApplicationCommandInput, SendSmsFromApplicationCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, SendSmsFromApplicationCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, SendSmsFromApplicationCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // SendSmsFromApplicationInput
 *   from: "STRING_VALUE", // required
 *   to: "STRING_VALUE", // required
 *   message: "STRING_VALUE", // required
 * };
 * const command = new SendSmsFromApplicationCommand(input);
 * const response = await client.send(command);
 * // { // SendSmsFromApplicationOutput
 * //   type: "STRING_VALUE",
 * //   success: true || false,
 * //   status: "STRING_VALUE",
 * //   id: [ // StringList
 * //     "STRING_VALUE",
 * //   ],
 * //   company: "STRING_VALUE",
 * //   data: { // SendSmsData
 * //     from: "STRING_VALUE",
 * //     to: "STRING_VALUE",
 * //     message: "STRING_VALUE",
 * //     pbx: "STRING_VALUE",
 * //     extension: "STRING_VALUE",
 * //   },
 * // };
 *
 * ```
 *
 * @param SendSmsFromApplicationCommandInput - {@link SendSmsFromApplicationCommandInput}
 * @returns {@link SendSmsFromApplicationCommandOutput}
 * @see {@link SendSmsFromApplicationCommandInput} for command's `input` shape.
 * @see {@link SendSmsFromApplicationCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class SendSmsFromApplicationCommand extends SendSmsFromApplicationCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: SendSmsFromApplicationInput;
            output: SendSmsFromApplicationOutput;
        };
        sdk: {
            input: SendSmsFromApplicationCommandInput;
            output: SendSmsFromApplicationCommandOutput;
        };
    };
}
