import { ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../ClassoundClient";
import { ListEsimBundlesInput, ListEsimBundlesOutput } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link ListEsimBundlesCommand}.
 */
export interface ListEsimBundlesCommandInput extends ListEsimBundlesInput {
}
/**
 * @public
 *
 * The output of {@link ListEsimBundlesCommand}.
 */
export interface ListEsimBundlesCommandOutput extends ListEsimBundlesOutput, __MetadataBearer {
}
declare const ListEsimBundlesCommand_base: {
    new (input: ListEsimBundlesCommandInput): import("@smithy/smithy-client").CommandImpl<ListEsimBundlesCommandInput, ListEsimBundlesCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (...[input]: [] | [ListEsimBundlesCommandInput]): import("@smithy/smithy-client").CommandImpl<ListEsimBundlesCommandInput, ListEsimBundlesCommandOutput, ClassoundClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * @public
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { ClassoundClient, ListEsimBundlesCommand } from "@wildix/classound-client"; // ES Modules import
 * // const { ClassoundClient, ListEsimBundlesCommand } = require("@wildix/classound-client"); // CommonJS import
 * const client = new ClassoundClient(config);
 * const input = { // ListEsimBundlesInput
 *   companyId: "STRING_VALUE",
 * };
 * const command = new ListEsimBundlesCommand(input);
 * const response = await client.send(command);
 * // { // ListEsimBundlesOutput
 * //   bundles: [ // EsimBundleCountList // required
 * //     { // EsimBundleCount
 * //       bundle: "PLAN-VC-MSG-2G" || "PLAN-VC-MSG-4G" || "PLAN-VC-MSG-10G" || "PLAN-VC-MSG-20G" || "PLAN-VC-MSG-UNLTD" || "PLAN-VC-MSG-BKGND", // required
 * //       available: Number("int"), // required
 * //       active: Number("int"), // required
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param ListEsimBundlesCommandInput - {@link ListEsimBundlesCommandInput}
 * @returns {@link ListEsimBundlesCommandOutput}
 * @see {@link ListEsimBundlesCommandInput} for command's `input` shape.
 * @see {@link ListEsimBundlesCommandOutput} for command's `response` shape.
 * @see {@link ClassoundClientResolvedConfig | config} for ClassoundClient's `config` shape.
 *
 * @throws {@link ValidationError} (client fault)
 *
 * @throws {@link InternalError} (server fault)
 *
 * @throws {@link RequestValidationException} (client fault)
 *
 * @throws {@link UserNotFoundException} (client fault)
 *
 * @throws {@link GatewayTimeoutException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link OrderError} (client fault)
 *
 * @throws {@link TangoEsimOrderError} (client fault)
 *
 * @throws {@link ClassoundServiceException}
 * <p>Base exception class for all service exceptions from Classound service.</p>
 *
 *
 */
export declare class ListEsimBundlesCommand extends ListEsimBundlesCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: ListEsimBundlesInput;
            output: ListEsimBundlesOutput;
        };
        sdk: {
            input: ListEsimBundlesCommandInput;
            output: ListEsimBundlesCommandOutput;
        };
    };
}
