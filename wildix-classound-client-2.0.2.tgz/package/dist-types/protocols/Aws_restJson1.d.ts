import { CleanupTangoEsimOrderCommandInput, CleanupTangoEsimOrderCommandOutput } from "../commands/CleanupTangoEsimOrderCommand";
import { CreateNumbersOrderCommandInput, CreateNumbersOrderCommandOutput } from "../commands/CreateNumbersOrderCommand";
import { CreateTangoEsimOrderCommandInput, CreateTangoEsimOrderCommandOutput } from "../commands/CreateTangoEsimOrderCommand";
import { DeleteEsimEndpointCommandInput, DeleteEsimEndpointCommandOutput } from "../commands/DeleteEsimEndpointCommand";
import { GetEsimQrCodeCommandInput, GetEsimQrCodeCommandOutput } from "../commands/GetEsimQrCodeCommand";
import { GetEsimStatusCommandInput, GetEsimStatusCommandOutput } from "../commands/GetEsimStatusCommand";
import { GetSmsHistoryCommandInput, GetSmsHistoryCommandOutput } from "../commands/GetSmsHistoryCommand";
import { ListEsimBundlesCommandInput, ListEsimBundlesCommandOutput } from "../commands/ListEsimBundlesCommand";
import { ListEsimSubscribersCommandInput, ListEsimSubscribersCommandOutput } from "../commands/ListEsimSubscribersCommand";
import { ListSmsNumbersCommandInput, ListSmsNumbersCommandOutput } from "../commands/ListSmsNumbersCommand";
import { ListWhatsAppNumbersCommandInput, ListWhatsAppNumbersCommandOutput } from "../commands/ListWhatsAppNumbersCommand";
import { ListWhatsAppTemplatesCommandInput, ListWhatsAppTemplatesCommandOutput } from "../commands/ListWhatsAppTemplatesCommand";
import { ProvisionEsimSubscriberCommandInput, ProvisionEsimSubscriberCommandOutput } from "../commands/ProvisionEsimSubscriberCommand";
import { RefreshEsimQrCodeCommandInput, RefreshEsimQrCodeCommandOutput } from "../commands/RefreshEsimQrCodeCommand";
import { SendSmsCommandInput, SendSmsCommandOutput } from "../commands/SendSmsCommand";
import { SendSmsFromApplicationCommandInput, SendSmsFromApplicationCommandOutput } from "../commands/SendSmsFromApplicationCommand";
import { SendWhatsAppInteractiveMessageCommandInput, SendWhatsAppInteractiveMessageCommandOutput } from "../commands/SendWhatsAppInteractiveMessageCommand";
import { SendWhatsAppMessageCommandInput, SendWhatsAppMessageCommandOutput } from "../commands/SendWhatsAppMessageCommand";
import { SendWhatsAppTemplateCommandInput, SendWhatsAppTemplateCommandOutput } from "../commands/SendWhatsAppTemplateCommand";
import { SyncEsimTransformsCommandInput, SyncEsimTransformsCommandOutput } from "../commands/SyncEsimTransformsCommand";
import { TerminateEsimSubscriberCommandInput, TerminateEsimSubscriberCommandOutput } from "../commands/TerminateEsimSubscriberCommand";
import { UpdateEsimSubscriberCommandInput, UpdateEsimSubscriberCommandOutput } from "../commands/UpdateEsimSubscriberCommand";
import { HttpRequest as __HttpRequest, HttpResponse as __HttpResponse } from "@smithy/protocol-http";
import { SerdeContext as __SerdeContext } from "@smithy/types";
/**
 * serializeAws_restJson1CleanupTangoEsimOrderCommand
 */
export declare const se_CleanupTangoEsimOrderCommand: (input: CleanupTangoEsimOrderCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CreateNumbersOrderCommand
 */
export declare const se_CreateNumbersOrderCommand: (input: CreateNumbersOrderCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CreateTangoEsimOrderCommand
 */
export declare const se_CreateTangoEsimOrderCommand: (input: CreateTangoEsimOrderCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1DeleteEsimEndpointCommand
 */
export declare const se_DeleteEsimEndpointCommand: (input: DeleteEsimEndpointCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetEsimQrCodeCommand
 */
export declare const se_GetEsimQrCodeCommand: (input: GetEsimQrCodeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetEsimStatusCommand
 */
export declare const se_GetEsimStatusCommand: (input: GetEsimStatusCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetSmsHistoryCommand
 */
export declare const se_GetSmsHistoryCommand: (input: GetSmsHistoryCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListEsimBundlesCommand
 */
export declare const se_ListEsimBundlesCommand: (input: ListEsimBundlesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListEsimSubscribersCommand
 */
export declare const se_ListEsimSubscribersCommand: (input: ListEsimSubscribersCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListSmsNumbersCommand
 */
export declare const se_ListSmsNumbersCommand: (input: ListSmsNumbersCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListWhatsAppNumbersCommand
 */
export declare const se_ListWhatsAppNumbersCommand: (input: ListWhatsAppNumbersCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListWhatsAppTemplatesCommand
 */
export declare const se_ListWhatsAppTemplatesCommand: (input: ListWhatsAppTemplatesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ProvisionEsimSubscriberCommand
 */
export declare const se_ProvisionEsimSubscriberCommand: (input: ProvisionEsimSubscriberCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1RefreshEsimQrCodeCommand
 */
export declare const se_RefreshEsimQrCodeCommand: (input: RefreshEsimQrCodeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SendSmsCommand
 */
export declare const se_SendSmsCommand: (input: SendSmsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SendSmsFromApplicationCommand
 */
export declare const se_SendSmsFromApplicationCommand: (input: SendSmsFromApplicationCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SendWhatsAppInteractiveMessageCommand
 */
export declare const se_SendWhatsAppInteractiveMessageCommand: (input: SendWhatsAppInteractiveMessageCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SendWhatsAppMessageCommand
 */
export declare const se_SendWhatsAppMessageCommand: (input: SendWhatsAppMessageCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SendWhatsAppTemplateCommand
 */
export declare const se_SendWhatsAppTemplateCommand: (input: SendWhatsAppTemplateCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SyncEsimTransformsCommand
 */
export declare const se_SyncEsimTransformsCommand: (input: SyncEsimTransformsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1TerminateEsimSubscriberCommand
 */
export declare const se_TerminateEsimSubscriberCommand: (input: TerminateEsimSubscriberCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1UpdateEsimSubscriberCommand
 */
export declare const se_UpdateEsimSubscriberCommand: (input: UpdateEsimSubscriberCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * deserializeAws_restJson1CleanupTangoEsimOrderCommand
 */
export declare const de_CleanupTangoEsimOrderCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CleanupTangoEsimOrderCommandOutput>;
/**
 * deserializeAws_restJson1CreateNumbersOrderCommand
 */
export declare const de_CreateNumbersOrderCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateNumbersOrderCommandOutput>;
/**
 * deserializeAws_restJson1CreateTangoEsimOrderCommand
 */
export declare const de_CreateTangoEsimOrderCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateTangoEsimOrderCommandOutput>;
/**
 * deserializeAws_restJson1DeleteEsimEndpointCommand
 */
export declare const de_DeleteEsimEndpointCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeleteEsimEndpointCommandOutput>;
/**
 * deserializeAws_restJson1GetEsimQrCodeCommand
 */
export declare const de_GetEsimQrCodeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetEsimQrCodeCommandOutput>;
/**
 * deserializeAws_restJson1GetEsimStatusCommand
 */
export declare const de_GetEsimStatusCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetEsimStatusCommandOutput>;
/**
 * deserializeAws_restJson1GetSmsHistoryCommand
 */
export declare const de_GetSmsHistoryCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetSmsHistoryCommandOutput>;
/**
 * deserializeAws_restJson1ListEsimBundlesCommand
 */
export declare const de_ListEsimBundlesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListEsimBundlesCommandOutput>;
/**
 * deserializeAws_restJson1ListEsimSubscribersCommand
 */
export declare const de_ListEsimSubscribersCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListEsimSubscribersCommandOutput>;
/**
 * deserializeAws_restJson1ListSmsNumbersCommand
 */
export declare const de_ListSmsNumbersCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListSmsNumbersCommandOutput>;
/**
 * deserializeAws_restJson1ListWhatsAppNumbersCommand
 */
export declare const de_ListWhatsAppNumbersCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListWhatsAppNumbersCommandOutput>;
/**
 * deserializeAws_restJson1ListWhatsAppTemplatesCommand
 */
export declare const de_ListWhatsAppTemplatesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListWhatsAppTemplatesCommandOutput>;
/**
 * deserializeAws_restJson1ProvisionEsimSubscriberCommand
 */
export declare const de_ProvisionEsimSubscriberCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ProvisionEsimSubscriberCommandOutput>;
/**
 * deserializeAws_restJson1RefreshEsimQrCodeCommand
 */
export declare const de_RefreshEsimQrCodeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<RefreshEsimQrCodeCommandOutput>;
/**
 * deserializeAws_restJson1SendSmsCommand
 */
export declare const de_SendSmsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SendSmsCommandOutput>;
/**
 * deserializeAws_restJson1SendSmsFromApplicationCommand
 */
export declare const de_SendSmsFromApplicationCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SendSmsFromApplicationCommandOutput>;
/**
 * deserializeAws_restJson1SendWhatsAppInteractiveMessageCommand
 */
export declare const de_SendWhatsAppInteractiveMessageCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SendWhatsAppInteractiveMessageCommandOutput>;
/**
 * deserializeAws_restJson1SendWhatsAppMessageCommand
 */
export declare const de_SendWhatsAppMessageCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SendWhatsAppMessageCommandOutput>;
/**
 * deserializeAws_restJson1SendWhatsAppTemplateCommand
 */
export declare const de_SendWhatsAppTemplateCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SendWhatsAppTemplateCommandOutput>;
/**
 * deserializeAws_restJson1SyncEsimTransformsCommand
 */
export declare const de_SyncEsimTransformsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SyncEsimTransformsCommandOutput>;
/**
 * deserializeAws_restJson1TerminateEsimSubscriberCommand
 */
export declare const de_TerminateEsimSubscriberCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<TerminateEsimSubscriberCommandOutput>;
/**
 * deserializeAws_restJson1UpdateEsimSubscriberCommand
 */
export declare const de_UpdateEsimSubscriberCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UpdateEsimSubscriberCommandOutput>;
