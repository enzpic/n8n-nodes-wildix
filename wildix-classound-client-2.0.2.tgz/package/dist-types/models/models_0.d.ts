import { ClassoundServiceException as __BaseException } from "./ClassoundServiceException";
import { ExceptionOptionType as __ExceptionOptionType } from "@smithy/smithy-client";
/**
 * @public
 */
export interface BodyTextNamedParam {
    paramName: string;
    example: string;
}
/**
 * @public
 * @enum
 */
export declare const ButtonType: {
    readonly APP: "APP";
    readonly CATALOG: "CATALOG";
    readonly FLOW: "FLOW";
    readonly MPM: "MPM";
    readonly OTP: "OTP";
    readonly PHONE_NUMBER: "PHONE_NUMBER";
    readonly QUICK_REPLY: "QUICK_REPLY";
    readonly URL: "URL";
    readonly VOICE_CALL: "VOICE_CALL";
};
/**
 * @public
 */
export type ButtonType = typeof ButtonType[keyof typeof ButtonType];
/**
 * @public
 */
export interface Button {
    type: ButtonType;
    text: string;
    flowId?: number | undefined;
    flowAction?: string | undefined;
    navigateScreen?: string | undefined;
}
/**
 * @public
 */
export interface CleanupTangoEsimOrderInput {
    /**
     * Order ID returned from POST /esim/order (base64-encoded key)
     * @public
     */
    orderId: string;
}
/**
 * @public
 * @enum
 */
export declare const TangoCleanupStatus: {
    readonly CLEANED: "CLEANED";
};
/**
 * @public
 */
export type TangoCleanupStatus = typeof TangoCleanupStatus[keyof typeof TangoCleanupStatus];
/**
 * @public
 */
export interface CleanupTangoEsimOrderOutput {
    status: TangoCleanupStatus;
    /**
     * Order ID that was cleaned up
     * @public
     */
    orderId: string;
    simsReleased: number;
    /**
     * Map of cleanup step names to their result status (e.g. 'move_to_bookin' -> 'success')
     * @public
     */
    steps: Record<string, string>;
}
/**
 * @public
 */
export declare class GatewayTimeoutException extends __BaseException {
    readonly name: "GatewayTimeoutException";
    readonly $fault: "client";
    type?: string | undefined;
    description?: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<GatewayTimeoutException, __BaseException>);
}
/**
 * @public
 */
export declare class InternalError extends __BaseException {
    readonly name: "InternalError";
    readonly $fault: "server";
    type: string;
    description: string;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<InternalError, __BaseException>);
}
/**
 * @public
 */
export declare class InternalServerException extends __BaseException {
    readonly name: "InternalServerException";
    readonly $fault: "server";
    type?: string | undefined;
    description?: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<InternalServerException, __BaseException>);
}
/**
 * @public
 */
export declare class NotFoundError extends __BaseException {
    readonly name: "NotFoundError";
    readonly $fault: "client";
    type: string;
    description: string;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<NotFoundError, __BaseException>);
}
/**
 * @public
 */
export declare class OrderError extends __BaseException {
    readonly name: "OrderError";
    readonly $fault: "client";
    type: string;
    description: string;
    requestId?: string | undefined;
    customerOrderId?: string | undefined;
    errorCode?: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<OrderError, __BaseException>);
}
/**
 * @public
 */
export declare class RequestValidationException extends __BaseException {
    readonly name: "RequestValidationException";
    readonly $fault: "client";
    type?: string | undefined;
    description?: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<RequestValidationException, __BaseException>);
}
/**
 * @public
 */
export declare class TangoEsimOrderError extends __BaseException {
    readonly name: "TangoEsimOrderError";
    readonly $fault: "client";
    requestId?: string | undefined;
    errorCode?: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<TangoEsimOrderError, __BaseException>);
}
/**
 * @public
 */
export declare class UserNotFoundException extends __BaseException {
    readonly name: "UserNotFoundException";
    readonly $fault: "client";
    type?: string | undefined;
    description?: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<UserNotFoundException, __BaseException>);
}
/**
 * @public
 */
export declare class ValidationError extends __BaseException {
    readonly name: "ValidationError";
    readonly $fault: "client";
    type: string;
    description: string;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<ValidationError, __BaseException>);
}
/**
 * Search criteria for phone number ordering. At least one of city, state, or zip must be provided.
 * @public
 */
export interface OrderSearchCriteria {
    country: string;
    state?: string | undefined;
    quantity: number;
    city?: string | undefined;
    zip?: string | undefined;
}
/**
 * @public
 */
export interface CreateNumbersOrderInput {
    companyId: string;
    requestId: string;
    customerOrderId: string;
    webhookUrl: string;
    webhookToken: string;
    /**
     * Search criteria for phone number ordering. At least one of city, state, or zip must be provided.
     * @public
     */
    data: OrderSearchCriteria;
}
/**
 * @public
 */
export interface CreateNumbersOrderOutput {
    status: string;
    supplierOrderId?: string | undefined;
    requestId?: string | undefined;
    customerOrderId?: string | undefined;
    orderStatus?: string | undefined;
    message?: string | undefined;
    testMode?: boolean | undefined;
}
/**
 * @public
 * @enum
 */
export declare const TangoBundleSku: {
    readonly PLAN_VC_MSG_10G: "PLAN-VC-MSG-10G";
    readonly PLAN_VC_MSG_20G: "PLAN-VC-MSG-20G";
    readonly PLAN_VC_MSG_2G: "PLAN-VC-MSG-2G";
    readonly PLAN_VC_MSG_4G: "PLAN-VC-MSG-4G";
    readonly PLAN_VC_MSG_BKGND: "PLAN-VC-MSG-BKGND";
    readonly PLAN_VC_MSG_UNLTD: "PLAN-VC-MSG-UNLTD";
};
/**
 * @public
 */
export type TangoBundleSku = typeof TangoBundleSku[keyof typeof TangoBundleSku];
/**
 * @public
 */
export interface CreateTangoEsimOrderInput {
    /**
     * Wildix partner ID
     * @public
     */
    partnerId: string;
    /**
     * Partner display name (used for Tango reseller creation)
     * @public
     */
    partnerName: string;
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * Company display name (used for Tango group creation)
     * @public
     */
    companyName: string;
    /**
     * ISO 3166-1 alpha-2 country code (e.g. IT, DE, US)
     * @public
     */
    countryCode: string;
    /**
     * Number of eSIMs to reserve
     * @public
     */
    quantity: number;
    /**
     * Unique request ID from Salesforce for idempotency tracking
     * @public
     */
    requestId: string;
    /**
     * Partner contact email (optional, used for Tango reseller creation)
     * @public
     */
    partnerEmail?: string | undefined;
    /**
     * Tango bundle/plan SKU to assign to allocated SIMs
     * @public
     */
    bundle: TangoBundleSku;
    /**
     * List of ISO 3166-1 alpha-2 country codes for Tango Reseller/Group Home Location. At least one country required. Allows the reseller to serve subscribers across multiple countries.
     * @public
     */
    homeLocations: (string)[];
    /**
     * Partner billing address line 1
     * @public
     */
    partnerAddress: string;
    /**
     * Partner billing postal/zip code
     * @public
     */
    partnerPostCode: string;
    /**
     * Partner contact phone number (E.164 digits only, no +)
     * @public
     */
    partnerContactNumber: string;
    /**
     * Partner billing address line 2 (optional)
     * @public
     */
    partnerAddress2?: string | undefined;
    /**
     * Partner billing town/city (optional)
     * @public
     */
    partnerTown?: string | undefined;
    /**
     * Partner billing county/state (optional)
     * @public
     */
    partnerCounty?: string | undefined;
    /**
     * Reseller description in Tango (optional)
     * @public
     */
    partnerDescription?: string | undefined;
}
/**
 * @public
 * @enum
 */
export declare const TangoOrderStatus: {
    readonly SUCCESS: "SUCCESS";
};
/**
 * @public
 */
export type TangoOrderStatus = typeof TangoOrderStatus[keyof typeof TangoOrderStatus];
/**
 * @public
 */
export interface CreateTangoEsimOrderOutput {
    status: TangoOrderStatus;
    /**
     * Internal order tracking ID (UUID)
     * @public
     */
    orderId: string;
    requestId: string;
    partnerId: string;
    companyId: string;
    countryCode: string;
    /**
     * Number of eSIMs allocated in this order (equals requested quantity)
     * @public
     */
    quantity: number;
    /**
     * Total SIMs currently in ALLOCATED state for this company across all orders
     * @public
     */
    totalReserved: number;
    /**
     * Bundle/plan SKU assigned to SIMs (echoed from request)
     * @public
     */
    bundle?: TangoBundleSku | undefined;
}
/**
 * @public
 */
export interface DeleteEsimEndpointInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
    /**
     * PBX serial number to delete
     * @public
     */
    serial: string;
}
/**
 * @public
 */
export interface DeleteEsimEndpointOutput {
    /**
     * Deletion status
     * @public
     */
    status: string;
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * PBX serial number that was deleted
     * @public
     */
    serial: string;
}
/**
 * @public
 */
export interface GetEsimQrCodeInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
    /**
     * Stable primary identifier of the subscriber to get the QR code for
     * @public
     */
    uid: string;
}
/**
 * @public
 */
export interface GetEsimQrCodeOutput {
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * Stable primary identifier of the subscriber
     * @public
     */
    uid: string;
    /**
     * User extension on PBX (current value)
     * @public
     */
    extension?: string | undefined;
    /**
     * ICCID of the eSIM
     * @public
     */
    iccid: string;
    /**
     * LPA activation code string for eSIM installation (e.g. LPA1:$smdp.example.com$code)
     * @public
     */
    activationCode: string;
    /**
     * Mobile number (E.164 digits only)
     * @public
     */
    phone?: string | undefined;
}
/**
 * @public
 */
export interface GetEsimStatusInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
    /**
     * Stable primary identifier of the subscriber
     * @public
     */
    uid: string;
}
/**
 * @public
 */
export interface GetEsimStatusOutput {
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * Stable primary identifier of the subscriber
     * @public
     */
    uid: string;
    /**
     * User extension on PBX (current value)
     * @public
     */
    extension?: string | undefined;
    /**
     * Mobile number (E.164 digits only)
     * @public
     */
    phone?: string | undefined;
    /**
     * ICCID of the eSIM
     * @public
     */
    iccid?: string | undefined;
    /**
     * eSIM status from Tango (e.g. INSTALLED, AVAILABLE, RELEASED, ERROR)
     * @public
     */
    esimStatus: string;
    /**
     * Tango subscriber UID
     * @public
     */
    subUID?: string | undefined;
}
/**
 * @public
 */
export interface GetSmsHistoryInput {
    from?: string | undefined;
    to?: string | undefined;
    companyId?: string | undefined;
}
/**
 * @public
 */
export interface GetSmsHistoryRecord {
    from?: string | undefined;
    to?: string | undefined;
    messageId?: string | undefined;
    messageText?: string | undefined;
    time?: number | undefined;
}
/**
 * @public
 */
export interface GetSmsHistoryOutput {
    type?: string | undefined;
    result?: (GetSmsHistoryRecord)[] | undefined;
}
/**
 * @public
 */
export interface ListEsimBundlesInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
}
/**
 * SIM count breakdown per bundle/plan
 * @public
 */
export interface EsimBundleCount {
    /**
     * Bundle/plan SKU
     * @public
     */
    bundle: TangoBundleSku;
    /**
     * SIMs available for provisioning in this bundle
     * @public
     */
    available: number;
    /**
     * SIMs actively provisioned in this bundle
     * @public
     */
    active: number;
}
/**
 * @public
 */
export interface ListEsimBundlesOutput {
    /**
     * SIM count breakdown per bundle/plan
     * @public
     */
    bundles: (EsimBundleCount)[];
}
/**
 * @public
 */
export interface ListEsimSubscribersInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
    /**
     * Maximum number of subscribers to return. If omitted, returns all.
     * @public
     */
    limit?: number | undefined;
    /**
     * Number of subscribers to skip (default 0)
     * @public
     */
    offset?: number | undefined;
}
/**
 * A provisioned eSIM subscriber
 * @public
 */
export interface SubscriberItem {
    /**
     * PBX user UID — primary identifier for the subscriber
     * @public
     */
    uid: string;
    /**
     * User extension / SIP address on PBX (current value)
     * @public
     */
    extension?: string | undefined;
    /**
     * Mobile number (E.164 digits only)
     * @public
     */
    phone?: string | undefined;
    /**
     * User email address
     * @public
     */
    email?: string | undefined;
    /**
     * ICCID of the eSIM
     * @public
     */
    iccid?: string | undefined;
    /**
     * Tango subscriber UID
     * @public
     */
    subUID?: string | undefined;
    /**
     * PBX serial number
     * @public
     */
    serial?: string | undefined;
    /**
     * Bundle/plan SKU
     * @public
     */
    bundle?: string | undefined;
    /**
     * User first name
     * @public
     */
    firstName?: string | undefined;
    /**
     * User last name
     * @public
     */
    lastName?: string | undefined;
    /**
     * eSIM status from Tango (e.g. PROVISIONED, ACTIVE)
     * @public
     */
    status?: string | undefined;
}
/**
 * @public
 */
export interface ListEsimSubscribersOutput {
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * List of provisioned subscribers
     * @public
     */
    subscribers: (SubscriberItem)[];
    /**
     * Total number of subscribers for this company
     * @public
     */
    total: number;
    /**
     * Maximum number of subscribers returned
     * @public
     */
    limit: number;
    /**
     * Number of subscribers skipped
     * @public
     */
    offset: number;
}
/**
 * @public
 */
export interface ListSmsNumbersInput {
    companyId: string;
}
/**
 * @public
 */
export interface SmsNumbersResult {
    companyId: string;
    numbers?: (string)[] | undefined;
}
/**
 * @public
 */
export interface ListSmsNumbersOutput {
    type: string;
    success: boolean;
    timestamp: number;
    result: SmsNumbersResult;
}
/**
 * @public
 */
export interface ListWhatsAppNumbersInput {
    companyId: string;
}
/**
 * @public
 */
export interface WhatsAppNumbersResult {
    companyId: string;
    numbers?: (string)[] | undefined;
}
/**
 * @public
 */
export interface ListWhatsAppNumbersOutput {
    type: string;
    success: boolean;
    timestamp: number;
    result: WhatsAppNumbersResult;
}
/**
 * @public
 */
export interface ListWhatsAppTemplatesInput {
    did: string;
}
/**
 * @public
 * @enum
 */
export declare const TemplateCategory: {
    readonly AUTHENTICATION: "AUTHENTICATION";
    readonly MARKETING: "MARKETING";
    readonly UTILITY: "UTILITY";
};
/**
 * @public
 */
export type TemplateCategory = typeof TemplateCategory[keyof typeof TemplateCategory];
/**
 * @public
 */
export interface ComponentExample {
    headerHandle?: (string)[] | undefined;
    bodyTextNamedParams?: (BodyTextNamedParam)[] | undefined;
}
/**
 * @public
 * @enum
 */
export declare const ComponentFormat: {
    readonly IMAGE: "IMAGE";
    readonly TEXT: "TEXT";
};
/**
 * @public
 */
export type ComponentFormat = typeof ComponentFormat[keyof typeof ComponentFormat];
/**
 * @public
 * @enum
 */
export declare const ComponentType: {
    readonly BODY: "BODY";
    readonly BUTTONS: "BUTTONS";
    readonly FOOTER: "FOOTER";
    readonly HEADER: "HEADER";
};
/**
 * @public
 */
export type ComponentType = typeof ComponentType[keyof typeof ComponentType];
/**
 * @public
 */
export interface Component {
    type: ComponentType;
    format: ComponentFormat;
    text?: string | undefined;
    example?: ComponentExample | undefined;
    buttons?: (Button)[] | undefined;
}
/**
 * @public
 * @enum
 */
export declare const ParameterFormat: {
    readonly NAMED: "NAMED";
};
/**
 * @public
 */
export type ParameterFormat = typeof ParameterFormat[keyof typeof ParameterFormat];
/**
 * @public
 * @enum
 */
export declare const TemplateStatus: {
    readonly APPROVED: "APPROVED";
    readonly PAUSED: "PAUSED";
    readonly REJECTED: "REJECTED";
};
/**
 * @public
 */
export type TemplateStatus = typeof TemplateStatus[keyof typeof TemplateStatus];
/**
 * @public
 */
export interface Template {
    name: string;
    parameterFormat: ParameterFormat;
    components: (Component)[];
    language: string;
    status: TemplateStatus;
    category: TemplateCategory;
    subCategory?: string | undefined;
    id: string;
}
/**
 * @public
 */
export interface ListWhatsAppTemplatesOutput {
    type: string;
    success: boolean;
    did: string;
    data: (Template)[];
}
/**
 * @public
 */
export interface ProvisionEsimSubscriberInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
    /**
     * Stable primary identifier for the subscriber.
     * @public
     */
    uid: string;
    /**
     * PBX serial number (maps to KC-PBX / endpointName in Tango)
     * @public
     */
    serial: string;
    /**
     * PBX domain (IP or FQDN, e.g. 'mycompany.wildixin.com')
     * @public
     */
    host: string;
    /**
     * User extension / SIP address on PBX
     * @public
     */
    extension: string;
    /**
     * Mobile number with country code, digits only (MDN-E164)
     * @public
     */
    phone: string;
    /**
     * User email address (Tango sends QR code to this address)
     * @public
     */
    email: string;
    /**
     * User first name
     * @public
     */
    firstName?: string | undefined;
    /**
     * User last name
     * @public
     */
    lastName?: string | undefined;
    /**
     * PBX SIP password for the extension (Tango uses it to register to PBX)
     * @public
     */
    userPassword: string;
    /**
     * Override bundle/plan SKU for this subscriber. If not provided, the group default bundle is used.
     * @public
     */
    bundle?: TangoBundleSku | undefined;
}
/**
 * @public
 * @enum
 */
export declare const TangoProvisionStatus: {
    readonly ALREADY_PROVISIONED: "ALREADY_PROVISIONED";
    readonly PROVISIONED: "PROVISIONED";
};
/**
 * @public
 */
export type TangoProvisionStatus = typeof TangoProvisionStatus[keyof typeof TangoProvisionStatus];
/**
 * @public
 */
export interface ProvisionEsimSubscriberOutput {
    status: TangoProvisionStatus;
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * Unique identifier of the user in the WMS Network (7-digit numeric, 1,000,000–9,999,999)
     * @public
     */
    uid: string;
    /**
     * User extension
     * @public
     */
    extension: string;
    /**
     * Mobile number (MDN-E164)
     * @public
     */
    phone: string;
    /**
     * Tango subscriber UID (needed for future updates/deletes)
     * @public
     */
    subUID: string;
    /**
     * ICCID of the provisioned eSIM
     * @public
     */
    iccid: string;
    /**
     * LPA activation code string for eSIM installation
     * @public
     */
    activationCode?: string | undefined;
}
/**
 * @public
 */
export interface RefreshEsimQrCodeInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
    /**
     * PBX user UID (7-digit numeric) identifying the subscriber
     * @public
     */
    uid: string;
}
/**
 * @public
 */
export interface RefreshEsimQrCodeOutput {
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * PBX user UID
     * @public
     */
    uid: string;
    /**
     * User extension on PBX (current value)
     * @public
     */
    extension?: string | undefined;
    /**
     * ICCID of the eSIM
     * @public
     */
    iccid: string;
    /**
     * Regenerated LPA activation code string for eSIM installation
     * @public
     */
    activationCode: string;
    /**
     * Mobile number (E.164 digits only)
     * @public
     */
    phone?: string | undefined;
}
/**
 * @public
 */
export interface SendSmsInput {
    from: string;
    to: string;
    pbx: string;
    company: string;
    message: string;
    extension: string;
    media?: (string)[] | undefined;
    userId?: string | undefined;
    channelId?: string | undefined;
    messageId?: string | undefined;
}
/**
 * @public
 */
export interface SendSmsOutputData {
    from?: string | undefined;
    to?: string | undefined;
    message?: string | undefined;
    pbx?: string | undefined;
    extension?: string | undefined;
}
/**
 * @public
 */
export interface SendSmsOutput {
    type?: string | undefined;
    success?: boolean | undefined;
    status?: string | undefined;
    id?: (string)[] | undefined;
    company?: string | undefined;
    data?: SendSmsOutputData | undefined;
}
/**
 * @public
 */
export interface SendSmsFromApplicationInput {
    from: string;
    to: string;
    message: string;
}
/**
 * @public
 */
export interface SendSmsData {
    from?: string | undefined;
    to?: string | undefined;
    message?: string | undefined;
    pbx?: string | undefined;
    extension?: string | undefined;
}
/**
 * @public
 */
export interface SendSmsFromApplicationOutput {
    type?: string | undefined;
    success?: boolean | undefined;
    status?: string | undefined;
    id?: (string)[] | undefined;
    company?: string | undefined;
    data?: SendSmsData | undefined;
}
/**
 * @public
 */
export interface InteractiveButtonReply {
    id: string;
    title: string;
}
/**
 * @public
 * @enum
 */
export declare const InteractiveButtonType: {
    readonly REPLY: "reply";
};
/**
 * @public
 */
export type InteractiveButtonType = typeof InteractiveButtonType[keyof typeof InteractiveButtonType];
/**
 * @public
 */
export interface InteractiveButton {
    type: InteractiveButtonType;
    reply: InteractiveButtonReply;
}
/**
 * @public
 */
export interface InteractiveRow {
    id: string;
    title: string;
    description?: string | undefined;
}
/**
 * @public
 */
export interface InteractiveSection {
    title: string;
    rows: (InteractiveRow)[];
}
/**
 * @public
 */
export interface InteractiveAction {
    buttons?: (InteractiveButton)[] | undefined;
    sections?: (InteractiveSection)[] | undefined;
}
/**
 * @public
 */
export interface InteractiveBody {
    text: string;
}
/**
 * @public
 */
export interface InteractiveFooter {
    text: string;
}
/**
 * @public
 */
export interface InteractiveMedia {
    id: string;
    link: string;
    filename?: string | undefined;
}
/**
 * @public
 * @enum
 */
export declare const HeaderType: {
    readonly IMAGE: "image";
    readonly TEXT: "text";
};
/**
 * @public
 */
export type HeaderType = typeof HeaderType[keyof typeof HeaderType];
/**
 * @public
 */
export interface InteractiveHeader {
    type: HeaderType;
    text?: string | undefined;
    image?: InteractiveMedia | undefined;
    video?: InteractiveMedia | undefined;
    document?: InteractiveMedia | undefined;
}
/**
 * @public
 * @enum
 */
export declare const InteractiveContentType: {
    readonly BUTTON: "button";
    readonly LIST: "list";
};
/**
 * @public
 */
export type InteractiveContentType = typeof InteractiveContentType[keyof typeof InteractiveContentType];
/**
 * @public
 */
export interface InteractiveMessage {
    type: InteractiveContentType;
    header?: InteractiveHeader | undefined;
    body: InteractiveBody;
    footer?: InteractiveFooter | undefined;
    action: InteractiveAction;
}
/**
 * @public
 */
export interface SendWhatsAppInteractiveMessageInput {
    from: string;
    to: string;
    pbx: string;
    company: string;
    message: InteractiveMessage;
    extension: string;
    userId?: string | undefined;
    channelId?: string | undefined;
    messageId?: string | undefined;
}
/**
 * @public
 */
export interface SendWhatsAppInteractiveMessageData {
    from?: string | undefined;
    to?: string | undefined;
    pbx?: string | undefined;
    company?: string | undefined;
    message?: InteractiveMessage | undefined;
    extension?: string | undefined;
}
/**
 * @public
 */
export interface SendWhatsAppInteractiveMessageOutput {
    type?: string | undefined;
    success?: boolean | undefined;
    company?: string | undefined;
    status?: string | undefined;
    id?: (string)[] | undefined;
    data?: SendWhatsAppInteractiveMessageData | undefined;
}
/**
 * @public
 */
export interface SendWhatsAppMessageInput {
    from: string;
    to: string;
    pbx: string;
    company: string;
    message: string;
    extension: string;
    media?: (string)[] | undefined;
    userId?: string | undefined;
    channelId?: string | undefined;
    messageId?: string | undefined;
}
/**
 * @public
 */
export interface SendWhatsAppMessageData {
    from?: string | undefined;
    to?: string | undefined;
    pbx?: string | undefined;
    company?: string | undefined;
    message?: string | undefined;
    extension?: string | undefined;
    media?: (string)[] | undefined;
    userId?: string | undefined;
    channelId?: string | undefined;
    messageId?: string | undefined;
}
/**
 * @public
 */
export interface SendWhatsAppMessageOutput {
    type?: string | undefined;
    success?: boolean | undefined;
    company?: string | undefined;
    status?: string | undefined;
    id?: (string)[] | undefined;
    data?: SendWhatsAppMessageData | undefined;
}
/**
 * @public
 */
export interface TemplateParameter {
    name: string;
    value: string;
}
/**
 * @public
 */
export interface TemplateWithParameters {
    name: string;
    parameters?: (TemplateParameter)[] | undefined;
}
/**
 * @public
 */
export interface SendWhatsAppTemplateInput {
    to: string;
    company: string;
    pbx: string;
    extension: string;
    from: string;
    channelId?: string | undefined;
    messageId?: string | undefined;
    userId?: string | undefined;
    template: TemplateWithParameters;
}
/**
 * @public
 */
export interface SendWhatsAppTemplateData {
    from?: string | undefined;
    to?: string | undefined;
    template?: TemplateWithParameters | undefined;
    pbx?: string | undefined;
    extension?: string | undefined;
}
/**
 * @public
 */
export interface SendWhatsAppTemplateOutput {
    type: string;
    success: boolean;
    status: string;
    id: string;
    company: string;
    data: SendWhatsAppTemplateData;
}
/**
 * @public
 */
export interface TransformEntry {
    /**
     * PBX extension / short code
     * @public
     */
    extension: string;
    /**
     * E.164 number (digits only, no +)
     * @public
     */
    e164: string;
}
/**
 * @public
 */
export interface SyncEsimTransformsInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
    /**
     * List of desired extension-to-E.164 mappings (full snapshot)
     * @public
     */
    transforms: (TransformEntry)[];
}
/**
 * @public
 */
export interface TransformError {
    /**
     * Action attempted: add, update, or delete
     * @public
     */
    action?: string | undefined;
    /**
     * Extension that failed
     * @public
     */
    extension?: string | undefined;
    /**
     * Error message from Tango
     * @public
     */
    error?: string | undefined;
}
/**
 * @public
 */
export interface SyncEsimTransformsOutput {
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * Number of transforms added
     * @public
     */
    added: number;
    /**
     * Number of transforms updated
     * @public
     */
    updated: number;
    /**
     * Number of transforms deleted
     * @public
     */
    deleted: number;
    /**
     * List of per-transform errors (if any)
     * @public
     */
    errors?: (TransformError)[] | undefined;
}
/**
 * @public
 */
export interface TerminateEsimSubscriberInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
    /**
     * Stable primary identifier of the subscriber to terminate
     * @public
     */
    uid: string;
}
/**
 * @public
 * @enum
 */
export declare const TangoTerminateStatus: {
    readonly TERMINATED: "TERMINATED";
};
/**
 * @public
 */
export type TangoTerminateStatus = typeof TangoTerminateStatus[keyof typeof TangoTerminateStatus];
/**
 * @public
 */
export interface TerminateEsimSubscriberOutput {
    status: TangoTerminateStatus;
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * Stable primary identifier of the terminated subscriber
     * @public
     */
    uid: string;
    /**
     * User extension at time of termination (from DynamoDB)
     * @public
     */
    extension?: string | undefined;
    /**
     * Tango subscriber UID
     * @public
     */
    subUID?: string | undefined;
}
/**
 * @public
 */
export interface UpdateEsimSubscriberInput {
    /**
     * Wildix company ID. Optional when using PBX token (resolved from authorizer).
     * @public
     */
    companyId?: string | undefined;
    /**
     * Stable primary identifier of the subscriber to update
     * @public
     */
    uid: string;
    /**
     * New extension / SIP address. Updates SIP-ADDRESS in Tango and the DynamoDB extension attribute.
     * @public
     */
    extension?: string | undefined;
    /**
     * New email address
     * @public
     */
    email?: string | undefined;
    /**
     * New first name
     * @public
     */
    firstName?: string | undefined;
    /**
     * New last name
     * @public
     */
    lastName?: string | undefined;
    /**
     * New mobile number with country code, digits only (MDN-E164)
     * @public
     */
    phone?: string | undefined;
    /**
     * New PBX SIP password
     * @public
     */
    userPassword?: string | undefined;
    /**
     * New bundle/plan SKU
     * @public
     */
    bundle?: TangoBundleSku | undefined;
}
/**
 * @public
 * @enum
 */
export declare const TangoUpdateStatus: {
    readonly UPDATED: "UPDATED";
};
/**
 * @public
 */
export type TangoUpdateStatus = typeof TangoUpdateStatus[keyof typeof TangoUpdateStatus];
/**
 * @public
 */
export interface UpdateEsimSubscriberOutput {
    status: TangoUpdateStatus;
    /**
     * Wildix company ID
     * @public
     */
    companyId: string;
    /**
     * Stable primary identifier of the updated subscriber
     * @public
     */
    uid: string;
    /**
     * List of fields that were updated
     * @public
     */
    updatedFields: (string)[];
}
