import { CleanupTangoEsimOrderCommandInput, CleanupTangoEsimOrderCommandOutput } from "./commands/CleanupTangoEsimOrderCommand";
import { CreateNumbersOrderCommandInput, CreateNumbersOrderCommandOutput } from "./commands/CreateNumbersOrderCommand";
import { CreateTangoEsimOrderCommandInput, CreateTangoEsimOrderCommandOutput } from "./commands/CreateTangoEsimOrderCommand";
import { DeleteEsimEndpointCommandInput, DeleteEsimEndpointCommandOutput } from "./commands/DeleteEsimEndpointCommand";
import { GetEsimQrCodeCommandInput, GetEsimQrCodeCommandOutput } from "./commands/GetEsimQrCodeCommand";
import { GetEsimStatusCommandInput, GetEsimStatusCommandOutput } from "./commands/GetEsimStatusCommand";
import { GetSmsHistoryCommandInput, GetSmsHistoryCommandOutput } from "./commands/GetSmsHistoryCommand";
import { ListEsimBundlesCommandInput, ListEsimBundlesCommandOutput } from "./commands/ListEsimBundlesCommand";
import { ListEsimSubscribersCommandInput, ListEsimSubscribersCommandOutput } from "./commands/ListEsimSubscribersCommand";
import { ListSmsNumbersCommandInput, ListSmsNumbersCommandOutput } from "./commands/ListSmsNumbersCommand";
import { ListWhatsAppNumbersCommandInput, ListWhatsAppNumbersCommandOutput } from "./commands/ListWhatsAppNumbersCommand";
import { ListWhatsAppTemplatesCommandInput, ListWhatsAppTemplatesCommandOutput } from "./commands/ListWhatsAppTemplatesCommand";
import { ProvisionEsimSubscriberCommandInput, ProvisionEsimSubscriberCommandOutput } from "./commands/ProvisionEsimSubscriberCommand";
import { RefreshEsimQrCodeCommandInput, RefreshEsimQrCodeCommandOutput } from "./commands/RefreshEsimQrCodeCommand";
import { SendSmsCommandInput, SendSmsCommandOutput } from "./commands/SendSmsCommand";
import { SendSmsFromApplicationCommandInput, SendSmsFromApplicationCommandOutput } from "./commands/SendSmsFromApplicationCommand";
import { SendWhatsAppInteractiveMessageCommandInput, SendWhatsAppInteractiveMessageCommandOutput } from "./commands/SendWhatsAppInteractiveMessageCommand";
import { SendWhatsAppMessageCommandInput, SendWhatsAppMessageCommandOutput } from "./commands/SendWhatsAppMessageCommand";
import { SendWhatsAppTemplateCommandInput, SendWhatsAppTemplateCommandOutput } from "./commands/SendWhatsAppTemplateCommand";
import { SyncEsimTransformsCommandInput, SyncEsimTransformsCommandOutput } from "./commands/SyncEsimTransformsCommand";
import { TerminateEsimSubscriberCommandInput, TerminateEsimSubscriberCommandOutput } from "./commands/TerminateEsimSubscriberCommand";
import { UpdateEsimSubscriberCommandInput, UpdateEsimSubscriberCommandOutput } from "./commands/UpdateEsimSubscriberCommand";
import { RuntimeExtension, RuntimeExtensionsConfig } from "./runtimeExtensions";
import { UserAgentInputConfig, UserAgentResolvedConfig } from "@aws-sdk/middleware-user-agent";
import { RetryInputConfig, RetryResolvedConfig } from "@smithy/middleware-retry";
import { HttpHandlerUserInput as __HttpHandlerUserInput } from "@smithy/protocol-http";
import { Client as __Client, DefaultsMode as __DefaultsMode, SmithyConfiguration as __SmithyConfiguration, SmithyResolvedConfiguration as __SmithyResolvedConfiguration } from "@smithy/smithy-client";
import { Provider, BodyLengthCalculator as __BodyLengthCalculator, CheckOptionalClientConfig as __CheckOptionalClientConfig, ChecksumConstructor as __ChecksumConstructor, Decoder as __Decoder, Encoder as __Encoder, HashConstructor as __HashConstructor, HttpHandlerOptions as __HttpHandlerOptions, Logger as __Logger, Provider as __Provider, StreamCollector as __StreamCollector, UrlParser as __UrlParser, UserAgent as __UserAgent } from "@smithy/types";
import { TokenProvider } from '@wildix/smithy-utils';
export { __Client };
/**
 * @public
 */
export type ServiceInputTypes = CleanupTangoEsimOrderCommandInput | CreateNumbersOrderCommandInput | CreateTangoEsimOrderCommandInput | DeleteEsimEndpointCommandInput | GetEsimQrCodeCommandInput | GetEsimStatusCommandInput | GetSmsHistoryCommandInput | ListEsimBundlesCommandInput | ListEsimSubscribersCommandInput | ListSmsNumbersCommandInput | ListWhatsAppNumbersCommandInput | ListWhatsAppTemplatesCommandInput | ProvisionEsimSubscriberCommandInput | RefreshEsimQrCodeCommandInput | SendSmsCommandInput | SendSmsFromApplicationCommandInput | SendWhatsAppInteractiveMessageCommandInput | SendWhatsAppMessageCommandInput | SendWhatsAppTemplateCommandInput | SyncEsimTransformsCommandInput | TerminateEsimSubscriberCommandInput | UpdateEsimSubscriberCommandInput;
/**
 * @public
 */
export type ServiceOutputTypes = CleanupTangoEsimOrderCommandOutput | CreateNumbersOrderCommandOutput | CreateTangoEsimOrderCommandOutput | DeleteEsimEndpointCommandOutput | GetEsimQrCodeCommandOutput | GetEsimStatusCommandOutput | GetSmsHistoryCommandOutput | ListEsimBundlesCommandOutput | ListEsimSubscribersCommandOutput | ListSmsNumbersCommandOutput | ListWhatsAppNumbersCommandOutput | ListWhatsAppTemplatesCommandOutput | ProvisionEsimSubscriberCommandOutput | RefreshEsimQrCodeCommandOutput | SendSmsCommandOutput | SendSmsFromApplicationCommandOutput | SendWhatsAppInteractiveMessageCommandOutput | SendWhatsAppMessageCommandOutput | SendWhatsAppTemplateCommandOutput | SyncEsimTransformsCommandOutput | TerminateEsimSubscriberCommandOutput | UpdateEsimSubscriberCommandOutput;
/**
 * @public
 */
export interface ClientDefaults extends Partial<__SmithyConfiguration<__HttpHandlerOptions>> {
    /**
     * The HTTP handler to use or its constructor options. Fetch in browser and Https in Nodejs.
     */
    requestHandler?: __HttpHandlerUserInput;
    /**
     * A constructor for a class implementing the {@link @smithy/types#ChecksumConstructor} interface
     * that computes the SHA-256 HMAC or checksum of a string or binary buffer.
     * @internal
     */
    sha256?: __ChecksumConstructor | __HashConstructor;
    /**
     * The function that will be used to convert strings into HTTP endpoints.
     * @internal
     */
    urlParser?: __UrlParser;
    /**
     * A function that can calculate the length of a request body.
     * @internal
     */
    bodyLengthChecker?: __BodyLengthCalculator;
    /**
     * A function that converts a stream into an array of bytes.
     * @internal
     */
    streamCollector?: __StreamCollector;
    /**
     * The function that will be used to convert a base64-encoded string to a byte array.
     * @internal
     */
    base64Decoder?: __Decoder;
    /**
     * The function that will be used to convert binary data to a base64-encoded string.
     * @internal
     */
    base64Encoder?: __Encoder;
    /**
     * The function that will be used to convert a UTF8-encoded string to a byte array.
     * @internal
     */
    utf8Decoder?: __Decoder;
    /**
     * The function that will be used to convert binary data to a UTF-8 encoded string.
     * @internal
     */
    utf8Encoder?: __Encoder;
    /**
     * The runtime environment.
     * @internal
     */
    runtime?: string;
    /**
     * Disable dynamically changing the endpoint of the client based on the hostPrefix
     * trait of an operation.
     */
    disableHostPrefix?: boolean;
    /**
     * The provider populating default tracking information to be sent with `user-agent`, `x-amz-user-agent` header
     * @internal
     */
    defaultUserAgentProvider?: Provider<__UserAgent>;
    /**
     * Value for how many times a request will be made at most in case of retry.
     */
    maxAttempts?: number | __Provider<number>;
    /**
     * Specifies which retry algorithm to use.
     * @see https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/Package/-smithy-util-retry/Enum/RETRY_MODES/
     *
     */
    retryMode?: string | __Provider<string>;
    /**
     * Optional logger for logging debug/info/warn/error.
     */
    logger?: __Logger;
    /**
     * Optional extensions
     */
    extensions?: RuntimeExtension[];
    /**
     * The {@link @smithy/smithy-client#DefaultsMode} that will be used to determine how certain default configuration options are resolved in the SDK.
     */
    defaultsMode?: __DefaultsMode | __Provider<__DefaultsMode>;
}
/**
 * @public
 */
export type ClassoundClientConfigType = Partial<__SmithyConfiguration<__HttpHandlerOptions>> & ClientDefaults & UserAgentInputConfig & RetryInputConfig;
/**
 * @public
 *
 *  The configuration interface of ClassoundClient class constructor that set the region, credentials and other options.
 */
export interface ClassoundClientConfig extends ClassoundClientConfigType {
    env?: 'stage' | 'stable' | 'prod';
    token: TokenProvider;
}
/**
 * @public
 */
export type ClassoundClientResolvedConfigType = __SmithyResolvedConfiguration<__HttpHandlerOptions> & Required<ClientDefaults> & RuntimeExtensionsConfig & UserAgentResolvedConfig & RetryResolvedConfig;
/**
 * @public
 *
 *  The resolved configuration interface of ClassoundClient class. This is resolved and normalized from the {@link ClassoundClientConfig | constructor configuration interface}.
 */
export interface ClassoundClientResolvedConfig extends ClassoundClientResolvedConfigType {
}
/**
 * @public
 */
export declare class ClassoundClient extends __Client<__HttpHandlerOptions, ServiceInputTypes, ServiceOutputTypes, ClassoundClientResolvedConfig> {
    /**
     * The resolved configuration of ClassoundClient class. This is resolved and normalized from the {@link ClassoundClientConfig | constructor configuration interface}.
     */
    readonly config: ClassoundClientResolvedConfig;
    constructor(...[configuration]: __CheckOptionalClientConfig<ClassoundClientConfig>);
    /**
     * Destroy underlying resources, like sockets. It's usually not necessary to do this.
     * However in Node.js, it's best to explicitly shut down the client's agent when it is no longer needed.
     * Otherwise, sockets might stay open for quite a long time before the server terminates them.
     */
    destroy(): void;
}
