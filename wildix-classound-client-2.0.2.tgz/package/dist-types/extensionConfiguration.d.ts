import { HttpHandlerExtensionConfiguration } from "@smithy/protocol-http";
import { DefaultExtensionConfiguration } from "@smithy/types";
/**
 * @internal
 */
export interface ClassoundExtensionConfiguration extends HttpHandlerExtensionConfiguration, DefaultExtensionConfiguration {
}
