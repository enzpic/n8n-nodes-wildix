"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.de_UpdateEsimSubscriberCommand = exports.de_TerminateEsimSubscriberCommand = exports.de_SyncEsimTransformsCommand = exports.de_SendWhatsAppTemplateCommand = exports.de_SendWhatsAppMessageCommand = exports.de_SendWhatsAppInteractiveMessageCommand = exports.de_SendSmsFromApplicationCommand = exports.de_SendSmsCommand = exports.de_RefreshEsimQrCodeCommand = exports.de_ProvisionEsimSubscriberCommand = exports.de_ListWhatsAppTemplatesCommand = exports.de_ListWhatsAppNumbersCommand = exports.de_ListSmsNumbersCommand = exports.de_ListEsimSubscribersCommand = exports.de_ListEsimBundlesCommand = exports.de_GetSmsHistoryCommand = exports.de_GetEsimStatusCommand = exports.de_GetEsimQrCodeCommand = exports.de_DeleteEsimEndpointCommand = exports.de_CreateTangoEsimOrderCommand = exports.de_CreateNumbersOrderCommand = exports.de_CleanupTangoEsimOrderCommand = exports.se_UpdateEsimSubscriberCommand = exports.se_TerminateEsimSubscriberCommand = exports.se_SyncEsimTransformsCommand = exports.se_SendWhatsAppTemplateCommand = exports.se_SendWhatsAppMessageCommand = exports.se_SendWhatsAppInteractiveMessageCommand = exports.se_SendSmsFromApplicationCommand = exports.se_SendSmsCommand = exports.se_RefreshEsimQrCodeCommand = exports.se_ProvisionEsimSubscriberCommand = exports.se_ListWhatsAppTemplatesCommand = exports.se_ListWhatsAppNumbersCommand = exports.se_ListSmsNumbersCommand = exports.se_ListEsimSubscribersCommand = exports.se_ListEsimBundlesCommand = exports.se_GetSmsHistoryCommand = exports.se_GetEsimStatusCommand = exports.se_GetEsimQrCodeCommand = exports.se_DeleteEsimEndpointCommand = exports.se_CreateTangoEsimOrderCommand = exports.se_CreateNumbersOrderCommand = exports.se_CleanupTangoEsimOrderCommand = void 0;
const ClassoundServiceException_1 = require("../models/ClassoundServiceException");
const models_0_1 = require("../models/models_0");
const core_1 = require("@aws-sdk/core");
const core_2 = require("@smithy/core");
const smithy_client_1 = require("@smithy/smithy-client");
const se_CleanupTangoEsimOrderCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/order/cleanup");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'orderId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_CleanupTangoEsimOrderCommand = se_CleanupTangoEsimOrderCommand;
const se_CreateNumbersOrderCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/numbers/ordering/order");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'companyId': [],
        'customerOrderId': [],
        'data': _ => (0, smithy_client_1._json)(_),
        'requestId': [],
        'webhookToken': [],
        'webhookUrl': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_CreateNumbersOrderCommand = se_CreateNumbersOrderCommand;
const se_CreateTangoEsimOrderCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/order");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'bundle': [],
        'companyId': [],
        'companyName': [],
        'countryCode': [],
        'homeLocations': _ => (0, smithy_client_1._json)(_),
        'partnerAddress': [],
        'partnerAddress2': [],
        'partnerContactNumber': [],
        'partnerCounty': [],
        'partnerDescription': [],
        'partnerEmail': [],
        'partnerId': [],
        'partnerName': [],
        'partnerPostCode': [],
        'partnerTown': [],
        'quantity': [],
        'requestId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_CreateTangoEsimOrderCommand = se_CreateTangoEsimOrderCommand;
const se_DeleteEsimEndpointCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/v1/esim/endpoint");
    const query = (0, smithy_client_1.map)({
        [_cI]: [, input[_cI]],
        [_s]: [, (0, smithy_client_1.expectNonNull)(input[_s], `serial`)],
    });
    let body;
    b.m("DELETE")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_DeleteEsimEndpointCommand = se_DeleteEsimEndpointCommand;
const se_GetEsimQrCodeCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/v1/esim/subscriber/qrcode");
    const query = (0, smithy_client_1.map)({
        [_cI]: [, input[_cI]],
        [_u]: [, (0, smithy_client_1.expectNonNull)(input[_u], `uid`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_GetEsimQrCodeCommand = se_GetEsimQrCodeCommand;
const se_GetEsimStatusCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/v1/esim/status");
    const query = (0, smithy_client_1.map)({
        [_cI]: [, input[_cI]],
        [_u]: [, (0, smithy_client_1.expectNonNull)(input[_u], `uid`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_GetEsimStatusCommand = se_GetEsimStatusCommand;
const se_GetSmsHistoryCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/v1/s2s/sms/history");
    const query = (0, smithy_client_1.map)({
        [_f]: [, input[_f]],
        [_t]: [, input[_t]],
        [_cI]: [, input[_cI]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_GetSmsHistoryCommand = se_GetSmsHistoryCommand;
const se_ListEsimBundlesCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/v1/esim/bundles");
    const query = (0, smithy_client_1.map)({
        [_cI]: [, input[_cI]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_ListEsimBundlesCommand = se_ListEsimBundlesCommand;
const se_ListEsimSubscribersCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/v1/esim/subscribers");
    const query = (0, smithy_client_1.map)({
        [_cI]: [, input[_cI]],
        [_l]: [() => input.limit !== void 0, () => (input[_l].toString())],
        [_o]: [() => input.offset !== void 0, () => (input[_o].toString())],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_ListEsimSubscribersCommand = se_ListEsimSubscribersCommand;
const se_ListSmsNumbersCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/v1/s2s/sms/numbers");
    const query = (0, smithy_client_1.map)({
        [_cI]: [, (0, smithy_client_1.expectNonNull)(input[_cI], `companyId`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_ListSmsNumbersCommand = se_ListSmsNumbersCommand;
const se_ListWhatsAppNumbersCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/v1/s2s/whatsapp/numbers");
    const query = (0, smithy_client_1.map)({
        [_cI]: [, (0, smithy_client_1.expectNonNull)(input[_cI], `companyId`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_ListWhatsAppNumbersCommand = se_ListWhatsAppNumbersCommand;
const se_ListWhatsAppTemplatesCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/v1/s2s/whatsapp/templates");
    const query = (0, smithy_client_1.map)({
        [_d]: [, (0, smithy_client_1.expectNonNull)(input[_d], `did`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
exports.se_ListWhatsAppTemplatesCommand = se_ListWhatsAppTemplatesCommand;
const se_ProvisionEsimSubscriberCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/subscriber/provision");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'bundle': [],
        'companyId': [],
        'email': [],
        'extension': [],
        'firstName': [],
        'host': [],
        'lastName': [],
        'phone': [],
        'serial': [],
        'uid': [],
        'userPassword': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_ProvisionEsimSubscriberCommand = se_ProvisionEsimSubscriberCommand;
const se_RefreshEsimQrCodeCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/subscriber/qrcode/refresh");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'companyId': [],
        'uid': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_RefreshEsimQrCodeCommand = se_RefreshEsimQrCodeCommand;
const se_SendSmsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/s2s/sms");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'channelId': [],
        'company': [],
        'extension': [],
        'from': [],
        'media': _ => (0, smithy_client_1._json)(_),
        'message': [],
        'messageId': [],
        'pbx': [],
        'to': [],
        'userId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_SendSmsCommand = se_SendSmsCommand;
const se_SendSmsFromApplicationCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/a2s/sms");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'from': [],
        'message': [],
        'to': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_SendSmsFromApplicationCommand = se_SendSmsFromApplicationCommand;
const se_SendWhatsAppInteractiveMessageCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/s2s/whatsapp/interactive");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'channelId': [],
        'company': [],
        'extension': [],
        'from': [],
        'message': _ => (0, smithy_client_1._json)(_),
        'messageId': [],
        'pbx': [],
        'to': [],
        'userId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_SendWhatsAppInteractiveMessageCommand = se_SendWhatsAppInteractiveMessageCommand;
const se_SendWhatsAppMessageCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/s2s/whatsapp");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'channelId': [],
        'company': [],
        'extension': [],
        'from': [],
        'media': _ => (0, smithy_client_1._json)(_),
        'message': [],
        'messageId': [],
        'pbx': [],
        'to': [],
        'userId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_SendWhatsAppMessageCommand = se_SendWhatsAppMessageCommand;
const se_SendWhatsAppTemplateCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/s2s/whatsapp/templates");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'channelId': [],
        'company': [],
        'extension': [],
        'from': [],
        'messageId': [],
        'pbx': [],
        'template': _ => (0, smithy_client_1._json)(_),
        'to': [],
        'userId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_SendWhatsAppTemplateCommand = se_SendWhatsAppTemplateCommand;
const se_SyncEsimTransformsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/transforms/sync");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'companyId': [],
        'transforms': _ => (0, smithy_client_1._json)(_),
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_SyncEsimTransformsCommand = se_SyncEsimTransformsCommand;
const se_TerminateEsimSubscriberCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/subscriber/terminate");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'companyId': [],
        'uid': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_TerminateEsimSubscriberCommand = se_TerminateEsimSubscriberCommand;
const se_UpdateEsimSubscriberCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/subscriber/{uid}");
    b.p('uid', () => input.uid, '{uid}', false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'bundle': [],
        'companyId': [],
        'email': [],
        'extension': [],
        'firstName': [],
        'lastName': [],
        'phone': [],
        'userPassword': [],
    }));
    b.m("PATCH")
        .h(headers)
        .b(body);
    return b.build();
};
exports.se_UpdateEsimSubscriberCommand = se_UpdateEsimSubscriberCommand;
const de_CleanupTangoEsimOrderCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'orderId': smithy_client_1.expectString,
        'simsReleased': smithy_client_1.expectInt32,
        'status': smithy_client_1.expectString,
        'steps': smithy_client_1._json,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CleanupTangoEsimOrderCommand = de_CleanupTangoEsimOrderCommand;
const de_CreateNumbersOrderCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'customerOrderId': smithy_client_1.expectString,
        'message': smithy_client_1.expectString,
        'orderStatus': smithy_client_1.expectString,
        'requestId': smithy_client_1.expectString,
        'status': smithy_client_1.expectString,
        'supplierOrderId': smithy_client_1.expectString,
        'testMode': smithy_client_1.expectBoolean,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CreateNumbersOrderCommand = de_CreateNumbersOrderCommand;
const de_CreateTangoEsimOrderCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'bundle': smithy_client_1.expectString,
        'companyId': smithy_client_1.expectString,
        'countryCode': smithy_client_1.expectString,
        'orderId': smithy_client_1.expectString,
        'partnerId': smithy_client_1.expectString,
        'quantity': smithy_client_1.expectInt32,
        'requestId': smithy_client_1.expectString,
        'status': smithy_client_1.expectString,
        'totalReserved': smithy_client_1.expectInt32,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CreateTangoEsimOrderCommand = de_CreateTangoEsimOrderCommand;
const de_DeleteEsimEndpointCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'companyId': smithy_client_1.expectString,
        'serial': smithy_client_1.expectString,
        'status': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_DeleteEsimEndpointCommand = de_DeleteEsimEndpointCommand;
const de_GetEsimQrCodeCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'activationCode': smithy_client_1.expectString,
        'companyId': smithy_client_1.expectString,
        'extension': smithy_client_1.expectString,
        'iccid': smithy_client_1.expectString,
        'phone': smithy_client_1.expectString,
        'uid': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetEsimQrCodeCommand = de_GetEsimQrCodeCommand;
const de_GetEsimStatusCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'companyId': smithy_client_1.expectString,
        'esimStatus': smithy_client_1.expectString,
        'extension': smithy_client_1.expectString,
        'iccid': smithy_client_1.expectString,
        'phone': smithy_client_1.expectString,
        'subUID': smithy_client_1.expectString,
        'uid': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetEsimStatusCommand = de_GetEsimStatusCommand;
const de_GetSmsHistoryCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetSmsHistoryCommand = de_GetSmsHistoryCommand;
const de_ListEsimBundlesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'bundles': smithy_client_1._json,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListEsimBundlesCommand = de_ListEsimBundlesCommand;
const de_ListEsimSubscribersCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'companyId': smithy_client_1.expectString,
        'limit': smithy_client_1.expectInt32,
        'offset': smithy_client_1.expectInt32,
        'subscribers': smithy_client_1._json,
        'total': smithy_client_1.expectInt32,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListEsimSubscribersCommand = de_ListEsimSubscribersCommand;
const de_ListSmsNumbersCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'success': smithy_client_1.expectBoolean,
        'timestamp': smithy_client_1.expectLong,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListSmsNumbersCommand = de_ListSmsNumbersCommand;
const de_ListWhatsAppNumbersCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'result': smithy_client_1._json,
        'success': smithy_client_1.expectBoolean,
        'timestamp': smithy_client_1.expectLong,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListWhatsAppNumbersCommand = de_ListWhatsAppNumbersCommand;
const de_ListWhatsAppTemplatesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'data': smithy_client_1._json,
        'did': smithy_client_1.expectString,
        'success': smithy_client_1.expectBoolean,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListWhatsAppTemplatesCommand = de_ListWhatsAppTemplatesCommand;
const de_ProvisionEsimSubscriberCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'activationCode': smithy_client_1.expectString,
        'companyId': smithy_client_1.expectString,
        'extension': smithy_client_1.expectString,
        'iccid': smithy_client_1.expectString,
        'phone': smithy_client_1.expectString,
        'status': smithy_client_1.expectString,
        'subUID': smithy_client_1.expectString,
        'uid': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ProvisionEsimSubscriberCommand = de_ProvisionEsimSubscriberCommand;
const de_RefreshEsimQrCodeCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'activationCode': smithy_client_1.expectString,
        'companyId': smithy_client_1.expectString,
        'extension': smithy_client_1.expectString,
        'iccid': smithy_client_1.expectString,
        'phone': smithy_client_1.expectString,
        'uid': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_RefreshEsimQrCodeCommand = de_RefreshEsimQrCodeCommand;
const de_SendSmsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'company': smithy_client_1.expectString,
        'data': smithy_client_1._json,
        'id': smithy_client_1._json,
        'status': smithy_client_1.expectString,
        'success': smithy_client_1.expectBoolean,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_SendSmsCommand = de_SendSmsCommand;
const de_SendSmsFromApplicationCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'company': smithy_client_1.expectString,
        'data': smithy_client_1._json,
        'id': smithy_client_1._json,
        'status': smithy_client_1.expectString,
        'success': smithy_client_1.expectBoolean,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_SendSmsFromApplicationCommand = de_SendSmsFromApplicationCommand;
const de_SendWhatsAppInteractiveMessageCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'company': smithy_client_1.expectString,
        'data': smithy_client_1._json,
        'id': smithy_client_1._json,
        'status': smithy_client_1.expectString,
        'success': smithy_client_1.expectBoolean,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_SendWhatsAppInteractiveMessageCommand = de_SendWhatsAppInteractiveMessageCommand;
const de_SendWhatsAppMessageCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'company': smithy_client_1.expectString,
        'data': smithy_client_1._json,
        'id': smithy_client_1._json,
        'status': smithy_client_1.expectString,
        'success': smithy_client_1.expectBoolean,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_SendWhatsAppMessageCommand = de_SendWhatsAppMessageCommand;
const de_SendWhatsAppTemplateCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'company': smithy_client_1.expectString,
        'data': smithy_client_1._json,
        'id': smithy_client_1.expectString,
        'status': smithy_client_1.expectString,
        'success': smithy_client_1.expectBoolean,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_SendWhatsAppTemplateCommand = de_SendWhatsAppTemplateCommand;
const de_SyncEsimTransformsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'added': smithy_client_1.expectInt32,
        'companyId': smithy_client_1.expectString,
        'deleted': smithy_client_1.expectInt32,
        'errors': smithy_client_1._json,
        'updated': smithy_client_1.expectInt32,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_SyncEsimTransformsCommand = de_SyncEsimTransformsCommand;
const de_TerminateEsimSubscriberCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'companyId': smithy_client_1.expectString,
        'extension': smithy_client_1.expectString,
        'status': smithy_client_1.expectString,
        'subUID': smithy_client_1.expectString,
        'uid': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_TerminateEsimSubscriberCommand = de_TerminateEsimSubscriberCommand;
const de_UpdateEsimSubscriberCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'companyId': smithy_client_1.expectString,
        'status': smithy_client_1.expectString,
        'uid': smithy_client_1.expectString,
        'updatedFields': smithy_client_1._json,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_UpdateEsimSubscriberCommand = de_UpdateEsimSubscriberCommand;
const de_CommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await (0, core_1.parseJsonErrorBody)(output.body, context)
    };
    const errorCode = (0, core_1.loadRestJsonErrorCode)(output, parsedOutput.body);
    switch (errorCode) {
        case "GatewayTimeoutException":
        case "wildix.classound#GatewayTimeoutException":
            throw await de_GatewayTimeoutExceptionRes(parsedOutput, context);
        case "InternalError":
        case "wildix.classound#InternalError":
            throw await de_InternalErrorRes(parsedOutput, context);
        case "InternalServerException":
        case "wildix.classound#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "NotFoundError":
        case "wildix.classound#NotFoundError":
            throw await de_NotFoundErrorRes(parsedOutput, context);
        case "OrderError":
        case "wildix.classound#OrderError":
            throw await de_OrderErrorRes(parsedOutput, context);
        case "RequestValidationException":
        case "wildix.classound#RequestValidationException":
            throw await de_RequestValidationExceptionRes(parsedOutput, context);
        case "TangoEsimOrderError":
        case "wildix.classound#TangoEsimOrderError":
            throw await de_TangoEsimOrderErrorRes(parsedOutput, context);
        case "UserNotFoundException":
        case "wildix.classound#UserNotFoundException":
            throw await de_UserNotFoundExceptionRes(parsedOutput, context);
        case "ValidationError":
        case "wildix.classound#ValidationError":
            throw await de_ValidationErrorRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const throwDefaultError = (0, smithy_client_1.withBaseException)(ClassoundServiceException_1.ClassoundServiceException);
const de_GatewayTimeoutExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'description': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.GatewayTimeoutException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_InternalErrorRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'description': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.InternalError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_InternalServerExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'description': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.InternalServerException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_NotFoundErrorRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'description': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.NotFoundError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_OrderErrorRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'customerOrderId': smithy_client_1.expectString,
        'description': smithy_client_1.expectString,
        'errorCode': smithy_client_1.expectString,
        'requestId': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.OrderError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_RequestValidationExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'description': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.RequestValidationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_TangoEsimOrderErrorRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'errorCode': smithy_client_1.expectString,
        'message': smithy_client_1.expectString,
        'requestId': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.TangoEsimOrderError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_UserNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'description': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.UserNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ValidationErrorRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'description': smithy_client_1.expectString,
        'type': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.ValidationError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBodyString = (streamBody, context) => (0, smithy_client_1.collectBody)(streamBody, context).then(body => context.utf8Encoder(body));
const _cI = "companyId";
const _d = "did";
const _f = "from";
const _l = "limit";
const _o = "offset";
const _s = "serial";
const _t = "to";
const _u = "uid";
