"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Classound = void 0;
const ClassoundClient_1 = require("./ClassoundClient");
const CleanupTangoEsimOrderCommand_1 = require("./commands/CleanupTangoEsimOrderCommand");
const CreateNumbersOrderCommand_1 = require("./commands/CreateNumbersOrderCommand");
const CreateTangoEsimOrderCommand_1 = require("./commands/CreateTangoEsimOrderCommand");
const DeleteEsimEndpointCommand_1 = require("./commands/DeleteEsimEndpointCommand");
const GetEsimQrCodeCommand_1 = require("./commands/GetEsimQrCodeCommand");
const GetEsimStatusCommand_1 = require("./commands/GetEsimStatusCommand");
const GetSmsHistoryCommand_1 = require("./commands/GetSmsHistoryCommand");
const ListEsimBundlesCommand_1 = require("./commands/ListEsimBundlesCommand");
const ListEsimSubscribersCommand_1 = require("./commands/ListEsimSubscribersCommand");
const ListSmsNumbersCommand_1 = require("./commands/ListSmsNumbersCommand");
const ListWhatsAppNumbersCommand_1 = require("./commands/ListWhatsAppNumbersCommand");
const ListWhatsAppTemplatesCommand_1 = require("./commands/ListWhatsAppTemplatesCommand");
const ProvisionEsimSubscriberCommand_1 = require("./commands/ProvisionEsimSubscriberCommand");
const RefreshEsimQrCodeCommand_1 = require("./commands/RefreshEsimQrCodeCommand");
const SendSmsCommand_1 = require("./commands/SendSmsCommand");
const SendSmsFromApplicationCommand_1 = require("./commands/SendSmsFromApplicationCommand");
const SendWhatsAppInteractiveMessageCommand_1 = require("./commands/SendWhatsAppInteractiveMessageCommand");
const SendWhatsAppMessageCommand_1 = require("./commands/SendWhatsAppMessageCommand");
const SendWhatsAppTemplateCommand_1 = require("./commands/SendWhatsAppTemplateCommand");
const SyncEsimTransformsCommand_1 = require("./commands/SyncEsimTransformsCommand");
const TerminateEsimSubscriberCommand_1 = require("./commands/TerminateEsimSubscriberCommand");
const UpdateEsimSubscriberCommand_1 = require("./commands/UpdateEsimSubscriberCommand");
const smithy_client_1 = require("@smithy/smithy-client");
const commands = {
    CleanupTangoEsimOrderCommand: CleanupTangoEsimOrderCommand_1.CleanupTangoEsimOrderCommand,
    CreateNumbersOrderCommand: CreateNumbersOrderCommand_1.CreateNumbersOrderCommand,
    CreateTangoEsimOrderCommand: CreateTangoEsimOrderCommand_1.CreateTangoEsimOrderCommand,
    DeleteEsimEndpointCommand: DeleteEsimEndpointCommand_1.DeleteEsimEndpointCommand,
    GetEsimQrCodeCommand: GetEsimQrCodeCommand_1.GetEsimQrCodeCommand,
    GetEsimStatusCommand: GetEsimStatusCommand_1.GetEsimStatusCommand,
    GetSmsHistoryCommand: GetSmsHistoryCommand_1.GetSmsHistoryCommand,
    ListEsimBundlesCommand: ListEsimBundlesCommand_1.ListEsimBundlesCommand,
    ListEsimSubscribersCommand: ListEsimSubscribersCommand_1.ListEsimSubscribersCommand,
    ListSmsNumbersCommand: ListSmsNumbersCommand_1.ListSmsNumbersCommand,
    ListWhatsAppNumbersCommand: ListWhatsAppNumbersCommand_1.ListWhatsAppNumbersCommand,
    ListWhatsAppTemplatesCommand: ListWhatsAppTemplatesCommand_1.ListWhatsAppTemplatesCommand,
    ProvisionEsimSubscriberCommand: ProvisionEsimSubscriberCommand_1.ProvisionEsimSubscriberCommand,
    RefreshEsimQrCodeCommand: RefreshEsimQrCodeCommand_1.RefreshEsimQrCodeCommand,
    SendSmsCommand: SendSmsCommand_1.SendSmsCommand,
    SendSmsFromApplicationCommand: SendSmsFromApplicationCommand_1.SendSmsFromApplicationCommand,
    SendWhatsAppInteractiveMessageCommand: SendWhatsAppInteractiveMessageCommand_1.SendWhatsAppInteractiveMessageCommand,
    SendWhatsAppMessageCommand: SendWhatsAppMessageCommand_1.SendWhatsAppMessageCommand,
    SendWhatsAppTemplateCommand: SendWhatsAppTemplateCommand_1.SendWhatsAppTemplateCommand,
    SyncEsimTransformsCommand: SyncEsimTransformsCommand_1.SyncEsimTransformsCommand,
    TerminateEsimSubscriberCommand: TerminateEsimSubscriberCommand_1.TerminateEsimSubscriberCommand,
    UpdateEsimSubscriberCommand: UpdateEsimSubscriberCommand_1.UpdateEsimSubscriberCommand,
};
class Classound extends ClassoundClient_1.ClassoundClient {
}
exports.Classound = Classound;
(0, smithy_client_1.createAggregatedClient)(commands, Classound);
