"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TangoUpdateStatus = exports.TangoTerminateStatus = exports.InteractiveContentType = exports.HeaderType = exports.InteractiveButtonType = exports.TangoProvisionStatus = exports.TemplateStatus = exports.ParameterFormat = exports.ComponentType = exports.ComponentFormat = exports.TemplateCategory = exports.TangoOrderStatus = exports.TangoBundleSku = exports.ValidationError = exports.UserNotFoundException = exports.TangoEsimOrderError = exports.RequestValidationException = exports.OrderError = exports.NotFoundError = exports.InternalServerException = exports.InternalError = exports.GatewayTimeoutException = exports.TangoCleanupStatus = exports.ButtonType = void 0;
const ClassoundServiceException_1 = require("./ClassoundServiceException");
exports.ButtonType = {
    APP: "APP",
    CATALOG: "CATALOG",
    FLOW: "FLOW",
    MPM: "MPM",
    OTP: "OTP",
    PHONE_NUMBER: "PHONE_NUMBER",
    QUICK_REPLY: "QUICK_REPLY",
    URL: "URL",
    VOICE_CALL: "VOICE_CALL",
};
exports.TangoCleanupStatus = {
    CLEANED: "CLEANED",
};
class GatewayTimeoutException extends ClassoundServiceException_1.ClassoundServiceException {
    name = "GatewayTimeoutException";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "GatewayTimeoutException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, GatewayTimeoutException.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
exports.GatewayTimeoutException = GatewayTimeoutException;
class InternalError extends ClassoundServiceException_1.ClassoundServiceException {
    name = "InternalError";
    $fault = "server";
    type;
    description;
    constructor(opts) {
        super({
            name: "InternalError",
            $fault: "server",
            ...opts
        });
        Object.setPrototypeOf(this, InternalError.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
exports.InternalError = InternalError;
class InternalServerException extends ClassoundServiceException_1.ClassoundServiceException {
    name = "InternalServerException";
    $fault = "server";
    type;
    description;
    constructor(opts) {
        super({
            name: "InternalServerException",
            $fault: "server",
            ...opts
        });
        Object.setPrototypeOf(this, InternalServerException.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
exports.InternalServerException = InternalServerException;
class NotFoundError extends ClassoundServiceException_1.ClassoundServiceException {
    name = "NotFoundError";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "NotFoundError",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, NotFoundError.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
exports.NotFoundError = NotFoundError;
class OrderError extends ClassoundServiceException_1.ClassoundServiceException {
    name = "OrderError";
    $fault = "client";
    type;
    description;
    requestId;
    customerOrderId;
    errorCode;
    constructor(opts) {
        super({
            name: "OrderError",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, OrderError.prototype);
        this.type = opts.type;
        this.description = opts.description;
        this.requestId = opts.requestId;
        this.customerOrderId = opts.customerOrderId;
        this.errorCode = opts.errorCode;
    }
}
exports.OrderError = OrderError;
class RequestValidationException extends ClassoundServiceException_1.ClassoundServiceException {
    name = "RequestValidationException";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "RequestValidationException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, RequestValidationException.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
exports.RequestValidationException = RequestValidationException;
class TangoEsimOrderError extends ClassoundServiceException_1.ClassoundServiceException {
    name = "TangoEsimOrderError";
    $fault = "client";
    requestId;
    errorCode;
    constructor(opts) {
        super({
            name: "TangoEsimOrderError",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, TangoEsimOrderError.prototype);
        this.requestId = opts.requestId;
        this.errorCode = opts.errorCode;
    }
}
exports.TangoEsimOrderError = TangoEsimOrderError;
class UserNotFoundException extends ClassoundServiceException_1.ClassoundServiceException {
    name = "UserNotFoundException";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "UserNotFoundException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, UserNotFoundException.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
exports.UserNotFoundException = UserNotFoundException;
class ValidationError extends ClassoundServiceException_1.ClassoundServiceException {
    name = "ValidationError";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "ValidationError",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, ValidationError.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
exports.ValidationError = ValidationError;
exports.TangoBundleSku = {
    PLAN_VC_MSG_10G: "PLAN-VC-MSG-10G",
    PLAN_VC_MSG_20G: "PLAN-VC-MSG-20G",
    PLAN_VC_MSG_2G: "PLAN-VC-MSG-2G",
    PLAN_VC_MSG_4G: "PLAN-VC-MSG-4G",
    PLAN_VC_MSG_BKGND: "PLAN-VC-MSG-BKGND",
    PLAN_VC_MSG_UNLTD: "PLAN-VC-MSG-UNLTD",
};
exports.TangoOrderStatus = {
    SUCCESS: "SUCCESS",
};
exports.TemplateCategory = {
    AUTHENTICATION: "AUTHENTICATION",
    MARKETING: "MARKETING",
    UTILITY: "UTILITY",
};
exports.ComponentFormat = {
    IMAGE: "IMAGE",
    TEXT: "TEXT",
};
exports.ComponentType = {
    BODY: "BODY",
    BUTTONS: "BUTTONS",
    FOOTER: "FOOTER",
    HEADER: "HEADER",
};
exports.ParameterFormat = {
    NAMED: "NAMED",
};
exports.TemplateStatus = {
    APPROVED: "APPROVED",
    PAUSED: "PAUSED",
    REJECTED: "REJECTED",
};
exports.TangoProvisionStatus = {
    ALREADY_PROVISIONED: "ALREADY_PROVISIONED",
    PROVISIONED: "PROVISIONED",
};
exports.InteractiveButtonType = {
    REPLY: "reply",
};
exports.HeaderType = {
    IMAGE: "image",
    TEXT: "text",
};
exports.InteractiveContentType = {
    BUTTON: "button",
    LIST: "list",
};
exports.TangoTerminateStatus = {
    TERMINATED: "TERMINATED",
};
exports.TangoUpdateStatus = {
    UPDATED: "UPDATED",
};
