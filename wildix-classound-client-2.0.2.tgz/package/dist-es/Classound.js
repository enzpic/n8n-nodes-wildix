import { ClassoundClient, } from "./ClassoundClient";
import { CleanupTangoEsimOrderCommand, } from "./commands/CleanupTangoEsimOrderCommand";
import { CreateNumbersOrderCommand, } from "./commands/CreateNumbersOrderCommand";
import { CreateTangoEsimOrderCommand, } from "./commands/CreateTangoEsimOrderCommand";
import { DeleteEsimEndpointCommand, } from "./commands/DeleteEsimEndpointCommand";
import { GetEsimQrCodeCommand, } from "./commands/GetEsimQrCodeCommand";
import { GetEsimStatusCommand, } from "./commands/GetEsimStatusCommand";
import { GetSmsHistoryCommand, } from "./commands/GetSmsHistoryCommand";
import { ListEsimBundlesCommand, } from "./commands/ListEsimBundlesCommand";
import { ListEsimSubscribersCommand, } from "./commands/ListEsimSubscribersCommand";
import { ListSmsNumbersCommand, } from "./commands/ListSmsNumbersCommand";
import { ListWhatsAppNumbersCommand, } from "./commands/ListWhatsAppNumbersCommand";
import { ListWhatsAppTemplatesCommand, } from "./commands/ListWhatsAppTemplatesCommand";
import { ProvisionEsimSubscriberCommand, } from "./commands/ProvisionEsimSubscriberCommand";
import { RefreshEsimQrCodeCommand, } from "./commands/RefreshEsimQrCodeCommand";
import { SendSmsCommand, } from "./commands/SendSmsCommand";
import { SendSmsFromApplicationCommand, } from "./commands/SendSmsFromApplicationCommand";
import { SendWhatsAppInteractiveMessageCommand, } from "./commands/SendWhatsAppInteractiveMessageCommand";
import { SendWhatsAppMessageCommand, } from "./commands/SendWhatsAppMessageCommand";
import { SendWhatsAppTemplateCommand, } from "./commands/SendWhatsAppTemplateCommand";
import { SyncEsimTransformsCommand, } from "./commands/SyncEsimTransformsCommand";
import { TerminateEsimSubscriberCommand, } from "./commands/TerminateEsimSubscriberCommand";
import { UpdateEsimSubscriberCommand, } from "./commands/UpdateEsimSubscriberCommand";
import { createAggregatedClient } from "@smithy/smithy-client";
const commands = {
    CleanupTangoEsimOrderCommand,
    CreateNumbersOrderCommand,
    CreateTangoEsimOrderCommand,
    DeleteEsimEndpointCommand,
    GetEsimQrCodeCommand,
    GetEsimStatusCommand,
    GetSmsHistoryCommand,
    ListEsimBundlesCommand,
    ListEsimSubscribersCommand,
    ListSmsNumbersCommand,
    ListWhatsAppNumbersCommand,
    ListWhatsAppTemplatesCommand,
    ProvisionEsimSubscriberCommand,
    RefreshEsimQrCodeCommand,
    SendSmsCommand,
    SendSmsFromApplicationCommand,
    SendWhatsAppInteractiveMessageCommand,
    SendWhatsAppMessageCommand,
    SendWhatsAppTemplateCommand,
    SyncEsimTransformsCommand,
    TerminateEsimSubscriberCommand,
    UpdateEsimSubscriberCommand,
};
export class Classound extends ClassoundClient {
}
createAggregatedClient(commands, Classound);
