import { getRuntimeConfig as __getRuntimeConfig } from "./runtimeConfig";
import { resolveRuntimeExtensions, } from "./runtimeExtensions";
import { getUserAgentPlugin, resolveUserAgentConfig, } from "@aws-sdk/middleware-user-agent";
import { getContentLengthPlugin } from "@smithy/middleware-content-length";
import { getRetryPlugin, resolveRetryConfig, } from "@smithy/middleware-retry";
import { Client as __Client, } from "@smithy/smithy-client";
import { authorizationMiddleware } from '@wildix/smithy-utils';
export { __Client };
export class ClassoundClient extends __Client {
    config;
    constructor(...[configuration]) {
        let _config_0 = __getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        let _config_1 = resolveUserAgentConfig(_config_0);
        let _config_2 = resolveRetryConfig(_config_1);
        let _config_3 = resolveRuntimeExtensions(_config_2, configuration?.extensions || []);
        const hostname = ['stable', 'stage'].includes(configuration.env || '') ? `classound-p2p-${configuration.env}.wildix.com` : 'classound-p2p.wildix.com';
        const endpoint = () => {
            return {
                hostname,
                protocol: "https",
                port: '443',
                path: ''
            };
        };
        const config = { ..._config_3, endpoint };
        this.config = config;
        this.middlewareStack.add(authorizationMiddleware.bind(this, configuration.token), { step: "build" });
        this.middlewareStack.use(getUserAgentPlugin(this.config));
        this.middlewareStack.use(getRetryPlugin(this.config));
        this.middlewareStack.use(getContentLengthPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}
