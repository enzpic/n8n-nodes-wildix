import { de_SendWhatsAppInteractiveMessageCommand, se_SendWhatsAppInteractiveMessageCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class SendWhatsAppInteractiveMessageCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "SendWhatsAppInteractiveMessage", {})
    .n("ClassoundClient", "SendWhatsAppInteractiveMessageCommand")
    .f(void 0, void 0)
    .ser(se_SendWhatsAppInteractiveMessageCommand)
    .de(de_SendWhatsAppInteractiveMessageCommand)
    .build() {
}
