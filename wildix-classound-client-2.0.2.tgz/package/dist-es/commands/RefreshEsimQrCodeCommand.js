import { de_RefreshEsimQrCodeCommand, se_RefreshEsimQrCodeCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class RefreshEsimQrCodeCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "RefreshEsimQrCode", {})
    .n("ClassoundClient", "RefreshEsimQrCodeCommand")
    .f(void 0, void 0)
    .ser(se_RefreshEsimQrCodeCommand)
    .de(de_RefreshEsimQrCodeCommand)
    .build() {
}
