import { de_UpdateEsimSubscriberCommand, se_UpdateEsimSubscriberCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class UpdateEsimSubscriberCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "UpdateEsimSubscriber", {})
    .n("ClassoundClient", "UpdateEsimSubscriberCommand")
    .f(void 0, void 0)
    .ser(se_UpdateEsimSubscriberCommand)
    .de(de_UpdateEsimSubscriberCommand)
    .build() {
}
