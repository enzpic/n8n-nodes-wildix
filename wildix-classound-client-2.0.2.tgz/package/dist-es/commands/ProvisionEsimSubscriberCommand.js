import { de_ProvisionEsimSubscriberCommand, se_ProvisionEsimSubscriberCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class ProvisionEsimSubscriberCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "ProvisionEsimSubscriber", {})
    .n("ClassoundClient", "ProvisionEsimSubscriberCommand")
    .f(void 0, void 0)
    .ser(se_ProvisionEsimSubscriberCommand)
    .de(de_ProvisionEsimSubscriberCommand)
    .build() {
}
