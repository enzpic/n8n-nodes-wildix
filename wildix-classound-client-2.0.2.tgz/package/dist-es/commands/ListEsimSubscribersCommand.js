import { de_ListEsimSubscribersCommand, se_ListEsimSubscribersCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class ListEsimSubscribersCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "ListEsimSubscribers", {})
    .n("ClassoundClient", "ListEsimSubscribersCommand")
    .f(void 0, void 0)
    .ser(se_ListEsimSubscribersCommand)
    .de(de_ListEsimSubscribersCommand)
    .build() {
}
