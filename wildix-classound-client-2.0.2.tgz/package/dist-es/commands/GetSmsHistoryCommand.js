import { de_GetSmsHistoryCommand, se_GetSmsHistoryCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetSmsHistoryCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "GetSmsHistory", {})
    .n("ClassoundClient", "GetSmsHistoryCommand")
    .f(void 0, void 0)
    .ser(se_GetSmsHistoryCommand)
    .de(de_GetSmsHistoryCommand)
    .build() {
}
