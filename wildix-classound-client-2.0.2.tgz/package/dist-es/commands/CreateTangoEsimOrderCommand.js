import { de_CreateTangoEsimOrderCommand, se_CreateTangoEsimOrderCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CreateTangoEsimOrderCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "CreateTangoEsimOrder", {})
    .n("ClassoundClient", "CreateTangoEsimOrderCommand")
    .f(void 0, void 0)
    .ser(se_CreateTangoEsimOrderCommand)
    .de(de_CreateTangoEsimOrderCommand)
    .build() {
}
