import { de_TerminateEsimSubscriberCommand, se_TerminateEsimSubscriberCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class TerminateEsimSubscriberCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "TerminateEsimSubscriber", {})
    .n("ClassoundClient", "TerminateEsimSubscriberCommand")
    .f(void 0, void 0)
    .ser(se_TerminateEsimSubscriberCommand)
    .de(de_TerminateEsimSubscriberCommand)
    .build() {
}
