import { de_CleanupTangoEsimOrderCommand, se_CleanupTangoEsimOrderCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CleanupTangoEsimOrderCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "CleanupTangoEsimOrder", {})
    .n("ClassoundClient", "CleanupTangoEsimOrderCommand")
    .f(void 0, void 0)
    .ser(se_CleanupTangoEsimOrderCommand)
    .de(de_CleanupTangoEsimOrderCommand)
    .build() {
}
