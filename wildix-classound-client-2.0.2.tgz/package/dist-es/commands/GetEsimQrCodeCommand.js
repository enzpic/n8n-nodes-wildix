import { de_GetEsimQrCodeCommand, se_GetEsimQrCodeCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetEsimQrCodeCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "GetEsimQrCode", {})
    .n("ClassoundClient", "GetEsimQrCodeCommand")
    .f(void 0, void 0)
    .ser(se_GetEsimQrCodeCommand)
    .de(de_GetEsimQrCodeCommand)
    .build() {
}
