import { de_SendWhatsAppMessageCommand, se_SendWhatsAppMessageCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class SendWhatsAppMessageCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "SendWhatsAppMessage", {})
    .n("ClassoundClient", "SendWhatsAppMessageCommand")
    .f(void 0, void 0)
    .ser(se_SendWhatsAppMessageCommand)
    .de(de_SendWhatsAppMessageCommand)
    .build() {
}
