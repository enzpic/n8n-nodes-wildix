import { de_ListWhatsAppTemplatesCommand, se_ListWhatsAppTemplatesCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class ListWhatsAppTemplatesCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "ListWhatsAppTemplates", {})
    .n("ClassoundClient", "ListWhatsAppTemplatesCommand")
    .f(void 0, void 0)
    .ser(se_ListWhatsAppTemplatesCommand)
    .de(de_ListWhatsAppTemplatesCommand)
    .build() {
}
