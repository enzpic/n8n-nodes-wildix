import { de_SendSmsCommand, se_SendSmsCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class SendSmsCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "SendSms", {})
    .n("ClassoundClient", "SendSmsCommand")
    .f(void 0, void 0)
    .ser(se_SendSmsCommand)
    .de(de_SendSmsCommand)
    .build() {
}
