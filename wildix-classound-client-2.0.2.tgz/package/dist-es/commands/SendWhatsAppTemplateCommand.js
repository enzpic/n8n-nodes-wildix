import { de_SendWhatsAppTemplateCommand, se_SendWhatsAppTemplateCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class SendWhatsAppTemplateCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "SendWhatsAppTemplate", {})
    .n("ClassoundClient", "SendWhatsAppTemplateCommand")
    .f(void 0, void 0)
    .ser(se_SendWhatsAppTemplateCommand)
    .de(de_SendWhatsAppTemplateCommand)
    .build() {
}
