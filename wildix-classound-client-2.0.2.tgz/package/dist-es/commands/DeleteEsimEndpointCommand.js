import { de_DeleteEsimEndpointCommand, se_DeleteEsimEndpointCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class DeleteEsimEndpointCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "DeleteEsimEndpoint", {})
    .n("ClassoundClient", "DeleteEsimEndpointCommand")
    .f(void 0, void 0)
    .ser(se_DeleteEsimEndpointCommand)
    .de(de_DeleteEsimEndpointCommand)
    .build() {
}
