import { de_CreateNumbersOrderCommand, se_CreateNumbersOrderCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class CreateNumbersOrderCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "CreateNumbersOrder", {})
    .n("ClassoundClient", "CreateNumbersOrderCommand")
    .f(void 0, void 0)
    .ser(se_CreateNumbersOrderCommand)
    .de(de_CreateNumbersOrderCommand)
    .build() {
}
