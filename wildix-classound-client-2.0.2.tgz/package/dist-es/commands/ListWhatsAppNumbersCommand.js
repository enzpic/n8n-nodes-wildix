import { de_ListWhatsAppNumbersCommand, se_ListWhatsAppNumbersCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class ListWhatsAppNumbersCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "ListWhatsAppNumbers", {})
    .n("ClassoundClient", "ListWhatsAppNumbersCommand")
    .f(void 0, void 0)
    .ser(se_ListWhatsAppNumbersCommand)
    .de(de_ListWhatsAppNumbersCommand)
    .build() {
}
