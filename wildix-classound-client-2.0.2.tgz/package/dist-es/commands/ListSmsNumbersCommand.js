import { de_ListSmsNumbersCommand, se_ListSmsNumbersCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class ListSmsNumbersCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "ListSmsNumbers", {})
    .n("ClassoundClient", "ListSmsNumbersCommand")
    .f(void 0, void 0)
    .ser(se_ListSmsNumbersCommand)
    .de(de_ListSmsNumbersCommand)
    .build() {
}
