import { de_GetEsimStatusCommand, se_GetEsimStatusCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class GetEsimStatusCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "GetEsimStatus", {})
    .n("ClassoundClient", "GetEsimStatusCommand")
    .f(void 0, void 0)
    .ser(se_GetEsimStatusCommand)
    .de(de_GetEsimStatusCommand)
    .build() {
}
