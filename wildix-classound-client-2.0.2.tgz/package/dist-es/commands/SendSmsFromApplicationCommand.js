import { de_SendSmsFromApplicationCommand, se_SendSmsFromApplicationCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
export { $Command };
export class SendSmsFromApplicationCommand extends $Command.classBuilder()
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
    ];
})
    .s("Classound", "SendSmsFromApplication", {})
    .n("ClassoundClient", "SendSmsFromApplicationCommand")
    .f(void 0, void 0)
    .ser(se_SendSmsFromApplicationCommand)
    .de(de_SendSmsFromApplicationCommand)
    .build() {
}
