import { ClassoundServiceException as __BaseException } from "./ClassoundServiceException";
export const ButtonType = {
    APP: "APP",
    CATALOG: "CATALOG",
    FLOW: "FLOW",
    MPM: "MPM",
    OTP: "OTP",
    PHONE_NUMBER: "PHONE_NUMBER",
    QUICK_REPLY: "QUICK_REPLY",
    URL: "URL",
    VOICE_CALL: "VOICE_CALL",
};
export const TangoCleanupStatus = {
    CLEANED: "CLEANED",
};
export class GatewayTimeoutException extends __BaseException {
    name = "GatewayTimeoutException";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "GatewayTimeoutException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, GatewayTimeoutException.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
export class InternalError extends __BaseException {
    name = "InternalError";
    $fault = "server";
    type;
    description;
    constructor(opts) {
        super({
            name: "InternalError",
            $fault: "server",
            ...opts
        });
        Object.setPrototypeOf(this, InternalError.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
export class InternalServerException extends __BaseException {
    name = "InternalServerException";
    $fault = "server";
    type;
    description;
    constructor(opts) {
        super({
            name: "InternalServerException",
            $fault: "server",
            ...opts
        });
        Object.setPrototypeOf(this, InternalServerException.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
export class NotFoundError extends __BaseException {
    name = "NotFoundError";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "NotFoundError",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, NotFoundError.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
export class OrderError extends __BaseException {
    name = "OrderError";
    $fault = "client";
    type;
    description;
    requestId;
    customerOrderId;
    errorCode;
    constructor(opts) {
        super({
            name: "OrderError",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, OrderError.prototype);
        this.type = opts.type;
        this.description = opts.description;
        this.requestId = opts.requestId;
        this.customerOrderId = opts.customerOrderId;
        this.errorCode = opts.errorCode;
    }
}
export class RequestValidationException extends __BaseException {
    name = "RequestValidationException";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "RequestValidationException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, RequestValidationException.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
export class TangoEsimOrderError extends __BaseException {
    name = "TangoEsimOrderError";
    $fault = "client";
    requestId;
    errorCode;
    constructor(opts) {
        super({
            name: "TangoEsimOrderError",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, TangoEsimOrderError.prototype);
        this.requestId = opts.requestId;
        this.errorCode = opts.errorCode;
    }
}
export class UserNotFoundException extends __BaseException {
    name = "UserNotFoundException";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "UserNotFoundException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, UserNotFoundException.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
export class ValidationError extends __BaseException {
    name = "ValidationError";
    $fault = "client";
    type;
    description;
    constructor(opts) {
        super({
            name: "ValidationError",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, ValidationError.prototype);
        this.type = opts.type;
        this.description = opts.description;
    }
}
export const TangoBundleSku = {
    PLAN_VC_MSG_10G: "PLAN-VC-MSG-10G",
    PLAN_VC_MSG_20G: "PLAN-VC-MSG-20G",
    PLAN_VC_MSG_2G: "PLAN-VC-MSG-2G",
    PLAN_VC_MSG_4G: "PLAN-VC-MSG-4G",
    PLAN_VC_MSG_BKGND: "PLAN-VC-MSG-BKGND",
    PLAN_VC_MSG_UNLTD: "PLAN-VC-MSG-UNLTD",
};
export const TangoOrderStatus = {
    SUCCESS: "SUCCESS",
};
export const TemplateCategory = {
    AUTHENTICATION: "AUTHENTICATION",
    MARKETING: "MARKETING",
    UTILITY: "UTILITY",
};
export const ComponentFormat = {
    IMAGE: "IMAGE",
    TEXT: "TEXT",
};
export const ComponentType = {
    BODY: "BODY",
    BUTTONS: "BUTTONS",
    FOOTER: "FOOTER",
    HEADER: "HEADER",
};
export const ParameterFormat = {
    NAMED: "NAMED",
};
export const TemplateStatus = {
    APPROVED: "APPROVED",
    PAUSED: "PAUSED",
    REJECTED: "REJECTED",
};
export const TangoProvisionStatus = {
    ALREADY_PROVISIONED: "ALREADY_PROVISIONED",
    PROVISIONED: "PROVISIONED",
};
export const InteractiveButtonType = {
    REPLY: "reply",
};
export const HeaderType = {
    IMAGE: "image",
    TEXT: "text",
};
export const InteractiveContentType = {
    BUTTON: "button",
    LIST: "list",
};
export const TangoTerminateStatus = {
    TERMINATED: "TERMINATED",
};
export const TangoUpdateStatus = {
    UPDATED: "UPDATED",
};
