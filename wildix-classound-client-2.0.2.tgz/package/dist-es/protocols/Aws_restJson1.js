import { ClassoundServiceException as __BaseException } from "../models/ClassoundServiceException";
import { GatewayTimeoutException, InternalError, InternalServerException, NotFoundError, OrderError, RequestValidationException, TangoEsimOrderError, UserNotFoundException, ValidationError, } from "../models/models_0";
import { loadRestJsonErrorCode, parseJsonBody as parseBody, parseJsonErrorBody as parseErrorBody, } from "@aws-sdk/core";
import { requestBuilder as rb } from "@smithy/core";
import { decorateServiceException as __decorateServiceException, expectBoolean as __expectBoolean, expectInt32 as __expectInt32, expectLong as __expectLong, expectNonNull as __expectNonNull, expectObject as __expectObject, expectString as __expectString, _json, collectBody, map, take, withBaseException, } from "@smithy/smithy-client";
export const se_CleanupTangoEsimOrderCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/order/cleanup");
    let body;
    body = JSON.stringify(take(input, {
        'orderId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_CreateNumbersOrderCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/numbers/ordering/order");
    let body;
    body = JSON.stringify(take(input, {
        'companyId': [],
        'customerOrderId': [],
        'data': _ => _json(_),
        'requestId': [],
        'webhookToken': [],
        'webhookUrl': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_CreateTangoEsimOrderCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/order");
    let body;
    body = JSON.stringify(take(input, {
        'bundle': [],
        'companyId': [],
        'companyName': [],
        'countryCode': [],
        'homeLocations': _ => _json(_),
        'partnerAddress': [],
        'partnerAddress2': [],
        'partnerContactNumber': [],
        'partnerCounty': [],
        'partnerDescription': [],
        'partnerEmail': [],
        'partnerId': [],
        'partnerName': [],
        'partnerPostCode': [],
        'partnerTown': [],
        'quantity': [],
        'requestId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_DeleteEsimEndpointCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/esim/endpoint");
    const query = map({
        [_cI]: [, input[_cI]],
        [_s]: [, __expectNonNull(input[_s], `serial`)],
    });
    let body;
    b.m("DELETE")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_GetEsimQrCodeCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/esim/subscriber/qrcode");
    const query = map({
        [_cI]: [, input[_cI]],
        [_u]: [, __expectNonNull(input[_u], `uid`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_GetEsimStatusCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/esim/status");
    const query = map({
        [_cI]: [, input[_cI]],
        [_u]: [, __expectNonNull(input[_u], `uid`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_GetSmsHistoryCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/s2s/sms/history");
    const query = map({
        [_f]: [, input[_f]],
        [_t]: [, input[_t]],
        [_cI]: [, input[_cI]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_ListEsimBundlesCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/esim/bundles");
    const query = map({
        [_cI]: [, input[_cI]],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_ListEsimSubscribersCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/esim/subscribers");
    const query = map({
        [_cI]: [, input[_cI]],
        [_l]: [() => input.limit !== void 0, () => (input[_l].toString())],
        [_o]: [() => input.offset !== void 0, () => (input[_o].toString())],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_ListSmsNumbersCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/s2s/sms/numbers");
    const query = map({
        [_cI]: [, __expectNonNull(input[_cI], `companyId`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_ListWhatsAppNumbersCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/s2s/whatsapp/numbers");
    const query = map({
        [_cI]: [, __expectNonNull(input[_cI], `companyId`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_ListWhatsAppTemplatesCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/s2s/whatsapp/templates");
    const query = map({
        [_d]: [, __expectNonNull(input[_d], `did`)],
    });
    let body;
    b.m("GET")
        .h(headers)
        .q(query)
        .b(body);
    return b.build();
};
export const se_ProvisionEsimSubscriberCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/subscriber/provision");
    let body;
    body = JSON.stringify(take(input, {
        'bundle': [],
        'companyId': [],
        'email': [],
        'extension': [],
        'firstName': [],
        'host': [],
        'lastName': [],
        'phone': [],
        'serial': [],
        'uid': [],
        'userPassword': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_RefreshEsimQrCodeCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/subscriber/qrcode/refresh");
    let body;
    body = JSON.stringify(take(input, {
        'companyId': [],
        'uid': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_SendSmsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/s2s/sms");
    let body;
    body = JSON.stringify(take(input, {
        'channelId': [],
        'company': [],
        'extension': [],
        'from': [],
        'media': _ => _json(_),
        'message': [],
        'messageId': [],
        'pbx': [],
        'to': [],
        'userId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_SendSmsFromApplicationCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/a2s/sms");
    let body;
    body = JSON.stringify(take(input, {
        'from': [],
        'message': [],
        'to': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_SendWhatsAppInteractiveMessageCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/s2s/whatsapp/interactive");
    let body;
    body = JSON.stringify(take(input, {
        'channelId': [],
        'company': [],
        'extension': [],
        'from': [],
        'message': _ => _json(_),
        'messageId': [],
        'pbx': [],
        'to': [],
        'userId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_SendWhatsAppMessageCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/s2s/whatsapp");
    let body;
    body = JSON.stringify(take(input, {
        'channelId': [],
        'company': [],
        'extension': [],
        'from': [],
        'media': _ => _json(_),
        'message': [],
        'messageId': [],
        'pbx': [],
        'to': [],
        'userId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_SendWhatsAppTemplateCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/s2s/whatsapp/templates");
    let body;
    body = JSON.stringify(take(input, {
        'channelId': [],
        'company': [],
        'extension': [],
        'from': [],
        'messageId': [],
        'pbx': [],
        'template': _ => _json(_),
        'to': [],
        'userId': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_SyncEsimTransformsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/transforms/sync");
    let body;
    body = JSON.stringify(take(input, {
        'companyId': [],
        'transforms': _ => _json(_),
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_TerminateEsimSubscriberCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/subscriber/terminate");
    let body;
    body = JSON.stringify(take(input, {
        'companyId': [],
        'uid': [],
    }));
    b.m("POST")
        .h(headers)
        .b(body);
    return b.build();
};
export const se_UpdateEsimSubscriberCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        'content-type': 'application/json',
    };
    b.bp("/v1/esim/subscriber/{uid}");
    b.p('uid', () => input.uid, '{uid}', false);
    let body;
    body = JSON.stringify(take(input, {
        'bundle': [],
        'companyId': [],
        'email': [],
        'extension': [],
        'firstName': [],
        'lastName': [],
        'phone': [],
        'userPassword': [],
    }));
    b.m("PATCH")
        .h(headers)
        .b(body);
    return b.build();
};
export const de_CleanupTangoEsimOrderCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'orderId': __expectString,
        'simsReleased': __expectInt32,
        'status': __expectString,
        'steps': _json,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CreateNumbersOrderCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'customerOrderId': __expectString,
        'message': __expectString,
        'orderStatus': __expectString,
        'requestId': __expectString,
        'status': __expectString,
        'supplierOrderId': __expectString,
        'testMode': __expectBoolean,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CreateTangoEsimOrderCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'bundle': __expectString,
        'companyId': __expectString,
        'countryCode': __expectString,
        'orderId': __expectString,
        'partnerId': __expectString,
        'quantity': __expectInt32,
        'requestId': __expectString,
        'status': __expectString,
        'totalReserved': __expectInt32,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_DeleteEsimEndpointCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'companyId': __expectString,
        'serial': __expectString,
        'status': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetEsimQrCodeCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'activationCode': __expectString,
        'companyId': __expectString,
        'extension': __expectString,
        'iccid': __expectString,
        'phone': __expectString,
        'uid': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetEsimStatusCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'companyId': __expectString,
        'esimStatus': __expectString,
        'extension': __expectString,
        'iccid': __expectString,
        'phone': __expectString,
        'subUID': __expectString,
        'uid': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetSmsHistoryCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListEsimBundlesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'bundles': _json,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListEsimSubscribersCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'companyId': __expectString,
        'limit': __expectInt32,
        'offset': __expectInt32,
        'subscribers': _json,
        'total': __expectInt32,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListSmsNumbersCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'success': __expectBoolean,
        'timestamp': __expectLong,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListWhatsAppNumbersCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'result': _json,
        'success': __expectBoolean,
        'timestamp': __expectLong,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListWhatsAppTemplatesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'data': _json,
        'did': __expectString,
        'success': __expectBoolean,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ProvisionEsimSubscriberCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'activationCode': __expectString,
        'companyId': __expectString,
        'extension': __expectString,
        'iccid': __expectString,
        'phone': __expectString,
        'status': __expectString,
        'subUID': __expectString,
        'uid': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_RefreshEsimQrCodeCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'activationCode': __expectString,
        'companyId': __expectString,
        'extension': __expectString,
        'iccid': __expectString,
        'phone': __expectString,
        'uid': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_SendSmsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'company': __expectString,
        'data': _json,
        'id': _json,
        'status': __expectString,
        'success': __expectBoolean,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_SendSmsFromApplicationCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'company': __expectString,
        'data': _json,
        'id': _json,
        'status': __expectString,
        'success': __expectBoolean,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_SendWhatsAppInteractiveMessageCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'company': __expectString,
        'data': _json,
        'id': _json,
        'status': __expectString,
        'success': __expectBoolean,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_SendWhatsAppMessageCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'company': __expectString,
        'data': _json,
        'id': _json,
        'status': __expectString,
        'success': __expectBoolean,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_SendWhatsAppTemplateCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'company': __expectString,
        'data': _json,
        'id': __expectString,
        'status': __expectString,
        'success': __expectBoolean,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_SyncEsimTransformsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'added': __expectInt32,
        'companyId': __expectString,
        'deleted': __expectInt32,
        'errors': _json,
        'updated': __expectInt32,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_TerminateEsimSubscriberCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'companyId': __expectString,
        'extension': __expectString,
        'status': __expectString,
        'subUID': __expectString,
        'uid': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_UpdateEsimSubscriberCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'companyId': __expectString,
        'status': __expectString,
        'uid': __expectString,
        'updatedFields': _json,
    });
    Object.assign(contents, doc);
    return contents;
};
const de_CommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "GatewayTimeoutException":
        case "wildix.classound#GatewayTimeoutException":
            throw await de_GatewayTimeoutExceptionRes(parsedOutput, context);
        case "InternalError":
        case "wildix.classound#InternalError":
            throw await de_InternalErrorRes(parsedOutput, context);
        case "InternalServerException":
        case "wildix.classound#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "NotFoundError":
        case "wildix.classound#NotFoundError":
            throw await de_NotFoundErrorRes(parsedOutput, context);
        case "OrderError":
        case "wildix.classound#OrderError":
            throw await de_OrderErrorRes(parsedOutput, context);
        case "RequestValidationException":
        case "wildix.classound#RequestValidationException":
            throw await de_RequestValidationExceptionRes(parsedOutput, context);
        case "TangoEsimOrderError":
        case "wildix.classound#TangoEsimOrderError":
            throw await de_TangoEsimOrderErrorRes(parsedOutput, context);
        case "UserNotFoundException":
        case "wildix.classound#UserNotFoundException":
            throw await de_UserNotFoundExceptionRes(parsedOutput, context);
        case "ValidationError":
        case "wildix.classound#ValidationError":
            throw await de_ValidationErrorRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const throwDefaultError = withBaseException(__BaseException);
const de_GatewayTimeoutExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'description': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new GatewayTimeoutException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InternalErrorRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'description': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InternalError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InternalServerExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'description': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InternalServerException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_NotFoundErrorRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'description': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new NotFoundError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_OrderErrorRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'customerOrderId': __expectString,
        'description': __expectString,
        'errorCode': __expectString,
        'requestId': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new OrderError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_RequestValidationExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'description': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new RequestValidationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_TangoEsimOrderErrorRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'errorCode': __expectString,
        'message': __expectString,
        'requestId': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new TangoEsimOrderError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_UserNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'description': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new UserNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ValidationErrorRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'description': __expectString,
        'type': __expectString,
    });
    Object.assign(contents, doc);
    const exception = new ValidationError({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBodyString = (streamBody, context) => collectBody(streamBody, context).then(body => context.utf8Encoder(body));
const _cI = "companyId";
const _d = "did";
const _f = "from";
const _l = "limit";
const _o = "offset";
const _s = "serial";
const _t = "to";
const _u = "uid";
